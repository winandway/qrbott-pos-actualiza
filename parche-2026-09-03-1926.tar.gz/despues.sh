#!/bin/bash
# Pasos extra de ESTE parche: el PPD cambió → volver a registrar la impresora.
systemctl restart cups.service 2>/dev/null || true
/opt/qrbott/impresora.sh >/dev/null 2>&1 || true
echo "impresora re-registrada: $(lpstat -p QRBott-Ticket 2>&1 | head -1)"
