#!/bin/bash
# ============================================================
#  QRBott POS — pantallas y táctil
#
#  PROBLEMA REAL (equipo del cliente, 29-08-2026): había que tocar diez veces
#  para acertar. Causa: el sistema ve DOS salidas de vídeo y extiende el
#  escritorio a lo ancho de las dos; el táctil manda coordenadas ABSOLUTAS sobre
#  toda esa superficie, así que los toques caen desplazados. El ratón sí iba,
#  porque es relativo. Ver CANDADOS.md nº 29.
#
#  Qué hace:
#   1. Deja UNA sola pantalla activa (la del táctil) y clona la segunda si puede.
#   2. Amarra el táctil A ESA pantalla, para que el toque caiga donde se toca.
# ============================================================
set -uo pipefail
export DISPLAY=:0
LOG=/var/qrbott-datos/caja/pantallas.log
# La carpeta tiene que existir ANTES de escribir: este guion arranca antes que
# quien la crea, y sin esto se perdía el registro del táctil — justo lo que más
# nos ha costado diagnosticar. Auditoría 29-08-2026, fallo nº 8.
mkdir -p "$(dirname "$LOG")" 2>/dev/null || true
exec > >(tee -a "$LOG" 2>/dev/null) 2>&1 || true
echo "== $(date) configurando pantallas y táctil =="

conectadas=$(xrandr -q 2>/dev/null | awk '/ connected/{print $1}')
[ -z "$conectadas" ] && { echo "no se pudo leer las salidas de vídeo"; exit 0; }
echo "salidas conectadas: $(echo $conectadas | tr '\n' ' ')"

principal=$(echo "$conectadas" | head -1)
xrandr --output "$principal" --auto --primary 2>/dev/null
echo "pantalla principal: $principal"

# Las demás: intentar clonarlas (mismo contenido). Si no se puede, apagarlas —
# una salida fantasma encendida es lo que descoloca el táctil.
for o in $(echo "$conectadas" | tail -n +2); do
  if xrandr --output "$o" --auto --same-as "$principal" 2>/dev/null; then
    echo "  $o: clonada"
  else
    xrandr --output "$o" --off 2>/dev/null && echo "  $o: apagada (no se pudo clonar)"
  fi
done

# ---- Amarrar el táctil a la pantalla principal ----
if command -v xinput >/dev/null 2>&1; then
  # dispositivos absolutos (táctil): los que dicen Touch / Touchscreen / Finger
  ids=$(xinput list 2>/dev/null | grep -iE "touch|finger|tablet|ilitek|-tp|egalax|goodix|hid.*multi" | grep -oE "id=[0-9]+" | cut -d= -f2)
  if [ -z "$ids" ]; then
    echo "no se detectó pantalla táctil"
  else
    for id in $ids; do
      nombre=$(xinput list --name-only "$id" 2>/dev/null)
      xinput map-to-output "$id" "$principal" 2>/dev/null \
        && echo "  táctil [$id] $nombre -> $principal" \
        || echo "  no se pudo amarrar el táctil [$id] $nombre"
    done
  fi
else
  echo "falta xinput: el táctil no se puede amarrar a la pantalla"
fi

echo "== pantallas y táctil listos =="
exit 0
