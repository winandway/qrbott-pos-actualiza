#!/bin/bash
# ============================================================
#  QRBott Actualiza — Nivel 1: parches de seguridad automáticos
#
#  POR QUÉ: con 100 equipos vendidos no se puede flashear por cada hueco de
#  seguridad de Ubuntu. Esto los aplica SOLO, de madrugada, con estas reglas:
#   - SOLO parches de seguridad (unattended-upgrade: es su especialidad).
#   - Se escriben al disco REAL a través de la protección (overlayroot-chroot),
#     así sobreviven al reinicio.
#   - NUNCA reinicia por su cuenta: un kernel nuevo espera al próximo apagado
#     natural de la tienda. Cero riesgo de interrumpir una venta.
#   - Todo queda escrito: estado en /opt/qrbott/estado-parches (lo enseñan la
#     pantalla Equipo y el informe).
#  Ver ACTUALIZACIONES-PLAN.md. Candado 66.
# ============================================================
set -uo pipefail
INFO=/opt/qrbott/estado-parches
LOG=/var/qrbott-datos/caja/parches.log
mkdir -p /var/qrbott-datos/caja 2>/dev/null

exec 6>/var/lock/qrbott-parches.lock
flock -n 6 || exit 0

{ echo "== $(date '+%F %T') buscando parches de seguridad =="

# Sin red no hay parches: se intenta otra noche, sin drama.
if ! ping -c1 -W3 archive.ubuntu.com >/dev/null 2>&1 && \
   ! ping -c1 -W3 1.1.1.1 >/dev/null 2>&1; then
  echo "sin red esta noche; se intentará en la próxima"
  echo "SIN-RED:$(date '+%F %T')" > "$INFO"
  exit 0
fi

# Actualizar el índice y aplicar SOLO seguridad, contra el disco real.
if ! timeout 600 overlayroot-chroot apt-get update 2>&1 | tail -3; then
  echo "!! no se pudo leer el índice de paquetes"
  echo "ERROR-INDICE:$(date '+%F %T')" > "$INFO"
  exit 0
fi

if timeout 1500 overlayroot-chroot unattended-upgrade -v 2>&1 | tail -12; then
  echo "OK parches aplicados (o no había ninguno pendiente)"
  echo "OK:$(date '+%F %T')" > "$INFO"
else
  echo "!! unattended-upgrade terminó con error"
  echo "ERROR-PARCHES:$(date '+%F %T')" > "$INFO"
fi
} 2>&1 | tee -a "$LOG" 2>/dev/null || true
exit 0
