#!/bin/bash
# ============================================================
#  QRBott POS OS — instalador visual (3 idiomas)
#  El progreso es REAL: no hay animación ni barra decorativa.
#  Cada paso lo marca el propio instalador dejando una "miga":
#    /run/qrbott-paso            <- lo escriben las late-commands
#    /target/opt/qrbott-progreso <- lo escribe programas.sh (dentro del sistema)
#  Se muestra siempre la miga MÁS AVANZADA (los nombres van numerados).
# ============================================================
DIR=/cdrom/qrbott/pantallas
[ -d "$DIR" ] || DIR=/opt/qrbott-setup/pantallas

# Instalar el visor de imágenes en el sistema del instalador (viene en el USB)
if ! command -v fbi >/dev/null 2>&1; then
  for i in 1 2 3 4 5 6 7 8 9 10; do [ -d /cdrom/visor ] && break; sleep 2; done
  dpkg -i /cdrom/visor/*.deb >/dev/null 2>&1
fi

LOG=/var/log/installer/subiquity-server-debug.log
FB=/dev/fb0
actual=""

mostrar() {   # mostrar <nombre-de-pantalla>
  [ "$1" = "$actual" ] && return
  [ -f "$DIR/$1.png" ] || return
  actual="$1"
  printf '\033[?25l\033[2J' > /dev/tty1 2>/dev/null   # sin cursor ni texto del kernel
  if [ -e "$FB" ] && command -v fbi >/dev/null 2>&1; then
    pkill -f "fbi .*$DIR" 2>/dev/null
    fbi -T 1 -d "$FB" -noverbose -a "$DIR/$1.png" >/dev/null 2>&1 &
  elif command -v fbv >/dev/null 2>&1; then
    fbv -c -f -i "$DIR/$1.png" >/dev/null 2>&1 &
  fi
}

# Antes de que empiecen nuestras migas, el paso sale del log del instalador
paso_del_log() {
  [ -r "$LOG" ] || { echo "01-bienvenida"; return; }
  if   grep -qa "cmd-extract\|curtin extract\|installing kernel" "$LOG" 2>/dev/null; then echo "20-sistema"
  elif grep -qa "stage-partitioning\|block-meta"                 "$LOG" 2>/dev/null; then echo "10-disco"
  else echo "01-bienvenida"; fi
}

paso_actual() {
  { paso_del_log
    cat /run/qrbott-paso            2>/dev/null
    cat /target/opt/qrbott-progreso 2>/dev/null
  } | grep -E '^[0-9]{2}-' | sort | tail -1
}

mostrar 01-bienvenida
while true; do
  p="$(paso_actual)"
  [ -n "$p" ] && mostrar "$p"
  sleep 3
done
