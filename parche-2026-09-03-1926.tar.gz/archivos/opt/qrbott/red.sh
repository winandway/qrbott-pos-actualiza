#!/bin/bash
# ============================================================
#  QRBott POS — asistente de red del primer arranque
#  Si no hay internet, muestra en pantalla el selector de Wi-Fi
#  para que el dueño escriba su contraseña. Universal, cualquier país.
# ============================================================
export DISPLAY=:0

hay_internet() { curl -sf -m 4 https://pos.qrbott.com >/dev/null 2>&1; }

# Cable o Wi-Fi ya recordado: seguir sin molestar
for i in 1 2 3 4 5 6 7 8; do hay_internet && exit 0; sleep 2; done

# Sin internet → asistente en pantalla completa
onboard --startup-delay=1 &   # teclado en pantalla para escribir la contraseña
sleep 1

xterm -fa "DejaVu Sans Mono" -fs 16 -bg "#0f172a" -fg "#e2e8f0" \
  -geometry 100x30 -title "QRBott POS — Conectar a internet" \
  -e bash -c '
cat <<TXT

   ╔══════════════════════════════════════════════════════════╗
   ║              QRBott POS — Conectar a internet             ║
   ╚══════════════════════════════════════════════════════════╝

   Esta caja necesita internet la primera vez, para cargar
   tu tienda. Después puede vender aunque se caiga la red.

   Elige tu red Wi-Fi de la lista y escribe la contraseña.
   (Si conectaste un cable de red, sal con  Q  y listo.)

   Se abrirá el selector de redes en 3 segundos...

TXT
sleep 3
nmtui connect
' 2>/dev/null

# Reintentar: si ya hay internet, seguir
for i in 1 2 3 4 5; do hay_internet && break; sleep 2; done
pkill onboard 2>/dev/null || true
exit 0
