#!/bin/bash
# ============================================================
#  QRBott POS — pendrives y discos USB
#
#  POR QUÉ EXISTE (preguntado por los usuarios, 29-08-2026): el equipo tiene
#  varios puertos USB y estaban MUDOS. Meter un pendrive con fotos de productos
#  no hacía nada. La causa: quien monta los pendrives normalmente es el
#  escritorio, y nuestro sistema no tiene escritorio — arranca directo en la
#  caja. Así que lo montamos nosotros, sin depender de ninguna sesión gráfica.
#  Ver CANDADOS.md nº 36.
#
#  Uso:  montar-usb.sh <sdb1> add|remove
# ============================================================
set -uo pipefail
DEV="/dev/${1:-}"
ACCION="${2:-add}"
BASE="/media/qrbott"
ESTADO="/opt/qrbott/estado-usb"
LOG="/var/qrbott-datos/caja/usb.log"
ENLACE="/var/qrbott-datos/Mis archivos/Pendrive"

anotar() { echo "$(date '+%F %T') $*" >> "$LOG" 2>/dev/null || true; }

# Solo UNO a la vez: la regla del sistema y el vigía pueden llegar juntos al
# mismo pendrive y montarlo dos veces. Auditoría v5, fallo 24. Candado 53.
exec 7>/var/lock/qrbott-usb.lock
flock -w 20 7 || exit 0

if [ "$ACCION" = "remove" ]; then
  # OJO: aquí había la condición AL REVÉS. Decía «si NO está montado,
  # desmóntalo», así que un pendrive montado NUNCA se soltaba: quedaban
  # montajes muertos y la barra seguía diciendo que había un pendrive puesto
  # después de sacarlo. Ahora se desmonta lo que de verdad está montado.
  # Auditoría 29-08-2026, fallo nº 1. Candado 43.
  quedan=0
  for p in "$BASE"/*; do
    [ -d "$p" ] || continue
    if mountpoint -q "$p"; then
      # ¿Sigue existiendo el disco de detrás? Si no, es un montaje muerto.
      origen=$(findmnt -no SOURCE "$p" 2>/dev/null)
      if [ -z "$origen" ] || [ ! -b "$origen" ]; then
        umount -l "$p" 2>/dev/null
        rmdir "$p" 2>/dev/null
        anotar "soltado el montaje muerto de $p"
      else
        quedan=$((quedan+1))
      fi
    else
      rmdir "$p" 2>/dev/null
    fi
  done
  if [ "$quedan" -eq 0 ]; then
    rm -f "$ESTADO" "$ENLACE"
    anotar "ya no queda ningún pendrive"
  fi
  anotar "retirado $DEV (quedan $quedan)"
  exit 0
fi

if [ "$ACCION" = "escanear" ] || [ "${1:-}" = "escanear" ]; then
  # EL VIGÍA. En el equipo real el pendrive NO fue reconocido: la regla del
  # sistema (udev) no disparó. Este modo no depende de ella: repasa los discos
  # USB presentes y monta el que falte. Lo llama el servicio cada 6 segundos.
  # Informe de campo del 30-08-2026. Candado 53.
  lsblk -rno NAME,TRAN,TYPE,FSTYPE,MOUNTPOINT 2>/dev/null | while read -r n tran tipo fs mp; do
    [ "$tran" = "usb" ] || { # las particiones no traen TRAN: mirar el padre
      padre=$(lsblk -rno PKNAME "/dev/$n" 2>/dev/null | head -1)
      [ -n "$padre" ] && [ "$(lsblk -rno TRAN "/dev/$padre" 2>/dev/null)" = "usb" ] || continue
    }
    [ -n "$fs" ] || continue                 # sin sistema de archivos no hay nada que montar
    [ -z "$mp" ] || continue                 # ya montado
    case "$tipo" in disk|part) ;; *) continue ;; esac
    # si es un disco entero pero tiene particiones, que monte la partición
    if [ "$tipo" = "disk" ] && lsblk -rno TYPE "/dev/$n" 2>/dev/null | grep -q "^part$"; then continue; fi
    "$0" "$n" add
  done
  exit 0
fi

[ -b "$DEV" ] || { anotar "no es un disco: $DEV"; exit 0; }

# Idempotente: si este disco YA está montado, no montarlo dos veces.
findmnt -no TARGET -S "$DEV" >/dev/null 2>&1 && exit 0

# Qué trae dentro (FAT, exFAT, NTFS…) y cómo se llama
TIPO=$(blkid -o value -s TYPE "$DEV" 2>/dev/null)
NOMBRE=$(blkid -o value -s LABEL "$DEV" 2>/dev/null)
[ -z "$TIPO" ] && { anotar "sin sistema de archivos: $DEV"; exit 0; }
[ -z "$NOMBRE" ] && NOMBRE="Pendrive"
# Nada de nombres raros que rompan una ruta
NOMBRE=$(echo "$NOMBRE" | tr -c 'A-Za-z0-9._-' '_' | cut -c1-40)

PUNTO="$BASE/$NOMBRE"
n=2
while mountpoint -q "$PUNTO"; do PUNTO="$BASE/${NOMBRE}_$n"; n=$((n+1)); done
mkdir -p "$PUNTO"

# El dueño tiene que poder escribir. 'flush' hace que lo copiado se grabe
# enseguida, para que sacar el pendrive no pierda archivos.
UID_POS=$(id -u pos 2>/dev/null || echo 1000)
GID_POS=$(id -g pos 2>/dev/null || echo 1000)
case "$TIPO" in
  vfat|exfat)
    mount -t "$TIPO" -o "rw,uid=$UID_POS,gid=$GID_POS,umask=000,flush" "$DEV" "$PUNTO" 2>>"$LOG" ;;
  ntfs|ntfs3)
    mount -t ntfs3 -o "rw,uid=$UID_POS,gid=$GID_POS,umask=000" "$DEV" "$PUNTO" 2>>"$LOG" \
      || mount -t ntfs-3g -o "rw,uid=$UID_POS,gid=$GID_POS,umask=000" "$DEV" "$PUNTO" 2>>"$LOG" ;;
  *)
    mount -o rw "$DEV" "$PUNTO" 2>>"$LOG" ;;
esac

if mountpoint -q "$PUNTO"; then
  ln -sfn "$PUNTO" "$ENLACE" 2>/dev/null || true
  printf 'OK\t%s\t%s\t%s\n' "$NOMBRE" "$PUNTO" "$TIPO" > "$ESTADO"
  anotar "montado $DEV ($TIPO) en $PUNTO"
else
  rmdir "$PUNTO" 2>/dev/null
  printf 'ERROR\t%s\t\t%s\n' "$NOMBRE" "$TIPO" > "$ESTADO"
  anotar "NO se pudo montar $DEV ($TIPO)"
fi
exit 0
