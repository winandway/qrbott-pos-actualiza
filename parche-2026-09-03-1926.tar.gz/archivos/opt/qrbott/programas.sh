#!/bin/bash
# Instala todos los programas desde el USB (sin internet).
# Va dejando MIGAS de progreso REAL en /opt/qrbott-progreso; la pantalla del
# instalador (instalador-visual.sh) las lee para mostrar en qué paso va.
set -uo pipefail
LOG=/var/log/qrbott-programas.log
exec > >(tee -a "$LOG") 2>&1
echo "== Instalando programas desde el USB (sin internet) =="
export DEBIAN_FRONTEND=noninteractive

paso() { echo "$1" > /opt/qrbott-progreso 2>/dev/null || true; echo "-- paso $1"; }

instalar() {   # instalar <miga> <paquetes…>
  local miga="$1"; shift
  paso "$miga"
  # Si una etapa falla, la instalación SE DETIENE y lo dice. En la 12ª
  # instalación, la etapa 32 murió por un pool con versiones mezcladas y el
  # instalador siguió como si nada: el equipo quedó sin cups NI red y nadie
  # gritó. Un equipo a medias que parece bueno es peor que una instalación
  # fallida a la vista. Candado 65.
  if ! apt-get install -y --no-install-recommends \
    -o Acquire::AllowInsecureRepositories=true \
    -o APT::Get::AllowUnauthenticated=true \
    -o Acquire::Retries=0 -o Acquire::http::Timeout=5 \
    "$@" 2>&1 | tail -12; then
    echo "!! LA ETAPA $miga NO PUDO INSTALARSE. La instalación NO puede seguir."
    echo "ERROR:etapa-$miga" > /opt/qrbott-progreso 2>/dev/null || true
    exit 1
  fi
}
set -o pipefail

# 1) Pantalla táctil: servidor gráfico, controladores, escritorio mínimo, teclado
instalar 30-pos xserver-xorg-core xserver-xorg-input-libinput \
  xserver-xorg-video-fbdev xserver-xorg-video-vesa \
  xinit xauth xserver-xorg-legacy x11-xserver-utils xinput xdotool mesa-utils openbox pcmanfm udisks2 ntfs-3g exfatprogs dosfstools gvfs gvfs-backends unclutter onboard at-spi2-core

# 2) El punto de venta en sí (el navegador en modo caja)
instalar 31-pos chromium chromium-common chromium-sandbox dbus-x11 xterm fonts-dejavu-core fonts-noto-cjk fonts-noto-color-emoji

# 3) Impresora, red y el resto del sistema
instalar 32-pos cups cups-client poppler-utils printer-driver-escpr plymouth plymouth-themes \
  network-manager network-manager-gnome wpasupplicant iw rfkill wireless-tools curl unattended-upgrades overlayroot cloud-guest-utils python3

# Plan B: si apt falla, instalar los .deb a mano
if ! command -v chromium >/dev/null 2>&1; then
  echo "  apt no pudo; instalando los paquetes uno por uno…"
  dpkg -i /opt/qrbott-pool/*.deb 2>/dev/null | tail -5
  apt-get -f install -y --no-install-recommends 2>/dev/null | tail -5
fi

echo "== Programas instalados =="
faltan=0
for c in Xorg xinit openbox chromium onboard cupsd nmcli; do
  if command -v $c >/dev/null 2>&1; then echo "   OK  $c"; else echo "   --  $c (no encontrado)"; faltan=1; fi
done
# CANDADO: dejar constancia visible de si algo quedó sin instalar (nunca en silencio)
echo "$faltan" > /opt/qrbott-programas-faltan 2>/dev/null || true

exit 0   # nunca tumbar la instalación
