#!/bin/bash
# ============================================================
#  Possum OS — convierte Ubuntu mínimo en la caja QRBott
#  Se ejecuta UNA vez, al final de la instalación desatendida.
# ============================================================
set -uo pipefail   # sin -e: un comando que falle no debe tumbar la instalación
LOG=/var/log/qrbott-setup.log
exec > >(tee -a "$LOG") 2>&1
echo "== Possum OS · configuración inicial =="

DIR=/opt/qrbott
mkdir -p "$DIR"
cp -r /opt/qrbott-setup/* "$DIR"/ 2>/dev/null || true

# ---------- 1. Identidad del equipo (MAC, porque el serial viene vacío) ----------
cat > "$DIR"/identidad.sh <<'ID'
#!/bin/bash
# Devuelve un identificador ESTABLE del equipo.
# 1º el serial del BIOS si es real; si no, la MAC de red (única y sobrevive al clonado).
s=$(cat /sys/class/dmi/id/product_serial 2>/dev/null || true)
[ -z "$s" ] && s=$(cat /sys/class/dmi/id/board_serial 2>/dev/null || true)
case "${s,,}" in ""|*"to be filled"*|*"default string"*|*"none"*|*"system serial"*) s="" ;; esac
if [ -z "$s" ]; then
  m=$(cat /sys/class/net/e*/address 2>/dev/null | head -1)
  [ -z "$m" ] && m=$(cat /sys/class/net/w*/address 2>/dev/null | head -1)
  s="MAC-$(echo "$m" | tr -d ':' | tr 'a-z' 'A-Z')"
fi
echo "$s"
ID
chmod +x "$DIR"/identidad.sh

# ---------- 2. La caja (Chromium en kiosco) ----------
# caja.sh vive en payload/caja.sh (ya copiado a $DIR): así un PARCHE firmado
# puede cambiarlo sin volver a instalar el sistema. QRBott Actualiza, candado 71.
[ -s "$DIR"/caja.sh ] || { echo '!! falta caja.sh en el payload'; exit 1; }
chmod +x "$DIR"/caja.sh
# La versión REAL: se lee del propio asistente (la sella construir-iso.sh).
# Antes aquí decía "1.0.0" fijo: el equipo mentía su versión a la nube y al
# informe, y un fallo de un cliente no se podría rastrear a su versión.
# Auditoría 2ª vuelta, fallo 18. Candado 49.
V_REAL=$(grep -oE '"[0-9]{4}-[0-9]{2}-[0-9]{2}-[0-9]{4}"' "$DIR"/asistente-red.py | head -1 | tr -d '"')
echo "${V_REAL:-1.0.0}" > "$DIR"/version

# ---------- 3. Arranque automático (sin escritorio) ----------
# OJO — NO se escribe nada en /home/pos: cuando esto corre, el usuario TODAVÍA NO
# EXISTE (lo crea cloud-init en el primer arranque) y los archivos se perdían en
# silencio; el equipo arrancaba en una consola negra en vez de la caja.
# Todo vive en /opt/qrbott y lo arranca un servicio del sistema. Ver CANDADOS.md nº 7.

cat > "$DIR"/xinitrc <<'XI'
#!/bin/bash
openbox &
exec /opt/qrbott/caja.sh
XI
chmod +x "$DIR"/xinitrc

# Carpeta de trabajo del navegador fuera de /home (existe siempre)
mkdir -p /var/lib/qrbott/chrome

cat > /etc/systemd/system/qrbott-caja.service <<'SVC'
[Unit]
Description=Caja QRBott (punto de venta a pantalla completa)
After=systemd-user-sessions.service plymouth-quit-wait.service network.target
# El usuario 'pos' lo crea cloud-init en el PRIMER arranque. Se espera SOLO a
# cloud-init.service (que corre antes de multi-user.target). OJO: poner aquí
# cloud-config.service o cloud-final.service crea un CICLO de dependencias y
# systemd SALTA el servicio en silencio -> el equipo arranca en negro.
# Ver CANDADOS.md nº 10.
After=cloud-init.service qrbott-persistencia.service
Requires=qrbott-persistencia.service
RequiresMountsFor=/var/qrbott-datos
Conflicts=getty@tty1.service
After=getty@tty1.service
StartLimitIntervalSec=0

[Service]
User=pos
Group=pos
PAMName=login
TTYPath=/dev/tty1
TTYReset=yes
TTYVHangup=yes
StandardInput=tty
StandardOutput=journal
StandardError=journal
Environment=XDG_RUNTIME_DIR=/run/user/1000
WorkingDirectory=/var/lib/qrbott
ExecStartPre=+/bin/sh -c 'mkdir -p /var/qrbott-datos/caja/chrome; chown -R pos:pos /var/qrbott-datos/caja'
ExecStartPre=+/opt/qrbott/carpetas.sh
ExecStart=/usr/bin/xinit /opt/qrbott/xinitrc -- :0 vt1 -keeptty
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
SVC

# Que el usuario 'pos' pueda arrancar X en la consola
cat > /etc/X11/Xwrapper.config <<'XW'
allowed_users=anybody
needs_root_rights=yes
XW

cat > "$DIR"/diagnostico.sh <<'DIA'
#!/bin/bash
# Cuenta cómo quedó el equipo. Se guarda en /opt/qrbott/diagnostico.txt y, si hay
# puerto serie, se vuelca ahí (así soporte lo puede capturar sin teclear nada).
{
  echo "===== QRBott POS — diagnóstico $(date) ====="
  echo "-- estado que dejó la instalación:"; cat /opt/qrbott/estado-caja 2>/dev/null
  echo "-- navegador (motor):"; ls -l /usr/lib/chromium/chromium 2>&1 | tail -1
  echo "-- usuario pos:"; id pos 2>&1
  echo "-- servicio de la caja:"
  systemctl is-enabled qrbott-caja 2>&1; systemctl is-active qrbott-caja 2>&1
  systemctl show qrbott-caja -p Result -p ExecMainStatus -p NRestarts 2>&1
  echo "-- ciclos de dependencias en este arranque:"
  journalctl -b --no-pager 2>/dev/null | grep -i "ordering cycle" | head -5
  echo "-- últimas líneas del servicio:"
  journalctl -b -u qrbott-caja --no-pager -o cat 2>/dev/null | tail -25
  echo "-- servicios del equipo:"
  cat /opt/qrbott/estado-servicios 2>/dev/null || echo "   (sin comprobar)"
  systemctl is-active qrbott-caja qrbott-asistente-red qrbott-impresora 2>&1 | tr '\n' ' '
  echo
  echo "-- pendrives:"
  cat /opt/qrbott/estado-usb 2>/dev/null || echo "   ninguno conectado"
  ls -1 /media/qrbott 2>/dev/null | sed 's/^/   /'
  echo "-- carpeta del dueño:"
  ls -1 /var/qrbott-datos/"Mis archivos" 2>/dev/null | sed 's/^/   /' || echo "   NO existe"
  df -h /var/qrbott-datos 2>/dev/null | tail -1 | awk '{print "   disco: "$4" libres de "$2}'
  echo "-- botón de apagar:"
  pgrep -af "QRBottBarra" >/dev/null 2>&1 && echo "   barra activa (modo: $(cat /opt/qrbott/estado-barra 2>/dev/null || echo tuerca))" || echo "   NO está la barra"
  echo "-- rendimiento:"
  echo "   procesador: $(grep -m1 'model name' /proc/cpuinfo 2>/dev/null | cut -d: -f2 | xargs)"
  echo "   memoria: $(free -m 2>/dev/null | awk '/Mem:/{print $3"/"$2" MB usados"}')"
  echo "   carga: $(cut -d' ' -f1-3 /proc/loadavg 2>/dev/null)"
  echo "   controlador de vídeo: $(grep -m1 -oE 'Loading /usr/lib/xorg/modules/drivers/[a-z]+' /var/log/Xorg.0.log 2>/dev/null | sed 's|.*/||')"
  echo "   aceleración: $(glxinfo -B 2>/dev/null | grep -m1 -i 'renderer' || echo 'no comprobada')"
  echo "-- impresora:"
  cat /opt/qrbott/estado-impresora 2>/dev/null
  lpstat -p 2>&1 | head -3
  lpinfo -v 2>/dev/null | head -6
  echo "-- pantallas y táctil:"
  cat /var/qrbott-datos/caja/pantallas.log 2>/dev/null | tail -12
  echo "-- red (cable y Wi-Fi):"
  nmcli -t -f DEVICE,TYPE,STATE device 2>&1 | head -6
  ip -4 -o addr show scope global 2>&1 | awk '{print "   ",$2,$4}'
  curl -sf -m 5 -o /dev/null https://pos.qrbott.com && echo "    internet: SÍ" || echo "    internet: no"
  echo "-- zona de datos (lo que sobrevive al apagón):"
  cat /opt/qrbott/estado-datos 2>/dev/null
  findmnt -no SOURCE,SIZE,USED /var/qrbott-datos 2>&1
  echo "-- equipo y clave propia:"; /opt/qrbott/identidad.sh 2>&1
  echo "-- permisos de la carpeta del navegador:"
  ls -ld /var/qrbott-datos/caja /var/qrbott-datos/caja/chrome /home/pos 2>&1
  echo "-- lo que dijo la caja al arrancar:"
  tail -30 /var/qrbott-datos/caja/caja.log 2>&1
  echo "-- Xorg:"; tail -15 /var/log/Xorg.0.log 2>/dev/null
  echo "===== fin ====="
} > /opt/qrbott/diagnostico.txt 2>&1
cat /opt/qrbott/diagnostico.txt > /dev/ttyS0 2>/dev/null || true
DIA
chmod +x "$DIR"/diagnostico.sh

cat > /etc/systemd/system/qrbott-diagnostico.service <<'SVC'
[Unit]
Description=Diagnóstico de la caja QRBott (para soporte)
After=multi-user.target qrbott-caja.service
[Service]
Type=oneshot
ExecStartPre=/bin/sleep 25
ExecStart=/opt/qrbott/diagnostico.sh
RemainAfterExit=yes
[Install]
WantedBy=multi-user.target
SVC

# ---------- 2b. El navegador se comporta como una CAJA, no como un navegador ----------
# Sin esto sale el cuadro de traducción ("Spanish / English"), ofertas de guardar
# contraseñas, avisos de navegador por defecto… cosas que el cliente NO puede ver
# en su punto de venta. Las opciones de línea de comandos no bastan: hace falta
# la política del sistema. Ver CANDADOS.md nº 16.
for POLDIR in /etc/chromium/policies/managed /etc/chromium-browser/policies/managed \
              /etc/opt/chrome/policies/managed; do
  mkdir -p "$POLDIR"
  cat > "$POLDIR"/qrbott.json <<'POL'
{
  "TranslateEnabled": false,
  "SpellcheckEnabled": false,
  "DefaultCookiesSetting": 1,
  "CookiesAllowedForUrls": ["https://pos.qrbott.com", "https://app.qrbott.com"],
  "DefaultJavaScriptSetting": 1,
  "BrowserSignin": 0,
  "SyncDisabled": true,
  "DefaultNotificationsSetting": 2,
  "PromptForDownloadLocation": false,
  "DownloadDirectory": "/var/qrbott-datos/Mis archivos/Descargas",
  "PasswordManagerEnabled": false,
  "AutofillAddressEnabled": false,
  "AutofillCreditCardEnabled": false,
  "PromotionalTabsEnabled": false,
  "DefaultBrowserSettingEnabled": false,
  "MetricsReportingEnabled": false,
  "SearchSuggestEnabled": false,
  "BrowserSignin": 0,
  "SyncDisabled": true,
  "ShowHomeButton": false,
  "BookmarkBarEnabled": false,
  "DefaultNotificationsSetting": 2,
  "DefaultGeolocationSetting": 2,
  "PrintingEnabled": true,
  "DefaultPrinterSelection": "{\"kind\":\"local\",\"idPattern\":\"QRBott-Ticket\"}",
  "InsecurePrivateNetworkRequestsAllowedForUrls": ["https://pos.qrbott.com", "https://app.qrbott.com"]
}
POL
done

# ---------- 3a. RED: cable y Wi-Fi, los dos, con el mismo dueño ----------
# El equipo trae las dos: Ethernet (RJ-45) y Wi-Fi. Ubuntu deja la red en manos
# de 'networkd', pero nuestro asistente de Wi-Fi (nmtui) habla con
# NetworkManager: si no mandan lo mismo, el cable funciona pero en el asistente
# NO APARECE NINGUNA RED. Aquí se le entrega todo a NetworkManager.
# Ver CANDADOS.md nº 14.
rm -f /etc/netplan/*.yaml /etc/netplan/*.yml 2>/dev/null
cat > /etc/netplan/01-qrbott.yaml <<'NET'
# QRBott POS — la red la maneja NetworkManager (cable Y Wi-Fi).
# El cable se conecta solo al enchufarlo; el Wi-Fi lo elige el dueño en pantalla.
network:
  version: 2
  renderer: NetworkManager
NET
chmod 600 /etc/netplan/01-qrbott.yaml

# Que cloud-init no vuelva a escribir la red en el primer arranque
mkdir -p /etc/cloud/cloud.cfg.d
cat > /etc/cloud/cloud.cfg.d/99-qrbott-red.cfg <<'CI'
network: {config: disabled}
CI

# El cable, además, con prioridad sobre el Wi-Fi cuando estén los dos
mkdir -p /etc/NetworkManager/conf.d
cat > /etc/NetworkManager/conf.d/10-qrbott.conf <<'NMC'
[main]
no-auto-default=
[connection]
ipv6.ip6-privacy=0
NMC

# Sitio fijo para la caja y para la barra de abajo. Se identifican por su
# clase (se la ponemos con --class), que es lo fiable.
mkdir -p /etc/xdg/openbox
cat > /etc/xdg/openbox/rc.xml <<'OB'
<?xml version="1.0" encoding="UTF-8"?>
<openbox_config xmlns="http://openbox.org/3.4/rc">
  <applications>
    <application class="QRBottBarra">
      <decor>no</decor><layer>above</layer><focus>no</focus>
      <skip_taskbar>yes</skip_taskbar><skip_pager>yes</skip_pager>
    </application>
    <application class="QRBottCaja">
      <decor>no</decor><maximized>no</maximized><focus>yes</focus>
    </application>
    <application type="dialog">
      <layer>above</layer><focus>yes</focus>
      <position force="yes"><x>center</x><y>center</y></position>
    </application>
  </applications>
</openbox_config>
OB

# El botón FÍSICO de encendido hace un apagado LIMPIO (pulsación corta).
# La pulsación larga de 4 segundos sigue siendo corte bruto: eso no se toca.
mkdir -p /etc/systemd/logind.conf.d
cat > /etc/systemd/logind.conf.d/qrbott.conf <<'LG'
[Login]
HandlePowerKey=poweroff
HandlePowerKeyLongPress=ignore
LG

# ---------- 3a-bis. La carpeta del dueño (el disco del equipo es suyo) ----------
# El equipo tiene disco de sobra. Estas carpetas son las que ve al tocar
# "Mis archivos", y son a donde caen las descargas del navegador.
MIS="/var/qrbott-datos/Mis archivos"
mkdir -p "$MIS/Fotos de productos" "$MIS/Descargas" "$MIS/Documentos"
chown -R pos:pos /var/qrbott-datos/"Mis archivos" 2>/dev/null || true
# El acceso directo se crea al arrancar la caja, cuando 'pos' ya existe.

# Que el navegador descargue AHÍ, y no en un rincón que nadie encuentra.
# OJO (candado 7): cuando corre este instalador el usuario 'pos' TODAVÍA NO
# EXISTE. Por eso va en /etc/skel, que es la plantilla con la que se crea su
# carpeta, y además en la configuración global de XDG. Escribirlo directo en
# /home/pos se perdería en silencio.
mkdir -p /etc/skel/.config
cat > /etc/skel/.config/user-dirs.dirs <<'UD'
XDG_DOWNLOAD_DIR="/var/qrbott-datos/Mis archivos/Descargas"
XDG_PICTURES_DIR="/var/qrbott-datos/Mis archivos/Fotos de productos"
XDG_DOCUMENTS_DIR="/var/qrbott-datos/Mis archivos/Documentos"
UD
# OJO: /etc/xdg/user-dirs.defaults espera NOMBRES de carpeta relativos, no
# rutas absolutas con espacios. Se deja como respaldo, pero lo que manda de
# verdad es el archivo user-dirs.dirs del cajero (con comillas y ruta completa),
# que además se escribe en cada arranque por si el usuario ya existía.
# Auditoría 29-08-2026, fallo nº 7. Candado 46.
cat > /etc/xdg/user-dirs.defaults <<'UD'
DOWNLOAD=Descargas
PICTURES=Imagenes
DOCUMENTS=Documentos
UD

# ---------- 3a-ter. Los pendrives (los puertos USB dejan de estar mudos) -------
# El equipo tiene varios puertos USB y no servían para nada: quien monta un
# pendrive es normalmente el escritorio, y aquí no hay escritorio. Lo hacemos
# nosotros, con una regla del sistema, sin depender de ninguna sesión gráfica.
mkdir -p /media/qrbott
cat > /etc/udev/rules.d/71-qrbott-usb.rules <<'UDEV'
ACTION=="add",    SUBSYSTEM=="block", SUBSYSTEMS=="usb", ENV{DEVTYPE}=="partition", ENV{ID_FS_TYPE}!="", RUN+="/usr/bin/systemctl --no-block start qrbott-usb@%k.service"
ACTION=="remove", SUBSYSTEM=="block", SUBSYSTEMS=="usb", ENV{DEVTYPE}=="partition", RUN+="/usr/bin/systemctl --no-block start qrbott-usb-quitar@%k.service"
UDEV

cat > /etc/systemd/system/qrbott-usb@.service <<'SVC'
[Unit]
Description=Montar el pendrive %i de QRBott
[Service]
Type=oneshot
ExecStart=/opt/qrbott/montar-usb.sh %i add
SVC

cat > /etc/systemd/system/qrbott-usb-quitar@.service <<'SVC'
[Unit]
Description=Soltar el pendrive %i de QRBott
[Service]
Type=oneshot
ExecStart=/opt/qrbott/montar-usb.sh %i remove
SVC

# El perfil del navegador (donde vive el catálogo bajado y las ventas sin
# subir) va en el disco persistente y no se toca jamás al actualizar.
mkdir -p /var/qrbott-datos/caja
chown -R pos:pos /var/qrbott-datos 2>/dev/null || true

# ---------- 3b. Que NADA de lo del dueño se pierda al apagar ----------
# El disco raíz va en solo lectura. Lo que tiene que sobrevivir se apunta a la
# partición de datos (QRBOTTDATA). Los enlaces se crean AHORA, mientras el disco
# aún se puede escribir; después ya no se podría. Ver CANDADOS.md nº 12.
mkdir -p /var/qrbott-datos

# la sesión del punto de venta y el registro de la caja
rm -rf /var/lib/qrbott && ln -sfn /var/qrbott-datos/caja /var/lib/qrbott

# el Wi-Fi de la tienda
rm -rf /etc/NetworkManager/system-connections
mkdir -p /etc/NetworkManager
ln -sfn /var/qrbott-datos/red /etc/NetworkManager/system-connections

# LA CAUSA RAÍZ DEL WI-FI QUE SE OLVIDABA (reproducida en la máquina virtual
# el 1-09-2026): Ubuntu 24.04 NO guarda las conexiones de NetworkManager en
# system-connections. Las convierte en YAML dentro de /etc/netplan/ y regenera
# la clave real en /run (memoria volátil) en cada arranque. /etc/netplan
# vivía en la capa protegida (tmpfs) → se borraba al reiniciar → la clave se
# perdía SIEMPRE. Los tres arreglos anteriores apuntaban a una carpeta que
# Ubuntu ignora. Ahora /etc/netplan vive en el disco de datos. Probado: una
# conexión creada, reinicio, y sigue viva y conectada. Candado 70.
mkdir -p /usr/share/qrbott/netplan-base
cp -a /etc/netplan/. /usr/share/qrbott/netplan-base/ 2>/dev/null || true
rm -rf /etc/netplan
ln -sfn /var/qrbott-datos/netplan /etc/netplan

# EL WI-FI SE CONECTA SOLO AL ARRANCAR. Ubuntu Server trae al guardián de red
# con el Wi-Fi como «dispositivo no gestionado»: la clave se guardaba bien,
# pero al reiniciar NADIE intentaba conectarla (nuestro asistente la forzaba a
# mano con «managed yes», y por eso solo funcionaba mientras él estaba
# abierto). Esta política lo gestiona TODO desde el arranque. Candado 64.
mkdir -p /etc/NetworkManager/conf.d
cat > /etc/NetworkManager/conf.d/10-qrbott-gestionado.conf <<'NMC'
[keyfile]
unmanaged-devices=none
NMC
rm -f /usr/lib/NetworkManager/conf.d/10-globally-managed-devices.conf 2>/dev/null || true

# la impresora registrada (se guarda una copia base para el primer arranque)
mkdir -p /usr/share/qrbott
# /etc/cups SE QUEDA DONDE ESTÁ. Antes se movía al disco de datos con un
# enlace, y el escudo de seguridad (AppArmor) le PROHÍBE a cupsd leer fuera de
# /etc/cups: el motor moría al nacer, en TODOS los equipos, siempre. Era LA
# causa raíz de cinco días sin imprimir. La cola no necesita persistencia:
# impresora.sh la registra en cada arranque. Informe de campo del 30-08-2026,
# líneas "apparmor DENIED cupsd". Candado 55.
cp -a /etc/cups /usr/share/qrbott/cups-base 2>/dev/null

cat > /etc/systemd/system/qrbott-persistencia.service <<'SVC'
[Unit]
Description=Zona de datos de QRBott (Wi-Fi, sesión y impresora del dueño)
# OJO: tiene que correr DESPUÉS de cloud-init, que es quien crea al usuario
# 'pos'. Si corre antes, el cambio de dueño de las carpetas no se aplica (falla
# en silencio) y el navegador no puede escribir: la caja se cierra en bucle.
# Y ANTES de NetworkManager, que lee el Wi-Fi guardado. Ver CANDADOS.md nº 15.
After=local-fs.target cloud-init.service
Before=qrbott-caja.service cups.service NetworkManager.service
RequiresMountsFor=/var/qrbott-datos
[Service]
Type=oneshot
ExecStart=/opt/qrbott/persistencia.sh
RemainAfterExit=yes
[Install]
WantedBy=multi-user.target
SVC

cat > /etc/systemd/system/qrbott-asistente-red.service <<'SVC'
[Unit]
Description=Asistente de conexión de QRBott (primer arranque)
After=NetworkManager.service
[Service]
ExecStart=/usr/bin/python3 /opt/qrbott/asistente-red.py
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
SVC

# ---------- 3z. Encender el PUERTO PARALELO (la impresora vive ahí) ----------
cat > /etc/modules-load.d/qrbott-impresora.conf <<'MOD'
# La impresora POS58 de este equipo está INTEGRADA y va por LPT1 (paralelo).
# Ubuntu no carga esto solo: sin estos módulos /dev/lp0 no existe y la
# impresora no se ve por ningún lado. Candado 39.
parport
parport_pc
lp
ppdev
usblp
MOD

# ---------- 3w. NUESTRO driver de la térmica (para el diálogo de imprimir) ----
# Sin driver, el navegador decía «not installed correctly». Este filtro
# convierte el PDF del navegador a ESC/POS raster. Candado 59.
install -m 755 -o root -g root "$DIR"/qrbott-pdf-a-escpos /usr/lib/cups/filter/qrbott-pdf-a-escpos
install -m 755 -o root -g root "$DIR"/qrbott-escpos-paso /usr/lib/cups/filter/qrbott-escpos-paso
install -m 644 -o root -g root "$DIR"/qrbott.types /usr/share/cups/mime/qrbott.types

# ---------- 4. Impresora térmica 58 mm (POS58, puerto serie/paralelo) ----------
# impresora.sh vive en payload/impresora.sh (ya copiado a $DIR): así un parche
# puede cambiarlo sin reinstalar. Candado 79.
[ -s "$DIR"/impresora.sh ] || { echo '!! falta impresora.sh en el payload'; exit 1; }
chmod +x "$DIR"/impresora.sh
# CUPS debe poder escribir a puertos file:
sed -i 's/^#*FileDevice.*/FileDevice Yes/' /etc/cups/cups-files.conf 2>/dev/null || echo "FileDevice Yes" >> /etc/cups/cups-files.conf
usermod -aG lp,lpadmin,dialout pos 2>/dev/null || true

# Si el dueño enchufa la impresora DESPUÉS de encender, se vuelve a intentar
cat > /etc/udev/rules.d/70-qrbott-impresora.rules <<'UDEV'
ACTION=="add", SUBSYSTEM=="usb", ENV{ID_USB_INTERFACES}=="*:0701*", RUN+="/opt/qrbott/impresora.sh"
ACTION=="add", SUBSYSTEM=="usbmisc", KERNEL=="lp*", RUN+="/opt/qrbott/impresora.sh"
UDEV

# Segundo intento 45 s después de arrancar: al encender, el sistema de
# impresión a veces todavía no está listo. Corre como ADMINISTRADOR (systemd),
# no como el cajero: hace falta para cargar los controladores del puerto
# paralelo y levantar CUPS. Auditoría 29-08-2026, fallo nº 3. Candado 45.
# El informe del equipo (la caja negra) se genera solo en cada arranque, un
# minuto después, cuando ya se sabe cómo fue todo. Candado 47.
# QRBott Actualiza — Nivel 1: parches de seguridad, solos, de madrugada.
# Evidencia del Wi-Fi en CADA arranque: qué conexiones ve la red al nacer.
# Tres veces se nos escapó este fallo por no tener este registro.
cat > /etc/systemd/system/qrbott-red-evidencia.service <<'SVC'
[Unit]
Description=Registro de lo que la red ve al arrancar (evidencia Wi-Fi)
After=NetworkManager.service
Wants=NetworkManager.service
[Service]
Type=oneshot
ExecStart=/bin/bash -c 'mkdir -p /var/qrbott-datos/caja; { echo "== arranque $(date)"; ls -la /var/qrbott-datos/red/ 2>&1; ls -la /etc/NetworkManager/system-connections 2>&1; sleep 8; nmcli -f NAME,TYPE,AUTOCONNECT connection show 2>&1; nmcli -f DEVICE,STATE device 2>&1; } >> /var/qrbott-datos/caja/red-arranque.log 2>&1; tail -c 100000 /var/qrbott-datos/caja/red-arranque.log > /tmp/ra.log && mv /tmp/ra.log /var/qrbott-datos/caja/red-arranque.log'
[Install]
WantedBy=multi-user.target
SVC

cat > /etc/systemd/system/qrbott-parches.service <<'SVC'
[Unit]
Description=Parches de seguridad automaticos de QRBott (nivel 1)
After=network-online.target
[Service]
Type=oneshot
ExecStart=/opt/qrbott/parches.sh
SVC

cat > /etc/systemd/system/qrbott-parches.timer <<'TMR'
[Unit]
Description=Buscar parches de seguridad cada madrugada
[Timer]
OnCalendar=*-*-* 03:30
RandomizedDelaySec=20min
[Install]
WantedBy=timers.target
TMR

# QRBott Actualiza — parches FIRMADOS desde la nube, sin reinstalar. Al
# encender (3 min después) y cada 30 min. También a mano desde Equipo.
# Candado 71.
cat > /etc/systemd/system/qrbott-actualiza.service <<'SVC'
[Unit]
Description=QRBott Actualiza: buscar y aplicar un parche firmado
After=network-online.target qrbott-persistencia.service qrbott-asistente-red.service
Wants=qrbott-persistencia.service
[Service]
Type=oneshot
ExecStart=/opt/qrbott/actualizar.sh
TimeoutStartSec=30min
SVC

cat > /etc/systemd/system/qrbott-actualiza.timer <<'TMR'
[Unit]
Description=Buscar parches firmados de QRBott cada 30 minutos
[Timer]
OnBootSec=3min
OnUnitActiveSec=30min
[Install]
WantedBy=timers.target
TMR
chmod +x "$DIR"/actualizar.sh
chmod 644 "$DIR"/actualiza.pub "$DIR"/actualiza.conf

cat > /etc/systemd/system/qrbott-informe.service <<'SVC'
[Unit]
Description=Informe del equipo de QRBott (caja negra)
[Service]
Type=oneshot
ExecStart=/opt/qrbott/informe.sh
SVC

cat > /etc/systemd/system/qrbott-informe.timer <<'TMR'
[Unit]
Description=Generar el informe del equipo poco despues de arrancar
[Timer]
OnBootSec=90s
AccuracySec=10s
[Install]
WantedBy=timers.target
TMR

cat > /etc/systemd/system/qrbott-impresora-reintento.service <<'SVC'
[Unit]
Description=Segundo intento de registrar la impresora de QRBott
[Service]
Type=oneshot
ExecStart=/opt/qrbott/impresora.sh
SVC

cat > /etc/systemd/system/qrbott-impresora-reintento.timer <<'TMR'
[Unit]
Description=Reintentar la impresora poco despues de arrancar
[Timer]
OnBootSec=45s
AccuracySec=5s
[Install]
WantedBy=timers.target
TMR

cat > /etc/systemd/system/qrbott-impresora.service <<'SVC'
[Unit]
Description=Registrar la impresora térmica de QRBott POS
After=cups.service network.target
Wants=cups.service
[Service]
Type=oneshot
ExecStart=/opt/qrbott/impresora.sh
RemainAfterExit=yes
[Install]
WantedBy=multi-user.target
SVC

# ---------- 5. Logo al arrancar ----------
if [ -f "$DIR/logo.png" ]; then
  mkdir -p /usr/share/plymouth/themes/qrbott
  cp "$DIR/logo.png" /usr/share/plymouth/themes/qrbott/logo.png
  # El pie: la marca del sistema operativo, PEQUEÑA y abajo. La grande del
  # centro es QRBott, que es lo que el cliente compró; Possum OS es el motor
  # y va como «powered by». Candado 86.
  [ -f "$DIR/arranque-pie.png" ] && cp "$DIR/arranque-pie.png" /usr/share/plymouth/themes/qrbott/pie.png
  cat > /usr/share/plymouth/themes/qrbott/qrbott.plymouth <<'PLY'
[Plymouth Theme]
Name=QRBott POS
ModuleName=script
[script]
ImageDir=/usr/share/plymouth/themes/qrbott
ScriptFile=/usr/share/plymouth/themes/qrbott/qrbott.script
PLY
  cat > /usr/share/plymouth/themes/qrbott/qrbott.script <<'PLS'
logo.image = Image("logo.png");
logo.sprite = Sprite(logo.image);
logo.sprite.SetX(Window.GetWidth()/2 - logo.image.GetWidth()/2);
logo.sprite.SetY(Window.GetHeight()/2 - logo.image.GetHeight()/2);

pie.image = Image("pie.png");
pie.sprite = Sprite(pie.image);
pie.sprite.SetX(Window.GetWidth()/2 - pie.image.GetWidth()/2);
pie.sprite.SetY(Window.GetHeight() - pie.image.GetHeight() - 40);
PLS
  update-alternatives --install /usr/share/plymouth/themes/default.plymouth default.plymouth \
    /usr/share/plymouth/themes/qrbott/qrbott.plymouth 200 || true
  update-initramfs -u 2>/dev/null || true
fi
# El guardián de red no puede arrancar antes de que exista su carpeta de
# claves (vive en el disco de datos). Candado 61.
mkdir -p /etc/systemd/system/NetworkManager.service.d
cat > /etc/systemd/system/NetworkManager.service.d/qrbott.conf <<'NM'
[Unit]
RequiresMountsFor=/var/qrbott-datos
# La red arranca DESPUÉS de que persistencia siembre /var/qrbott-datos/netplan
# (auditoría v13, fallo 29). Candado 70.
After=qrbott-persistencia.service
Wants=qrbott-persistencia.service
NM

# ---------- Arranque RÁPIDO y LIMPIO (candado 62) ----------
# La foto del dueño: menú azul de GRUB 30 segundos + logo 2 MINUTOS.
# - El menú de 30s sale cuando GRUB cree que el arranque anterior falló
#   (recordfail): en una caja que se apaga cortando, pasa siempre.
# - Los 2 minutos eran systemd-networkd-wait-online, un espera-red que NO
#   usamos (la red la lleva NetworkManager) y que muere por su propio tope.
mkdir -p /etc/default/grub.d
cat > /etc/default/grub.d/qrbott.cfg <<'GR'
GRUB_DISTRIBUTOR="QRBott POS"
GRUB_TIMEOUT=1
GRUB_TIMEOUT_STYLE=hidden
GRUB_RECORDFAIL_TIMEOUT=1
GRUB_CMDLINE_LINUX_DEFAULT="quiet splash loglevel=0 vt.global_cursor_default=0"
GR
sed -i 's/^GRUB_CMDLINE_LINUX_DEFAULT=.*/GRUB_CMDLINE_LINUX_DEFAULT="quiet splash loglevel=0"/' /etc/default/grub || true
sed -i 's/^GRUB_TIMEOUT=.*/GRUB_TIMEOUT=1/' /etc/default/grub || true
update-grub >>/var/log/qrbott-instalar.log 2>&1 || echo "AVISO: update-grub falló" >> /var/log/qrbott-instalar.log

# Fuera el espera-red ajeno (2 minutos de logo mirando al techo):
systemctl disable systemd-networkd-wait-online.service >>/var/log/qrbott-instalar.log 2>&1
systemctl mask systemd-networkd-wait-online.service >>/var/log/qrbott-instalar.log 2>&1
systemctl disable systemd-networkd.service >>/var/log/qrbott-instalar.log 2>&1

# ---------- 6. Actualizaciones de seguridad sin romper el kiosco ----------
cat > /etc/apt/apt.conf.d/52qrbott <<'UPD'
Unattended-Upgrade::Automatic-Reboot "false";
Unattended-Upgrade::Allowed-Origins { "${distro_id}:${distro_codename}-security"; };
UPD

# ---------- 6b. MARCA PROPIA (Possum OS) ----------
[ -x "$DIR/marca.sh" ] && bash "$DIR/marca.sh" || true

# ---------- 6c. ROBUSTEZ (cortes de luz + mantenimiento) ----------
[ -x "$DIR/robustez.sh" ] && bash "$DIR/robustez.sh" || true

# ---------- 7. Servicios ----------
# ACTIVAR LOS SERVICIOS, Y QUE SE SEPA SI ALGUNO NO SE ACTIVA.
# Antes esto era «systemctl enable X 2>/dev/null || true» cinco veces: si uno
# fallaba, NADIE se enteraba. Es exactamente el fallo que escondió durante seis
# versiones que el sistema de impresión no arrancaba (candado 37) y yo lo había
# dejado puesto en otros cinco sitios. Auditoría 29-08-2026, fallo nº 2.
# Candado 44.
FALLOS_SERVICIOS=""
for sv in qrbott-asistente-red qrbott-persistencia qrbott-caja \
          qrbott-diagnostico qrbott-impresora qrbott-red-evidencia; do
  if systemctl enable "$sv.service" >>/var/log/qrbott-instalar.log 2>&1; then
    echo "servicio activado: $sv"
  else
    echo "!! NO SE PUDO ACTIVAR EL SERVICIO: $sv"
    FALLOS_SERVICIOS="$FALLOS_SERVICIOS $sv"
  fi
done
for tm in qrbott-impresora-reintento qrbott-informe qrbott-parches qrbott-actualiza; do
  systemctl enable "$tm.timer" >>/var/log/qrbott-instalar.log 2>&1 \
    || FALLOS_SERVICIOS="$FALLOS_SERVICIOS $tm.timer"
done

if [ -n "$FALLOS_SERVICIOS" ]; then
  echo "ERROR:servicios-sin-activar:$FALLOS_SERVICIOS" > /opt/qrbott/estado-servicios
  echo "!! Estos servicios NO quedaron activados:$FALLOS_SERVICIOS"
else
  echo "OK:todos-activados" > /opt/qrbott/estado-servicios
fi
systemctl enable cups.service cups.socket 2>>/var/log/qrbott-instalar.log \
  || echo "AVISO: no se pudo activar el sistema de impresión" >> /var/log/qrbott-instalar.log
systemctl enable NetworkManager >>/var/log/qrbott-instalar.log 2>&1 \
  || { echo "!! NO SE PUDO ACTIVAR LA RED (NetworkManager)"
       echo "ERROR:sin-networkmanager" >> /opt/qrbott/estado-servicios; }
systemctl set-default multi-user.target 2>/dev/null || true

# ---------- 8. CANARIO: comprobar que la caja de verdad puede arrancar ----------
# Si algo de esto falta, el equipo arrancaría en una consola negra. No puede
# fallar en silencio: queda escrito y se ve en la pantalla de mantenimiento.
fallos=""
for f in /opt/qrbott/caja.sh /opt/qrbott/xinitrc /opt/qrbott/identidad.sh \
         /opt/qrbott/asistente-red.py /opt/qrbott/pantallas-tactil.sh \
         /opt/qrbott/montar-usb.sh /opt/qrbott/barra-modo.sh \
         /opt/qrbott/informe.sh /opt/qrbott/carpetas.sh /opt/qrbott/parches.sh \
         /opt/qrbott/persistencia.sh /opt/qrbott/sal \
         /etc/systemd/system/qrbott-caja.service \
         /etc/systemd/system/qrbott-persistencia.service; do
  [ -s "$f" ] || fallos="$fallos falta:$f"
done
for c in Xorg xinit openbox chromium onboard; do
  command -v "$c" >/dev/null 2>&1 || fallos="$fallos sin-programa:$c"
done
systemctl is-enabled qrbott-caja.service >/dev/null 2>&1 || fallos="$fallos servicio-no-activado"
# El navegador tiene que ser el DE VERDAD. /usr/bin/chromium es solo un lanzador
# de 5 KB; el motor está en /usr/lib/chromium/chromium (>300 MB). El paquete de
# transición de Ubuntu no trae motor: por eso la caja abría en negro.
motor=$(ls -l /usr/lib/chromium/chromium 2>/dev/null | awk '{print $5}')
[ -n "$motor" ] && [ "$motor" -gt 50000000 ] || fallos="$fallos navegador-sin-motor"
id pos >/dev/null 2>&1 || echo "  (el usuario pos aún no existe: lo crea el primer arranque, es normal)"

if [ -n "$fallos" ]; then
  echo "!! LA CAJA NO PODRÁ ARRANCAR:$fallos"
  echo "ERROR:$fallos" > /opt/qrbott/estado-caja
else
  echo "== Caja lista: al reiniciar arranca sola a pantalla completa. =="
  echo "OK" > /opt/qrbott/estado-caja
fi

exit 0   # nunca tumbar la instalación
