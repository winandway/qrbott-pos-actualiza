#!/bin/bash
# ============================================================
#  Possum OS — lo que el dueño configura NO se puede perder
#  Corre en CADA arranque, antes de abrir la caja.
#
#  El disco raíz va en solo lectura (aguanta cortes de luz), así que todo lo
#  que se escriba ahí se pierde al apagar. Lo que SÍ debe sobrevivir vive en la
#  partición QRBOTTDATA, montada en /var/qrbott-datos:
#     · el Wi-Fi de la tienda
#     · la sesión del punto de venta (el dueño entra UNA vez, no cada mañana)
#     · la impresora registrada
#     · la identidad del equipo y su clave de soporte
#  Ver CANDADOS.md nº 12.
# ============================================================
set -uo pipefail
D=/var/qrbott-datos
LOG=/var/log/qrbott-persistencia.log
exec > >(tee -a "$LOG") 2>&1
echo "== $(date) preparando la zona de datos =="

# ---------- 1. ¿Está la zona de datos? ----------
if ! mountpoint -q "$D"; then
  # Un último intento por etiqueta (por si el disco tardó en aparecer)
  mkdir -p "$D"; mount -L QRBOTTDATA "$D" 2>/dev/null
fi
if ! mountpoint -q "$D"; then
  echo "!! NO hay zona de datos: el equipo OLVIDARÁ lo que configure el dueño."
  echo "ERROR:sin-zona-de-datos" > /opt/qrbott/estado-datos
  exit 0     # que la caja abra igual; el aviso queda escrito y en el diagnóstico
fi
echo "OK" > /opt/qrbott/estado-datos

# ---------- 2. Crecer al tamaño real del disco (fábrica: se clona en SSD mayores) ----------
# Al clonar la imagen en un disco más grande, la partición de datos se queda
# chiquita. growpart la estira y resize2fs agranda el sistema de archivos.
DEV=$(findmnt -no SOURCE "$D" 2>/dev/null)
if [ -n "$DEV" ]; then
  DISCO=$(lsblk -no PKNAME "$DEV" 2>/dev/null | head -1)
  NUM=$(echo "$DEV" | grep -o '[0-9]*$')
  if [ -n "$DISCO" ] && [ -n "$NUM" ]; then
    growpart "/dev/$DISCO" "$NUM" 2>&1 | grep -v NOCHANGE || true
    resize2fs "$DEV" 2>&1 | tail -1 || true
  fi
fi

# ---------- 3. Carpetas que sobreviven ----------
mkdir -p "$D"/caja/chrome "$D"/red "$D"/cups "$D"/netplan
# netplan: la carpeta real de las conexiones (candado 70). Se siembra con la
# base de fábrica la primera vez, y queda a nombre de root con permisos
# privados (netplan exige 600 en sus YAML).
[ -z "$(ls -A "$D"/netplan 2>/dev/null)" ] && cp -a /usr/share/qrbott/netplan-base/. "$D"/netplan/ 2>/dev/null
chown -R root:root "$D"/netplan 2>/dev/null; chmod 700 "$D"/netplan 2>/dev/null
chmod 600 "$D"/netplan/*.yaml 2>/dev/null
# la primera vez, la impresora parte de la configuración que trajo el sistema
[ -z "$(ls -A "$D"/cups 2>/dev/null)" ] && cp -a /usr/share/qrbott/cups-base/. "$D"/cups/ 2>/dev/null
if id pos >/dev/null 2>&1; then
  chown -R pos:pos "$D"/caja || echo "!! no se pudo dar la carpeta al usuario pos"
else
  echo "!! el usuario pos aún no existe: la carpeta la ajusta el servicio de la caja"
fi
chmod 700 "$D"/red 2>/dev/null          # NetworkManager exige que sea privada

# ---------- 4. Identidad propia (al clonar, todos nacían iguales) ----------
if [ -s "$D"/machine-id ]; then
  cp "$D"/machine-id /etc/machine-id
else
  systemd-machine-id-setup >/dev/null 2>&1
  cp /etc/machine-id "$D"/machine-id 2>/dev/null
fi

# ---------- 5. Clave de soporte PROPIA DE ESTE EQUIPO ----------
# Antes era la misma en todas las máquinas del mundo: una sola clave las abría
# todas. Ahora se calcula con el número de serie del equipo, así que cada una
# tiene la suya. Soporte la obtiene con  os/clave-soporte.sh <serie>.
SERIE=$(/opt/qrbott/identidad.sh 2>/dev/null)
SAL=$(cat /opt/qrbott/sal 2>/dev/null)
if [ -n "$SERIE" ] && [ -n "$SAL" ]; then
  CLAVE=$(printf 'QRBOTT|%s|%s' "$SAL" "$SERIE" | sha256sum | cut -c1-12)
  echo "pos:$CLAVE" | chpasswd 2>/dev/null && echo "clave de soporte propia aplicada"
fi

# ---------- 6. El número de serie, visible para soporte ----------
{ echo; echo "  Possum OS 1.0   ·   equipo: ${SERIE:-desconocido}"
  echo "  Soporte: https://qrbott.com/soporte"; echo; } > /etc/issue.d/qrbott.issue 2>/dev/null

echo "== zona de datos lista =="
exit 0
