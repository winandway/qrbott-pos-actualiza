#!/bin/bash
# ============================================================
#  QRBott POS — sistema de impresión e impresora de tickets
#
#  LA CAUSA REAL (encontrada el 29-08-2026 en la pantalla "Estado del equipo"
#  del equipo del cliente): decía «lpstat: Scheduler is not running» y
#  «lpinfo: Bad file descriptor». O sea: EL SISTEMA DE IMPRESIÓN NO ESTABA
#  CORRIENDO. No era que no viera la impresora — era que el motor estaba
#  apagado. Se buscó la impresora durante días con CUPS caído.
#
#  Por qué estaba caído: el instalador hacía «systemctl enable cups || true»,
#  que se calla si falla, y el servicio de la impresora decía
#  «Requires=cups.service», así que si CUPS no arrancaba nuestro servicio
#  tampoco corría. Dos fallos en silencio, uno encima del otro.
#
#  Ahora: se levanta A LA FUERZA, y si no se puede, se DICE POR QUÉ.
#  Ver CANDADOS.md nº 37.
# ============================================================
set -uo pipefail
INFO=/opt/qrbott/estado-impresora
LOG=/var/qrbott-datos/caja/impresora.log
mkdir -p /var/qrbott-datos/caja 2>/dev/null

# Solo UNO a la vez. En el equipo real corrieron DOS con 5 segundos de
# diferencia (el servicio y la regla de udev), se pisaron entre sí al registrar
# la impresora y tumbaron el motor. Informe del 30-08-2026. Candado 51.
exec 8>/var/lock/qrbott-impresora.lock
flock -n 8 || exit 0

{ echo "== $(date) sistema de impresión =="

# ---- 1. Levantar CUPS a la fuerza. Sin esto NADA de lo demás sirve. ----
# DESBLOQUEAR PRIMERO: cuando el motor se cae 5 veces seguidas, el sistema lo
# bloquea y un «start» normal falla PARA SIEMPRE hasta hacer reset-failed. Por
# eso el botón «Reintentar» del dueño no hacía nada. Candado 51.
# Sanación: si /etc/cups quedó como ENLACE (versiones viejas), se restaura la
# carpeta real — AppArmor no deja a cupsd leer a través del enlace. Candado 55.
if [ -L /etc/cups ]; then
  rm -f /etc/cups
  cp -a /usr/share/qrbott/cups-base /etc/cups 2>/dev/null || mkdir -p /etc/cups
  echo "   /etc/cups era un enlace: restaurado como carpeta real"
fi
systemctl reset-failed cups.service cups.socket cups.path 2>/dev/null
systemctl unmask cups.service cups.socket cups.path 2>&1 | sed 's/^/   /'
systemctl enable cups.service cups.socket 2>&1 | sed 's/^/   /'
systemctl stop cups.service cups.socket 2>/dev/null
sleep 1
systemctl start cups.socket 2>&1 | sed 's/^/   /'
systemctl start cups.service 2>&1 | sed 's/^/   /'

# ---- 1b. ¿Por qué se cae, si se cae? Que quede ESCRITO. ----
echo "-- prueba de configuración del motor (cupsd -t):"
/usr/sbin/cupsd -t 2>&1 | sed 's/^/   /'
echo "-- últimas líneas del registro propio del motor:"
tail -15 /var/log/cups/error_log 2>/dev/null | sed 's/^/   /' || echo "   (sin registro)"
echo "-- bloqueos de seguridad (AppArmor):"
dmesg 2>/dev/null | grep -i "denied" | grep -i cups | tail -5 | sed 's/^/   /' || true

VIVO=no
for i in $(seq 1 20); do
  if lpstat -r 2>/dev/null | grep -qi "is running"; then VIVO=si; break; fi
  sleep 2
done

if [ "$VIVO" != "si" ]; then
  echo "!! EL SISTEMA DE IMPRESIÓN NO ARRANCA. Sin él no hay impresora posible."
  {
    echo "ERROR:cups-no-arranca"
    systemctl is-enabled cups.service 2>&1 | sed 's/^/enable:/'
    systemctl is-active  cups.service 2>&1 | sed 's/^/activo:/'
  } > "$INFO"
  systemctl status cups.service --no-pager -l 2>&1 | head -20 | sed 's/^/   /'
  journalctl -u cups.service -n 20 --no-pager 2>&1 | sed 's/^/   /'
  exit 0
fi
echo "OK el sistema de impresión está corriendo"

# ---- 2. Encender el puerto paralelo. La impresora de este equipo vive AHÍ.
#         (POS58 integrada en el chasis, por LPT1. Ver hardware/EQUIPO-01.md)
for m in parport parport_pc lp ppdev; do modprobe "$m" 2>&1 | sed 's/^/   /'; done
sleep 2
echo "-- puerto paralelo:"
ls -l /dev/lp* /dev/parport* 2>/dev/null | sed 's/^/   /' || echo "   no aparece ningún /dev/lp*"
dmesg 2>/dev/null | grep -i -E "parport|lp[0-9]" | tail -6 | sed 's/^/   /'

# ---- 3. Ahora sí, buscar la impresora ----
echo "-- lo que ve el sistema de impresión:"
lpinfo -v 2>&1 | sed 's/^/   /'
# ORDEN IMPORTANTE: el paralelo primero. Sabemos por el escaneo del equipo
# (hardware/EQUIPO-01.md) que la impresora integrada está en LPT1.
URI=""
for d in /dev/lp0 /dev/lp1; do
  [ -e "$d" ] && { URI="file:$d"; echo "   impresora integrada en el puerto paralelo: $d"; break; }
done
[ -z "$URI" ] && URI=$(lpinfo -v 2>/dev/null | grep -E "^direct parallel:|^direct usb://|^direct hp|^serial serial:" | head -1 | awk '{print $2}')

if [ -z "$URI" ]; then
  echo "-- aparatos presentes:"
  ls -l /dev/usb/lp* /dev/lp* /dev/ttyUSB* /dev/ttyS[0-3] /dev/parport* 2>/dev/null | sed 's/^/   /'
  for d in /dev/usb/lp0 /dev/usb/lp1 /dev/ttyUSB0 /dev/ttyS0 /dev/ttyS1; do
    [ -e "$d" ] || continue
    case "$d" in
      /dev/ttyS*|/dev/ttyUSB*) URI="serial:$d?baud=9600+bits=8+parity=none+flow=none" ;;
      *)                       URI="file:$d" ;;
    esac
    echo "   elegido a mano: $d"; break
  done
fi

if [ -z "$URI" ]; then
  echo "!! El sistema de impresión SÍ funciona, pero no hay ninguna impresora conectada."
  echo "ERROR:sin-impresora" > "$INFO"
  echo "-- pistas USB:"; lsusb 2>&1 | sed 's/^/   /'
  exit 0
fi

# ---- 3. Registrarla en modo RAW (los tickets térmicos hablan ESC/POS) ----
lpadmin -x QRBott-Ticket 2>/dev/null
if [ -f /opt/qrbott/qrbott58.ppd ] && [ -x /usr/lib/cups/filter/qrbott-pdf-a-escpos ]; then
  # CON nuestro driver: el diálogo del navegador imprime de verdad. Candado 59.
  lpadmin -p QRBott-Ticket -E -v "$URI" -P /opt/qrbott/qrbott58.ppd -o printer-is-shared=false 2>&1 | sed 's/^/   /'
else
  echo "   AVISO: falta el driver; se registra en crudo (el diálogo no podrá imprimir)"
  lpadmin -p QRBott-Ticket -E -v "$URI" -m raw -o printer-is-shared=false 2>&1 | sed 's/^/   /'
fi
lpadmin -d QRBott-Ticket 2>/dev/null
cupsenable QRBott-Ticket 2>/dev/null
cupsaccept QRBott-Ticket 2>/dev/null

if lpstat -p QRBott-Ticket >/dev/null 2>&1; then
  echo "OK impresora registrada: $URI"
  echo "OK:$URI" > "$INFO"
else
  echo "!! no se pudo registrar: $URI"
  echo "ERROR:no-se-registro:$URI" > "$INFO"
fi
} 2>&1 | tee -a "$LOG" 2>/dev/null || true

# ---- 4. Las impresoras que AGREGÓ el dueño (gestor de impresoras) ----
# El registro de CUPS vive en la capa volátil: al apagar se pierde. Por eso
# cada impresora agregada queda anotada en el disco de datos y aquí se vuelve
# a registrar en cada arranque. Candado 79.
EXTRA=/var/qrbott-datos/impresoras.json
if [ -s "$EXTRA" ] && command -v python3 >/dev/null 2>&1; then
  python3 - "$EXTRA" <<'PY2' 2>&1 | while read -r linea; do
import json, sys, subprocess, re
try:
    lista = json.load(open(sys.argv[1]))
except Exception as e:
    print("!! impresoras.json ilegible:", e); sys.exit(0)
for e in lista if isinstance(lista, list) else []:
    n, uri, tipo = str(e.get("nombre", "")), str(e.get("uri", "")), str(e.get("tipo", ""))
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,32}", n) or not uri.startswith(("usb://", "parallel:", "serial:", "hp:")):
        print("!! entrada rara ignorada:", n); continue
    if tipo == "termica58":
        args = ["lpadmin", "-p", n, "-E", "-v", uri, "-P", "/opt/qrbott/qrbott58.ppd", "-o", "printer-is-shared=false"]
    else:
        args = ["lpadmin", "-p", n, "-E", "-v", uri, "-m", "raw", "-o", "printer-is-shared=false"]
    r = subprocess.run(args, capture_output=True, text=True)
    print(("OK agregada de nuevo: " if r.returncode == 0 else "!! no se pudo registrar: ") + n + " " + (r.stderr or "").strip()[:120])
    subprocess.run(["cupsenable", n], capture_output=True); subprocess.run(["cupsaccept", n], capture_output=True)
    if e.get("predeterminada"):
        subprocess.run(["lpadmin", "-d", n], capture_output=True); print("   predeterminada:", n)
PY2
    echo "   $linea"
  done
fi
exit 0

