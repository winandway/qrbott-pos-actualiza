#!/bin/bash
# ============================================================
#  QRBott Actualiza — parches FIRMADOS desde la nube (nivel 1.5)
#
#  POR QUÉ (pedido por el dueño, 1-09-2026): cada arreglo obligaba a bajar una
#  ISO, flashear un USB y reinstalar el equipo. Con esto, el equipo BUSCA solo
#  un parche (cada 30 min y al encender, o al tocar «Buscar actualización» en
#  Equipo), comprueba que lo firmamos NOSOTROS (llave Ed25519: la privada vive
#  solo en la máquina del programador; aquí va la pública), comprueba la huella
#  del paquete, lo escribe en el DISCO REAL (debajo de la protección) y en el
#  sistema vivo, y se VIGILA: si después del parche el asistente no contesta,
#  vuelve solo a la versión anterior. Candado 71.
#
#  Lo que NO hace: no cambia el sistema base (kernel, paquetes) — eso es el
#  nivel 2 (imagen completa A/B, partición gemela). Ver ACTUALIZACIONES-PLAN.md.
#
#  Estado (lo enseñan Equipo y el informe): /opt/qrbott/estado-actualiza
#    AL-DIA:<v>  ACTUALIZADO:<v>  REVERTIDO:<v>  SIN-RED-O-CANAL:<v>
#    FIRMA-INVALIDA:<v>  REQUIERE-ISO:<v>  DESCARGA-FALLO / APLICAR-FALLO ...
#  Registro: /var/qrbott-datos/caja/actualiza.log
# ============================================================
set -uo pipefail
export PATH=/usr/sbin:/sbin:/usr/bin:/bin
INFO=/opt/qrbott/estado-actualiza
LOG=/var/qrbott-datos/caja/actualiza.log
PUB=/opt/qrbott/actualiza.pub
CONF=/opt/qrbott/actualiza.conf
CANAL_PROPIO=/var/qrbott-datos/caja/actualiza-canal   # una línea: otra URL (soporte / pruebas)
RAIZ=/media/root-ro

exec 7>/tmp/qrbott-actualiza.lock
flock -n 7 || { echo "ya hay una actualización en curso"; exit 0; }
mkdir -p "$(dirname "$LOG")" 2>/dev/null
log()    { echo "$(date '+%F %T') $*" | tee -a "$LOG" >&2; }
estado() { echo "$1" > "$INFO"; log "estado: $1"; }

ACTUAL=$(cat /opt/qrbott/version 2>/dev/null || echo "0000-00-00-0000")
# Si el disco real quedó escribible de una vez anterior (o este es el reintento
# programado), se protege AQUÍ y el estado deja de decir SIN-PROTEGER.
if grep -qE " $RAIZ [^ ]+ rw," /proc/mounts; then
  sync
  if mount -o remount,ro "$RAIZ" 2>>"$LOG"; then
    log "el disco real estaba SIN proteger: protegido otra vez${1:+ ($1)}"
    sed -i 's/^ACTUALIZADO-SIN-PROTEGER:/ACTUALIZADO:/' "$INFO" 2>/dev/null
  else
    log "!! el disco real sigue sin proteger${1:+ ($1)}"
    [ "${1:-}" = "proteger" ] && systemd-run --quiet --on-active=300 --unit=qrbott-proteger "/opt/qrbott/actualizar.sh" proteger 2>>"$LOG"
  fi
fi
[ "${1:-}" = "proteger" ] && exit 0
CANAL_URL=""
[ -r "$CONF" ] && . "$CONF"
[ -s "$CANAL_PROPIO" ] && CANAL_URL=$(head -1 "$CANAL_PROPIO" | tr -d '[:space:]')
[ -n "$CANAL_URL" ] || { estado "SIN-CANAL:$ACTUAL"; exit 0; }
[ -r "$PUB" ] || { estado "SIN-LLAVE-PUBLICA:$ACTUAL"; exit 1; }

T=$(mktemp -d /tmp/qrbott-act-XXXX); trap 'rm -rf "$T"' EXIT
bajar() { curl -sfL -m "${3:-30}" --retry 2 -o "$2" "$CANAL_URL/$1"; }
proteger() {
  # Volver a dejar el disco real solo-lectura. Justo después de escribir
  # puede dar "mount point is busy" (visto en la VM, solo en el PRIMER parche
  # tras encender): se reintenta un minuto; si sigue, queda escrito quién lo
  # tiene abierto, el estado lo dice SIN maquillar, y systemd vuelve a
  # intentarlo solo a los 3 minutos (y en cada pasada del temporizador).
  local i
  for i in $(seq 1 30); do
    sync
    mount -o remount,ro "$RAIZ" 2>>"$LOG" && { log "disco real protegido otra vez"; return 0; }
    sleep 2
  done
  log "!! el disco real NO se pudo volver a proteger; evidencia:"
  { fuser -vm "$RAIZ"; ls -l /proc/[0-9]*/fd 2>/dev/null | grep -F "$RAIZ" | head; grep -F " $RAIZ " /proc/mounts; } >>"$LOG" 2>&1 || true
  systemd-run --quiet --on-active=180 --unit=qrbott-proteger "/opt/qrbott/actualizar.sh" proteger 2>>"$LOG" || true
  return 1
}

# 1. El manifiesto y su firma
bajar manifest.json     "$T/m.json" 20 || { estado "SIN-RED-O-CANAL:$ACTUAL"; exit 0; }
bajar manifest.json.sig "$T/m.sig"  20 || { estado "CANAL-SIN-FIRMA:$ACTUAL"; exit 1; }
if ! openssl pkeyutl -verify -pubin -inkey "$PUB" -rawin -in "$T/m.json" -sigfile "$T/m.sig" >/dev/null 2>&1; then
  estado "FIRMA-INVALIDA:$ACTUAL"
  log "!! el manifiesto NO está firmado con nuestra llave: se ignora por completo"
  exit 1
fi
LEIDO=$(python3 - "$T/m.json" <<'PY'
import json, sys, shlex, re
m = json.load(open(sys.argv[1]))
v = str(m.get("version", ""))
if not re.fullmatch(r"\d{4}-\d{2}-\d{2}-\d{4}", v): sys.exit(1)
a = str(m.get("archivo", ""))
if not re.fullmatch(r"[A-Za-z0-9._-]+", a): sys.exit(1)
h = str(m.get("sha256", ""))
if not re.fullmatch(r"[0-9a-f]{64}", h): sys.exit(1)
mi = str(m.get("minimo", "") or "")
print("NUEVA=%s ARCHIVO=%s SHA=%s MINIMO=%s" % (shlex.quote(v), shlex.quote(a), shlex.quote(h), shlex.quote(mi)))
PY
) || { estado "MANIFIESTO-ILEGIBLE:$ACTUAL"; exit 1; }
eval "$LEIDO"

# 2. ¿Hace falta?
if [[ ! "$NUEVA" > "$ACTUAL" ]]; then estado "AL-DIA:$ACTUAL"; exit 0; fi
if [ -n "$MINIMO" ] && [[ "$ACTUAL" < "$MINIMO" ]]; then
  estado "REQUIERE-ISO:$NUEVA"
  log "el parche $NUEVA exige tener al menos la $MINIMO; este equipo tiene la $ACTUAL: hace falta reinstalar"
  exit 0
fi
log "hay un parche: $ACTUAL -> $NUEVA ($ARCHIVO)"

# 3. Descargar y comprobar la huella
estado "DESCARGANDO:$NUEVA"
bajar "$ARCHIVO" "$T/p.tgz" 900 || { estado "DESCARGA-FALLO:$NUEVA"; exit 1; }
echo "$SHA  $T/p.tgz" | sha256sum -c --quiet 2>/dev/null || { estado "HUELLA-NO-COINCIDE:$NUEVA"; log "!! la huella del paquete no coincide: se descarta"; exit 1; }
mkdir "$T/p"
tar -xzf "$T/p.tgz" -C "$T/p" 2>>"$LOG" || { estado "PAQUETE-ROTO:$NUEVA"; exit 1; }
[ -f "$T/p/aplicar.sh" ] && [ -d "$T/p/archivos" ] || { estado "PAQUETE-INCOMPLETO:$NUEVA"; exit 1; }
[ "$(cat "$T/p/version" 2>/dev/null)" = "$NUEVA" ] || { estado "PAQUETE-VERSION-DISTINTA:$NUEVA"; exit 1; }

# 4. Aplicar: al disco real (debajo de la protección) Y al sistema vivo
estado "APLICANDO:$NUEVA"
mountpoint -q "$RAIZ" || { estado "SIN-DISCO-PROTEGIDO:$NUEVA"; exit 1; }
mount -o remount,rw "$RAIZ" || { estado "DISCO-NO-ESCRIBIBLE:$NUEVA"; exit 1; }
ANT="$RAIZ/opt/qrbott.anterior"
rm -rf "$ANT"; cp -a "$RAIZ/opt/qrbott" "$ANT"; mkdir -p "$ANT/_otros"
if RAIZ="$RAIZ" ANTERIOR_DIR="$ANT" NUEVA="$NUEVA" ANTERIOR="$ACTUAL" bash "$T/p/aplicar.sh" >>"$LOG" 2>&1; then
  echo "$NUEVA" > "$RAIZ/opt/qrbott/version"; echo "$NUEVA" > /opt/qrbott/version
  PROTEGIDO=1; proteger || PROTEGIDO=0
  # 5. Vigilancia: el asistente tiene 40 s para contestar
  ok=0
  for i in $(seq 1 40); do
    curl -sf -m 2 -o /dev/null http://127.0.0.1:7777/estado && { ok=1; break; }
    sleep 1
  done
  if [ "$ok" = 1 ]; then
    if [ "$PROTEGIDO" = 1 ]; then estado "ACTUALIZADO:$NUEVA"; else estado "ACTUALIZADO-SIN-PROTEGER:$NUEVA"; fi
    systemctl start qrbott-informe.service 2>/dev/null
    exit 0
  fi
  log "!! después del parche el asistente NO contesta: se REVIERTE a la $ACTUAL"
  mount -o remount,rw "$RAIZ"
  for r in "$RAIZ" ""; do
    rm -rf "$r/opt/qrbott"; cp -a "$ANT" "$r/opt/qrbott"; rm -rf "$r/opt/qrbott/_otros"
    [ -d "$ANT/_otros" ] && cp -a "$ANT/_otros/." "$r/" 2>>"$LOG"
  done
  echo "$ACTUAL" > "$RAIZ/opt/qrbott/version"; echo "$ACTUAL" > /opt/qrbott/version
  proteger || true
  systemctl daemon-reload; systemctl restart qrbott-asistente-red.service
  estado "REVERTIDO:$NUEVA"
  exit 1
else
  proteger || true
  estado "APLICAR-FALLO:$NUEVA"
  exit 1
fi
