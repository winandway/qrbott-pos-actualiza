#!/bin/bash
# Lanza la caja QRBott a pantalla completa.
# --kiosk-printing: cuando el POS pide imprimir, sale DIRECTO a la impresora
# predeterminada (QRBott-Ticket), sin el diálogo «Print» que se congelaba y
# que el cajero no podía cerrar sin perder la venta. Informe de campo 1-09-2026
# (fotos). Candado 72.
# Todo lo que diga el navegador queda escrito: si un día no abre, el motivo
# está aquí y el autodiagnóstico lo enseña. Nunca falla en silencio.
# Si por lo que sea no se puede escribir el registro, la caja abre igual:
# antes, este redirección fallaba y MATABA la caja antes de arrancar.
REG=/var/qrbott-datos/caja/caja.log
touch "$REG" 2>/dev/null || REG=/tmp/qrbott-caja.log
exec > >(tee -a "$REG") 2>&1
echo "== $(date) arrancando la caja =="
export DISPLAY=:0

# CANARIO: si falta el navegador, avisar EN PANTALLA (nunca quedarse en negro)
if ! command -v chromium >/dev/null 2>&1 || [ ! -s /usr/lib/chromium/chromium ]; then
  P=/opt/qrbott/pantallas/error-caja.png
  if command -v fbi >/dev/null 2>&1 && [ -f "$P" ]; then
    fbi -T 1 -d /dev/fb0 -noverbose -a "$P" >/dev/null 2>&1
  else
    echo "QRBott: falta el navegador. Consola de mantenimiento: Ctrl+Alt+F2" > /dev/tty1
  fi
  sleep 3600
  exit 1
fi

setxkbmap us 2>/dev/null || true      # teclado americano en la pantalla
# Autorizar al ADMINISTRADOR en esta pantalla, por identidad local (no abre
# nada a la red). Sin esto, barra-modo.sh (que corre como root desde el
# servicio) no puede mover ventanas con xdotool, y el informe no puede leer
# xrandr/glxinfo: la tuerquita quedaba MUDA. Auditoría 2ª vuelta, fallos 16 y
# 17. Candado 49.
xhost +si:localuser:root 2>/dev/null || true
# Acceso directo a la carpeta del dueño (aquí el usuario ya existe de verdad)
ln -sfn "/var/qrbott-datos/Mis archivos" "$HOME/Mis archivos" 2>/dev/null || true
# Pantallas y táctil: una sola pantalla activa y el táctil amarrado a ella.
[ -x /opt/qrbott/pantallas-tactil.sh ] && /opt/qrbott/pantallas-tactil.sh || true
xset s off; xset -dpms; xset s noblank          # que la pantalla nunca se apague
unclutter -idle 8 &        # el puntero se esconde solo tras 8s sin usarlo,
                           # y reaparece al mover el ratón
# Teclado en pantalla: sale SOLO cuando se toca una casilla de texto, acoplado
# abajo, y sin el botoncito flotante que tapaba la tuerquita. Antes se abría
# siempre y se comía media pantalla. Lo destapó la prueba en la máquina
# virtual. Auditoría, fallo nº 12. Candado 48.
# Sin esto, onboard saca un diálogo «Enable accessibility now?» ENCIMA de la
# caja en el primer arranque. Se responde por adelantado. Candado 63.
gsettings set org.gnome.desktop.interface toolkit-accessibility true 2>/dev/null || true
gsettings set org.onboard.auto-show enabled true            2>/dev/null || true
gsettings set org.onboard start-minimized true              2>/dev/null || true
gsettings set org.onboard.icon-palette in-use false         2>/dev/null || true
gsettings set org.onboard.window docking-enabled true       2>/dev/null || true
gsettings set org.onboard.window window-decoration false    2>/dev/null || true
onboard --startup-delay=3 &

# (El ESCRITORIO con la marca lo pinta el propio menu (menu-inicio.py), en
#  una ventana de la capa «escritorio» siempre por debajo de todo: pcmanfm
#  solo pintaba el color, nunca la imagen. Candado 85.)                      # teclado en pantalla, a demanda


SERIAL=$(/opt/qrbott/identidad.sh)
NOMBRE=$(cat /opt/qrbott/nombre-equipo 2>/dev/null || echo "Terminal ${SERIAL: -4}")
VER=$(cat /opt/qrbott/version 2>/dev/null || echo "1.0.0")
URL_POS="https://pos.qrbott.com/pos?shell=linux&serial=${SERIAL}&v=${VER}&nombre=$(echo "$NOMBRE" | sed 's/ /%20/g')"
# Se la dejamos escrita al servicio local: es la que usará nuestra pantalla para
# saltar al punto de venta. Sin «shell=linux» el POS no reserva los 52 px de la
# barra del sistema y nuestra barra le taparía botones. Candado 42.
# OJO: esto corre como el CAJERO, que no puede escribir en /opt/qrbott. Va al
# disco de datos, que sí es suyo. Lo destapó la prueba en la máquina virtual:
# «/opt/qrbott/url-caja: Permission denied». Auditoría, fallo nº 11. Candado 48.
mkdir -p /var/qrbott-datos/caja 2>/dev/null
echo "$URL_POS" > /var/qrbott-datos/caja/url-caja

# Si el equipo todavía no tiene internet (primer arranque en la tienda), se abre
# NUESTRO asistente de conexión, con la marca y en tres idiomas. Cuando conecta,
# él mismo lleva al punto de venta. Antes salía una ventana de sistema morada
# con un <Quit> en inglés. Ver CANDADOS.md nº 20.
# La caja abre SIEMPRE en nuestra propia pantalla, que decide sola y en todo
# momento: si hay internet salta al punto de venta; si no, muestra "No hay
# conexión" con un botón grande para conectarse, y salta sola en cuanto conecta.
# Antes se decidía UNA SOLA VEZ al arrancar: si fallaba, el dueño quedaba en una
# página muerta, sin login (que vive en la nube) y sin forma de conectarse — solo
# le quedaba reinstalar. Ver CANDADOS.md nº 40.
for i in 1 2 3 4 5 6 7 8 9 10; do
  curl -sf -m 2 -o /dev/null http://127.0.0.1:7777/estado && break; sleep 1
done
URL="http://127.0.0.1:7777/caja"

# La caja abre igual aunque no haya internet (usa lo guardado).

# ---- Sitio reservado para la barra de abajo ----
# Antes la barra era una ventana flotante y el punto de venta la tapaba. Ahora
# la caja se queda con la pantalla MENOS 52 px, y esos 52 px son de la barra.
ALTO_BARRA=52
LADO_TUERCA=44
GEO=$(xrandr 2>/dev/null | awk '/\*/{print $1; exit}')
ANCHO=${GEO%x*}; ALTO=${GEO#*x}
case "$ANCHO" in ''|*[!0-9]*) ANCHO=1024 ;; esac
case "$ALTO"  in ''|*[!0-9]*) ALTO=768 ;; esac
ALTO_CAJA=$ALTO   # la caja ocupa TODO; la barra vive plegada en la esquina

# (El reintento de la impresora ya NO se lanza desde aquí: esto corre como el
#  usuario cajero y no puede cargar controladores ni levantar servicios. Va por
#  systemd, como administrador. Auditoría 29-08-2026, fallo nº 3. Candado 45.)

# El MENÚ DE INICIO (nativo, estilo XP): espera a que el servicio local
# conteste y, si se cae, vuelve solo. Antes esto era una ventanita del
# navegador (QRBottBarra); ahora es un programa del sistema. Candado 77.
# (Se conserva la espera y el freno de los candados 46 y 49.)
(
  for i in $(seq 1 60); do
    curl -sf -m 2 -o /dev/null http://127.0.0.1:7777/estado && break
    sleep 1
  done
  while true; do
    curl -sf -m 2 -o /dev/null http://127.0.0.1:7777/estado || { sleep 5; continue; }
    python3 /opt/qrbott/menu-inicio.py >>/var/qrbott-datos/caja/menu.log 2>&1
    sleep 3   # si se cayó, se vuelve a abrir
  done
) &


exec chromium --app="$URL" --class=QRBottCaja \
  --kiosk-printing \
  --window-position=0,0 --window-size=$ANCHO,$ALTO_CAJA \
  --no-first-run --noerrdialogs --disable-infobars --disable-session-crashed-bubble \
  --disable-pinch --overscroll-history-navigation=0 --disable-features=TranslateUI \
  --password-store=basic --check-for-update-interval=31536000 \
  --touch-events=enabled --enable-features=OverlayScrollbar \
  --disable-dev-shm-usage \
  --ignore-gpu-blocklist --enable-gpu-rasterization --enable-zero-copy \
  --enable-features=VaapiVideoDecodeLinuxGL \
  --disable-features=Translate,TranslateUI,AutofillServerCommunication \
  --disable-translate --no-default-browser-check --disable-sync \
  --user-data-dir=/var/lib/qrbott/chrome
