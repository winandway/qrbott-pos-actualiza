#!/bin/bash
# ============================================================
#  QRBott POS — INFORME DEL EQUIPO (la caja negra)
#
#  POR QUÉ (pedido por el dueño, 29-08-2026): diagnosticar a distancia por
#  fotos de pantalla es lento y se pierden datos. Esto junta TODO lo que hace
#  falta para arreglar un equipo en un solo archivo de texto que el dueño copia
#  a un pendrive y manda.
#
#  Se genera SOLO en cada arranque, y también a mano desde la pantalla «Equipo».
#  Queda en:  Mis archivos / informe-del-equipo.txt
#  Ver CANDADOS.md nº 47.
# ============================================================
set -uo pipefail
export PATH="/usr/sbin:/sbin:$PATH"
# La pantalla del cajero: sin esto, xrandr y glxinfo fallan y el informe pierde
# justo la sección que hizo falta cuando el equipo iba lento. El permiso lo da
# el xhost del arranque. Auditoría 2ª vuelta, fallo 17. Candado 49.
export DISPLAY=:0

# Solo UN informe a la vez (el temporizador y el botón pueden coincidir).
exec 9>/tmp/qrbott-informe.lock
flock -n 9 || exit 0
DESTINO="/var/qrbott-datos/Mis archivos/informe-del-equipo.txt"
mkdir -p "$(dirname "$DESTINO")" 2>/dev/null

t() { echo; echo "════════ $* ════════"; }
c() { echo "--- \$ $* ---"; "$@" 2>&1 | head -60; }

{
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  INFORME DEL EQUIPO — Xunil OS  (terminal QRBott)        ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo "Generado:  $(date '+%Y-%m-%d %H:%M:%S')"
echo "Versión:   Xunil OS 1.0 · build $(cat /opt/qrbott/version 2>/dev/null || echo desconocida)"
echo "Equipo:    $(/opt/qrbott/identidad.sh 2>/dev/null || echo desconocido)"
echo "Encendido: $(uptime -p 2>/dev/null || uptime)"

t "1. RESUMEN — lo que importa de un vistazo"
lpstat -r 2>&1 | sed 's/^/  motor de impresión: /'
grep -qE " /media/root-ro [^ ]+ ro," /proc/mounts && echo "  disco real: PROTEGIDO (solo lectura)" || echo "  disco real: !! SIN PROTEGER (escribible) — un apagón puede corromperlo"
[ -e /dev/lp0 ] && echo "  puerto paralelo:    SÍ (/dev/lp0 existe)" \
                || echo "  puerto paralelo:    NO — la impresora integrada no se ve"
echo "  impresora:          $(cat /opt/qrbott/estado-impresora 2>/dev/null || echo 'sin comprobar')"
echo "  servicios:          $(cat /opt/qrbott/estado-servicios 2>/dev/null || echo 'sin comprobar')"
echo "  pendrive:           $(cat /opt/qrbott/estado-usb 2>/dev/null || echo 'ninguno')"
echo "  barra:              $(cat /opt/qrbott/estado-barra 2>/dev/null || echo 'tuerca')"
echo "  caja guardada:      $([ -f /var/qrbott-datos/caja/pos-guardado ] && echo SÍ || echo NO)"
ping -c1 -W2 1.1.1.1 >/dev/null 2>&1 && echo "  internet:           SÍ" || echo "  internet:           NO"

t "2. IMPRESORA — por qué no imprime, si no imprime"
c lpstat -r
c lpstat -p
c lpinfo -v
c lsmod
echo "--- \$ ls /dev/lp* /dev/parport* /dev/usb/lp* ---"
ls -l /dev/lp* /dev/parport* /dev/usb/lp* 2>&1 | head -20
c systemctl status cups.service --no-pager -l
echo "--- prueba de configuración del motor (cupsd -t) ---"
/usr/sbin/cupsd -t 2>&1 | head -10
echo "--- registro propio del motor (error_log) ---"
tail -30 /var/log/cups/error_log 2>/dev/null || echo "(sin registro)"
echo "--- lo que dijo nuestro driver (error_log) ---"
grep -a "qrbott-driver\|qrbott-paso\|document-format" /var/log/cups/error_log 2>/dev/null | tail -12 || echo "(nada)"
echo "--- diario del sistema sobre el motor ---"
journalctl -u cups.service -b --no-pager 2>/dev/null | tail -25
echo "--- bloqueos de AppArmor ---"
dmesg 2>/dev/null | grep -i denied | tail -8 || echo "(ninguno)"
echo "--- registro de nuestra búsqueda de impresora ---"
tail -60 /var/qrbott-datos/caja/impresora.log 2>/dev/null || echo "(sin registro)"

t "3. APARATOS — táctil, escáner, teclado"
echo "--- aparatos de entrada (uno debe ser el escáner integrado) ---"
grep -E "^N: Name|^P: Phys" /proc/bus/input/devices 2>/dev/null | sed 's/^/  /'
c lsusb
echo "--- registro de pantallas y táctil ---"
tail -40 /var/qrbott-datos/caja/pantallas.log 2>/dev/null || echo "(sin registro)"

t "4. SERVICIOS — qué está vivo y qué no"
c systemctl list-units --type=service --state=failed --no-pager
for sv in qrbott-caja qrbott-asistente-red qrbott-impresora qrbott-persistencia \
          qrbott-diagnostico cups NetworkManager; do
  printf '  %-26s %s / %s\n' "$sv" \
    "$(systemctl is-enabled $sv 2>&1)" "$(systemctl is-active $sv 2>&1)"
done

t "5. ERRORES DEL SISTEMA (últimos)"
journalctl -p err -b --no-pager 2>/dev/null | tail -60 || echo "(sin registro)"

t "6. NUESTROS SERVICIOS — qué dijeron al arrancar"
for sv in qrbott-caja qrbott-asistente-red qrbott-impresora; do
  echo "--- $sv ---"
  journalctl -u "$sv" -b --no-pager 2>/dev/null | tail -25
done

t "7. PANTALLA Y GRÁFICOS"
xrandr 2>/dev/null | head -20 || echo "(la pantalla aún no estaba lista: regenera el informe con el botón de Equipo)"
grep -E "\(EE\)|\(WW\)" /var/log/Xorg.0.log 2>/dev/null | tail -25 || echo "(sin registro de X)"
glxinfo -B 2>/dev/null | head -8 || echo "(glxinfo no disponible)"

t "8. RED"
c nmcli -t device status
echo "--- conexiones guardadas (autoconnect debe decir yes) ---"
nmcli -f NAME,TYPE,AUTOCONNECT,DEVICE connection show 2>&1 | head -8
echo "--- netplan (Ubuntu guarda AHÍ las conexiones de NM, como YAML) ---"
ls -la /etc/netplan/ 2>&1 | head -8
ls -la /var/qrbott-datos/netplan/ 2>&1 | head -8
echo "--- las claves en el disco ---"
ls -la /var/qrbott-datos/red/ 2>&1 | head -6
ls -la /etc/NetworkManager/system-connections 2>&1 | head -2
echo "--- lo que la red vio en los últimos arranques ---"
tail -35 /var/qrbott-datos/caja/red-arranque.log 2>/dev/null || echo "(sin registro)"
echo "--- ¿el wifi está gestionado? ---"
nmcli -f DEVICE,STATE device 2>&1 | head -6
c ip -brief addr

t "9. DISCO Y MEMORIA"
c df -h
echo "--- lo que la caja tiene guardado ---"
du -sh /var/qrbott-datos/caja/Default/IndexedDB \
       "/var/qrbott-datos/caja/Default/Service Worker" \
       /var/qrbott-datos/caja 2>/dev/null | sed 's/^/  /'
c free -m
echo "--- procesador ---"; grep -m1 "model name" /proc/cpuinfo

t "9b. IMPRESIONES — cada orden que pasó por aquí (candado 74)"
echo "-- vía directa (POST /imprimir): fecha | origen | tamaño | resultado | vía | tardó | cómo empieza"
tail -30 /var/qrbott-datos/caja/impresion.log 2>/dev/null || echo "  (ninguna todavía)"
echo "-- motor de impresión (diálogo/driver): hoja, dónde estaba el contenido, resolución"
tail -40 /var/spool/cups/tmp/qrbott-motor.log 2>/dev/null || echo "  (ninguna todavía)"
c lpstat -W completed -o
c tail -20 /var/log/cups/page_log

t "9c. QRBott ACTUALIZA — parches firmados desde la nube (candado 71)"
echo "estado: $(cat /opt/qrbott/estado-actualiza 2>/dev/null || echo 'todavía no ha buscado')"
echo "canal:  $(grep -h CANAL_URL /opt/qrbott/actualiza.conf 2>/dev/null | cut -d= -f2) $( [ -s /var/qrbott-datos/caja/actualiza-canal ] && echo "(cambiado a: $(head -1 /var/qrbott-datos/caja/actualiza-canal))")"
c systemctl list-timers qrbott-actualiza.timer --no-pager
tail -25 /var/qrbott-datos/caja/actualiza.log 2>/dev/null || echo "  (sin registro todavía)"

t "10. ACTUALIZACIONES — parches de seguridad automáticos"
echo "  estado: $(cat /opt/qrbott/estado-parches 2>/dev/null || echo 'aún no ha corrido (corre solo a las 3:30 am)')"
tail -15 /var/qrbott-datos/caja/parches.log 2>/dev/null || echo "  (sin registro todavía)"
systemctl is-enabled qrbott-parches.timer 2>&1 | sed 's/^/  temporizador: /'

t "11. INSTALACIÓN — cómo se instaló este equipo"
tail -80 /var/log/qrbott-instalar.log 2>/dev/null || echo "(sin registro de instalación)"

t "FIN DEL INFORME"
echo "Copia este archivo a un pendrive y mándaselo a soporte."
} > "$DESTINO" 2>&1

chown pos:pos "$DESTINO" 2>/dev/null || true
chmod 644 "$DESTINO" 2>/dev/null || true
echo "$DESTINO"
exit 0
