#!/usr/bin/env python3
# ============================================================
#  QRBott POS — MENÚ DE INICIO (nativo; estructura tipo XP, piel moderna y plana)
#
#  POR QUÉ (pedido por el dueño, 2-09-2026): la barra de abajo era una
#  ventanita del navegador pintada con HTML — «se ve como de código barato».
#  Esto es un programa DEL SISTEMA (GTK 3, las mismas piezas que usa el
#  teclado en pantalla): vive aunque el navegador se caiga, tiene bandeja de
#  estado y manda sobre las ventanas. Candado 77.
#
#  Cómo se ve: una barra azul abajo con el botón verde «QRBott» en la esquina
#  izquierda; al tocarlo sale el menú de dos columnas (izquierda blanca con lo
#  del día a día, derecha celeste con lo técnico), cabecera azul con el nombre
#  del negocio y pie con Reiniciar / Apagar. Al elegir algo, se esconde solo.
#
#  La barra se ESCONDE SOLA (candado 78): la caja ocupa toda la pantalla y en
#  la esquina queda una pestañita verde; se toca y sale. «Fijar» la deja
#  siempre visible (la caja se encoge para no quedar tapada).
#
#  Habla con el asistente local (127.0.0.1:7777) para todo lo que requiere
#  permisos: abrir ventanas, apagar, reiniciar, informe, parches.
#  Señales para probar sin tocar la pantalla: USR1 abre/cierra el menú,
#  USR2 muestra la barra.
# ============================================================
import gi, os, sys, json, signal, subprocess, threading, time, urllib.request, urllib.parse
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf, Pango  # noqa: E402

BASE = "http://127.0.0.1:7777"
ICONOS = "/opt/qrbott/iconos"
MODO_ARCHIVO = "/var/qrbott-datos/caja/barra-modo"      # «oculta» (por defecto) o «fija»
ALTO_BARRA = 40
ANCHO_TAB, ALTO_TAB = 96, 14
ANCHO_MENU = 400
SEGUNDOS_BARRA = 8        # la barra sola se esconde tras este rato
IDIOMA_ARCHIVO = "/var/qrbott-datos/caja/idioma"       # es (por defecto), en, zh
TEXTOS = {
 "es": {"caja": "Caja", "caja_s": "Volver a vender", "internet": "Internet", "navegador": "Navegador",
        "navegador_s": "Correo, envíos", "archivos": "Mis archivos", "archivos_s": "Fotos, descargas, pendrive",
        "equipo": "Equipo", "equipo_s": "Impresora y estado", "escritorio": "Escritorio (modo técnico)  ▶",
        "impresora": "Impresora", "actualizar": "Buscar actualización", "informe": "Generar informe",
        "idioma": "Idioma / Language / 语言", "fijar": "Fijar la barra", "soltar": "Soltar la barra (se esconde sola)",
        "cerrar": "Esconder la barra de abajo", "cerrar_aviso": "La barra se escondió. Para volver a verla toca la pestaña verde «▲ QRBott», abajo a la izquierda.",
        "act_buscando": "Buscando una versión nueva en la nube…", "act_aldia": "Ya tienes la última versión (%s).",
        "act_descargando": "Hay una versión nueva: %s · descargando…", "act_aplicando": "Instalando la versión %s…",
        "act_hecho": "Actualizado a la versión %s. El menú se reinicia en un momento.", "act_hecho_sin": "Actualizado a la versión %s (el disco se termina de proteger solo en 3 minutos).",
        "act_sinred": "No se pudo llegar al buzón de actualizaciones. Revisa el Internet e inténtalo otra vez.",
        "act_error": "La actualización no se pudo aplicar (%s). Enséñale esto a soporte.", "act_revertido": "La versión nueva falló y el equipo volvió solo a la anterior (%s). Enséñale esto a soporte.",
        "act_iso": "La versión nueva (%s) necesita reinstalar el sistema desde USB.", "act_titulo": "Buscar actualización",
        "inf_titulo": "Informe para soporte", "inf_generando": "Generando el informe del equipo… (tarda hasta un minuto)",
        "inf_hecho": "Informe guardado en Mis archivos → informe-del-equipo.txt\n\nContiene: impresora, red, servicios, errores, pantalla, disco, actualizaciones e impresiones recientes.",
        "inf_error": "No se pudo generar el informe. Inténtalo otra vez o enséñale esto a soporte.",
        "abrir": "Abrir", "cerrar_btn": "Cerrar", "volver_caja": "Volver a la caja", "impresora_s": "Ver, probar y agregar impresoras", "reiniciar": "Reiniciar", "apagar": "Apagar",
        "p_apagar": "¿Apagar el equipo?", "p_reiniciar": "¿Reiniciar el equipo?", "p_sub": "Termina la venta antes",
        "si_apagar": "Sí, apagar", "si_reiniciar": "Sí, reiniciar", "no": "No, volver",
        "con_cable": "Por cable · conectado", "con": "Conectado", "sin": "SIN conexión · tocar aquí",
        "sin_asistente": "sin respuesta del asistente", "elegir_idioma": "Elige el idioma",
        "tareas": {"Equipo": "Equipo", "Navegador": "Navegador", "Internet": "Internet", "Mis archivos": "Mis archivos"}},
 "en": {"caja": "Register", "caja_s": "Back to selling", "internet": "Internet", "navegador": "Browser",
        "navegador_s": "Email, shipping", "archivos": "My files", "archivos_s": "Photos, downloads, USB drive",
        "equipo": "This device", "equipo_s": "Printer and status", "escritorio": "Desktop (technician mode)  ▶",
        "impresora": "Printer", "actualizar": "Check for updates", "informe": "Create support report",
        "idioma": "Language / Idioma / 语言", "fijar": "Pin the taskbar", "soltar": "Unpin the taskbar (auto-hide)",
        "cerrar": "Hide the bottom bar", "cerrar_aviso": "The bar is hidden. To bring it back, tap the green «▲ QRBott» tab at the bottom left.",
        "act_buscando": "Checking the cloud for a new version…", "act_aldia": "You already have the latest version (%s).",
        "act_descargando": "New version available: %s · downloading…", "act_aplicando": "Installing version %s…",
        "act_hecho": "Updated to version %s. The menu restarts in a moment.", "act_hecho_sin": "Updated to version %s (the disk finishes protecting itself in 3 minutes).",
        "act_sinred": "Could not reach the update server. Check the Internet and try again.",
        "act_error": "The update could not be applied (%s). Show this to support.", "act_revertido": "The new version failed and the device went back to the previous one (%s). Show this to support.",
        "act_iso": "The new version (%s) needs a fresh install from USB.", "act_titulo": "Check for updates",
        "inf_titulo": "Support report", "inf_generando": "Creating the device report… (up to one minute)",
        "inf_hecho": "Report saved in My files → informe-del-equipo.txt\n\nIt includes: printer, network, services, errors, display, disk, updates and recent print jobs.",
        "inf_error": "The report could not be created. Try again or show this to support.",
        "abrir": "Open", "cerrar_btn": "Close", "volver_caja": "Back to the register", "impresora_s": "View, test and add printers", "reiniciar": "Restart", "apagar": "Shut down",
        "p_apagar": "Shut down this device?", "p_reiniciar": "Restart this device?", "p_sub": "Finish your sale first",
        "si_apagar": "Yes, shut down", "si_reiniciar": "Yes, restart", "no": "No, go back",
        "con_cable": "Wired · connected", "con": "Connected", "sin": "NO connection · tap here",
        "sin_asistente": "no answer from the local service", "elegir_idioma": "Choose your language",
        "tareas": {"Equipo": "Device", "Navegador": "Browser", "Internet": "Internet", "Mis archivos": "My files"}},
 "zh": {"caja": "收银台", "caja_s": "返回销售", "internet": "网络", "navegador": "浏览器",
        "navegador_s": "邮件、物流", "archivos": "我的文件", "archivos_s": "照片、下载、U盘",
        "equipo": "本机", "equipo_s": "打印机与状态", "escritorio": "桌面（技术模式）  ▶",
        "impresora": "打印机", "actualizar": "检查更新", "informe": "生成支持报告",
        "idioma": "语言 / Language / Idioma", "fijar": "固定任务栏", "soltar": "取消固定（自动隐藏）",
        "cerrar": "隐藏底部任务栏", "cerrar_aviso": "任务栏已隐藏。点击左下角绿色的「▲ QRBott」标签即可恢复。",
        "act_buscando": "正在云端检查新版本…", "act_aldia": "已是最新版本（%s）。",
        "act_descargando": "发现新版本：%s · 正在下载…", "act_aplicando": "正在安装版本 %s…",
        "act_hecho": "已更新到版本 %s。菜单即将重新启动。", "act_hecho_sin": "已更新到版本 %s（磁盘将在3分钟内自动完成保护）。",
        "act_sinred": "无法连接更新服务器。请检查网络后重试。",
        "act_error": "更新未能应用（%s）。请联系支持。", "act_revertido": "新版本失败，设备已自动恢复到上一版本（%s）。请联系支持。",
        "act_iso": "新版本（%s）需要通过U盘重新安装系统。", "act_titulo": "检查更新",
        "inf_titulo": "支持报告", "inf_generando": "正在生成设备报告…（最多一分钟）",
        "inf_hecho": "报告已保存到 我的文件 → informe-del-equipo.txt\n\n内容：打印机、网络、服务、错误、显示、磁盘、更新与最近打印记录。",
        "inf_error": "无法生成报告。请重试或联系支持。",
        "abrir": "打开", "cerrar_btn": "关闭", "volver_caja": "返回收银台", "impresora_s": "查看、测试和添加打印机", "reiniciar": "重新启动", "apagar": "关机",
        "p_apagar": "要关闭本机吗？", "p_reiniciar": "要重新启动本机吗？", "p_sub": "请先完成当前销售",
        "si_apagar": "是，关机", "si_reiniciar": "是，重启", "no": "否，返回",
        "con_cable": "有线 · 已连接", "con": "已连接", "sin": "无网络 · 点此处理",
        "sin_asistente": "本地服务无响应", "elegir_idioma": "选择语言",
        "tareas": {"Equipo": "本机", "Navegador": "浏览器", "Internet": "网络", "Mis archivos": "我的文件"}},
}
IDIOMAS = (("es", "Español", "es"), ("en", "English", "en"), ("zh", "中文", "zh"))

def leer_idioma():
    try:
        i = open(IDIOMA_ARCHIVO).read().strip()
        return i if i in TEXTOS else "es"
    except Exception:
        return "es"

VERSION = open("/opt/qrbott/version").read().strip() if os.path.exists("/opt/qrbott/version") else "?"

def log(*a):
    print(time.strftime("%H:%M:%S"), *a, file=sys.stderr, flush=True)

def pedir(ruta, metodo="POST"):
    """Orden al asistente local, en segundo plano (nunca congela el menú)."""
    def go():
        try:
            req = urllib.request.Request(BASE + ruta, method=metodo, data=b"" if metodo == "POST" else None)
            urllib.request.urlopen(req, timeout=20).read()
        except Exception as e:
            log("pedir", ruta, "->", e)
    threading.Thread(target=go, daemon=True).start()

def estado():
    try:
        return json.load(urllib.request.urlopen(BASE + "/estado", timeout=4))
    except Exception:
        return None

def nombre_negocio():
    try:
        url = open("/var/qrbott-datos/caja/url-caja").read().strip()
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
        n = q.get("nombre", [""])[0].strip()
        if n:
            return n
    except Exception:
        pass
    try:
        return open("/opt/qrbott/nombre-equipo").read().strip() or "QRBott POS"
    except Exception:
        return "QRBott POS"

def icono(nombre, px):
    try:
        pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(os.path.join(ICONOS, nombre + ".svg"), px, px, True)
        return Gtk.Image.new_from_pixbuf(pb)
    except Exception as e:
        log("icono", nombre, e)
        return Gtk.Image.new_from_icon_name("image-missing", Gtk.IconSize.DND)

def pedir_con_respuesta(ruta, cb, timeout=180):
    """Orden al asistente y su respuesta (JSON) de vuelta en el hilo de GTK."""
    def go():
        ok, d = False, {}
        try:
            req = urllib.request.Request(BASE + ruta, method="POST", data=b"")
            cuerpo = urllib.request.urlopen(req, timeout=timeout).read()
            d = json.loads(cuerpo or b"{}"); ok = bool(d.get("ok", True))
        except Exception as e:
            log("pedir_con_respuesta", ruta, "->", e); d = {"error": str(e)}
        GLib.idle_add(cb, ok, d)
    threading.Thread(target=go, daemon=True).start()

def leer_json(ruta, timeout=6):
    try:
        return json.load(urllib.request.urlopen(BASE + ruta, timeout=timeout))
    except Exception:
        return None

def xdotool(*args):
    try:
        return subprocess.run(["xdotool", *args], capture_output=True, text=True, timeout=5).stdout.strip()
    except Exception:
        return ""

CSS = b"""
* { font-family: "DejaVu Sans", sans-serif; }
#barra { background: #0B1D3A; }
#tab { background: #22A559; border-radius: 0 10px 0 0; }
#bandeja { padding: 0 12px; }
.bandeja { color: #B7C7E3; font-size: 12px; }

/* OJO (field report 2026-09-02): with loose selectors (.tarea) the system
   theme wins and paints its own background AND its own label color - the
   result was WHITE TEXT ON WHITE. Every button goes as button.class, with
   "background" (which clears the gradient) and the label color set on its
   own label. Candado 82. */
button#inicio { background: #22A559; background-image: none; box-shadow: none; text-shadow: none;
                border: none; border-radius: 16px; padding: 0 16px 0 10px; margin: 4px 0 4px 8px; }
button#inicio:hover, button#inicio:active { background: #2DBD68; background-image: none; }
button#inicio label { color: #FFFFFF; font-weight: bold; font-size: 14px; }

button.tarea { background: #16305C; background-image: none; box-shadow: none; text-shadow: none;
               border: none; border-radius: 10px; padding: 3px 12px; }
button.tarea:hover { background: #1F3F78; background-image: none; }
button.tarea label { color: #FFFFFF; font-size: 12px; }

button.volver { background: #22A559; background-image: none; box-shadow: none; text-shadow: none;
                border: none; border-radius: 10px; padding: 3px 14px; }
button.volver:hover { background: #2DBD68; background-image: none; }
button.volver label { color: #FFFFFF; font-weight: bold; font-size: 14px; }

#menu { background: #FFFFFF; border: 1px solid #D9E2F1; border-radius: 16px; }
#cabecera { background: #0B1D3A; padding: 12px 14px; border-radius: 14px 14px 0 0; }
#cabecera label { color: #FFFFFF; }
#izq { background: #FFFFFF; padding: 8px; }
#der { background: #F4F7FC; border-left: 1px solid #E6ECF5; padding: 8px; }
#pie { background: #F4F7FC; border-top: 1px solid #E6ECF5; padding: 8px 12px; border-radius: 0 0 14px 14px; }

button.item { background: none; background-image: none; box-shadow: none; border: none;
              border-radius: 10px; padding: 6px 8px; }
button.item:hover, button.item:active { background: #E6F0FF; background-image: none; }
.titulo { font-weight: bold; font-size: 13px; color: #0B1D3A; }
.subtitulo { font-size: 11px; color: #5F6E85; }
button.item-der label { font-size: 13px; color: #0B1D3A; }
button.item-der .titulo { font-weight: bold; }
.separador { background: #E6ECF5; }

button.pie-boton { background: #FFFFFF; background-image: none; box-shadow: none; text-shadow: none;
                   border: 1px solid #D9E2F1; border-radius: 10px; padding: 5px 12px; }
button.pie-boton:hover { background: #E6F0FF; background-image: none; }
button.pie-boton label { color: #0B1D3A; font-size: 12px; }
button.pie-apagar { background: #E24B4A; background-image: none; box-shadow: none; text-shadow: none;
                    border: none; border-radius: 10px; padding: 5px 12px; }
button.pie-apagar:hover { background: #C93B3A; background-image: none; }
button.pie-apagar label { color: #FFFFFF; font-size: 12px; font-weight: bold; }

#confirmar { background: #FFFFFF; border: 1px solid #D9E2F1; border-radius: 16px; padding: 16px; }
.confirmar-txt { font-size: 15px; font-weight: bold; color: #0B1D3A; }
.confirmar-sub { font-size: 12px; color: #5F6E85; }
button.rojo { background: #E24B4A; background-image: none; box-shadow: none; text-shadow: none;
              border: none; border-radius: 10px; padding: 8px 18px; }
button.rojo:hover { background: #C93B3A; background-image: none; }
button.rojo label { color: #FFFFFF; font-weight: bold; }
button.azul { background: #2563EB; background-image: none; box-shadow: none; text-shadow: none;
              border: none; border-radius: 10px; padding: 8px 18px; }
button.azul:hover { background: #1D4FC4; background-image: none; }
button.azul label { color: #FFFFFF; font-weight: bold; }
button.gris { background: #FFFFFF; background-image: none; box-shadow: none; text-shadow: none;
              border: 1px solid #D9E2F1; border-radius: 10px; padding: 8px 18px; }
button.gris:hover { background: #F4F7FC; background-image: none; }
button.gris label { color: #0B1D3A; }
"""


class Menu:
    def __init__(self):
        self.pantalla = Gdk.Screen.get_default()
        self.ancho, self.alto = self.pantalla.get_width(), self.pantalla.get_height()
        self.modo = self.leer_modo()
        self.oculta_id = None
        self.menu_abierto = False
        self.internet = None
        self.idioma = leer_idioma()
        self.T = TEXTOS[self.idioma]

        prov = Gtk.CssProvider(); prov.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(self.pantalla, prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        self.barra = self.crear_barra()
        self.tab = self.crear_tab()
        self.menu = self.crear_menu()
        self.elector = None
        self.confirmacion = None
        self.aviso_win = None
        self.escritorio = False
        self.aplicar_modo(inicial=True)
        GLib.timeout_add_seconds(6, self.refrescar_estado)
        GLib.timeout_add_seconds(3, self.refrescar_tareas)
        GLib.timeout_add_seconds(20, self.refrescar_reloj)
        self.refrescar_estado(); self.refrescar_reloj()
        GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, signal.SIGUSR1, self.alternar_menu)
        GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, signal.SIGUSR2, lambda *a: (self.mostrar_barra(), True)[1])

    # ---------- ventanas ----------
    def ventana_dock(self, nombre, w, h, x, y):
        v = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
        v.set_name(nombre)
        v.set_wmclass("qrbott-menu", "QRBottMenu")
        v.set_type_hint(Gdk.WindowTypeHint.DOCK)
        v.set_decorated(False); v.set_resizable(False)
        v.set_keep_above(True); v.set_skip_taskbar_hint(True); v.set_skip_pager_hint(True)
        v.set_accept_focus(False)
        v.set_default_size(w, h); v.set_size_request(w, h)
        v.move(x, y)
        return v

    def crear_tab(self):
        v = self.ventana_dock("tab", ANCHO_TAB, ALTO_TAB, 0, self.alto - ALTO_TAB)
        ev = Gtk.EventBox(); ev.set_name("tab")
        lab = Gtk.Label(label="▲  QRBott"); lab.set_markup('<span foreground="#ffffff" size="8000" weight="bold">▲  QRBott</span>')
        ev.add(lab)
        ev.connect("button-press-event", lambda *a: (self.mostrar_barra(), self.abrir_menu(), True)[2])
        v.add(ev)
        return v

    def crear_barra(self):
        v = self.ventana_dock("barra", self.ancho, ALTO_BARRA, 0, self.alto - ALTO_BARRA)
        caja = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6); caja.set_name("barra")
        self.boton_inicio = Gtk.Button(); self.boton_inicio.set_name("inicio")
        bi = Gtk.Box(spacing=6); bi.pack_start(icono("inicio", 24), False, False, 0)
        bi.pack_start(Gtk.Label(label="QRBott"), False, False, 0); self.boton_inicio.add(bi)
        self.boton_inicio.connect("clicked", lambda *a: self.alternar_menu())
        caja.pack_start(self.boton_inicio, False, False, 0)
        self.tareas = Gtk.Box(spacing=4); caja.pack_start(self.tareas, False, False, 6)
        self.boton_volver = Gtk.Button(); self.boton_volver.get_style_context().add_class("volver")
        bv = Gtk.Box(spacing=6); bv.pack_start(icono("caja", 22), False, False, 0)
        self.lab_volver = Gtk.Label(label=self.T["volver_caja"]); bv.pack_start(self.lab_volver, False, False, 0)
        self.boton_volver.add(bv); self.boton_volver.set_no_show_all(True)
        self.boton_volver.connect("clicked", lambda *a: self.ejecutar("caja"))
        caja.pack_start(self.boton_volver, False, False, 6)
        # bandeja: internet, impresora, nombre y hora
        bandeja = Gtk.Box(spacing=10); bandeja.set_name("bandeja")
        self.ic_red = Gtk.Box(); bandeja.pack_start(self.ic_red, False, False, 0)
        self.ic_imp = Gtk.Box(); bandeja.pack_start(self.ic_imp, False, False, 0)
        self.lab_nombre = Gtk.Label(); self.lab_nombre.get_style_context().add_class("bandeja")
        bandeja.pack_start(self.lab_nombre, False, False, 0)
        self.reloj = Gtk.Label(); self.reloj.get_style_context().add_class("bandeja")
        bandeja.pack_start(self.reloj, False, False, 0)
        caja.pack_end(bandeja, False, False, 0)
        ev = Gtk.EventBox(); ev.add(caja)
        ev.connect("button-press-event", lambda *a: (self.programar_ocultar(), False)[1])
        v.add(ev)
        return v

    def item_grande(self, ic, titulo, subtitulo, accion):
        b = Gtk.Button(); b.get_style_context().add_class("item"); b.set_relief(Gtk.ReliefStyle.NONE)
        h = Gtk.Box(spacing=10); h.pack_start(icono(ic, 32), False, False, 0)
        vb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        t = Gtk.Label(label=titulo, xalign=0); t.get_style_context().add_class("titulo")
        s = Gtk.Label(label=subtitulo, xalign=0); s.get_style_context().add_class("subtitulo")
        vb.pack_start(t, False, False, 0); vb.pack_start(s, False, False, 0)
        h.pack_start(vb, True, True, 0); b.add(h)
        b.connect("clicked", lambda *a: self.ejecutar(accion))
        return b, s

    def item_chico(self, ic, titulo, accion, negrita=False):
        b = Gtk.Button(); b.get_style_context().add_class("item"); b.get_style_context().add_class("item-der")
        b.set_relief(Gtk.ReliefStyle.NONE)
        h = Gtk.Box(spacing=8); h.pack_start(icono(ic, 24), False, False, 0)
        t = Gtk.Label(label=titulo, xalign=0)
        if negrita: t.get_style_context().add_class("titulo")
        h.pack_start(t, True, True, 0); b.add(h)
        b.connect("clicked", lambda *a: self.ejecutar(accion))
        return b, t

    def crear_menu(self):
        v = Gtk.Window(type=Gtk.WindowType.POPUP)
        v.set_name("menu"); v.set_wmclass("qrbott-menu", "QRBottMenu")
        v.set_decorated(False); v.set_size_request(ANCHO_MENU, -1)
        self.raiz_menu = Gtk.Box(orientation=Gtk.Orientation.VERTICAL); self.raiz_menu.set_name("menu")
        v.add(self.raiz_menu)
        v.connect("button-press-event", self.click_fuera)
        v.connect("key-press-event", lambda w, e: (self.cerrar_menu(), True)[1] if e.keyval == Gdk.KEY_Escape else False)
        self.poblar_menu()
        return v

    def poblar_menu(self):
        """Llena (o vuelve a llenar, al cambiar de idioma) el contenido del menú
        SIN destruir la ventana: destruirla y crear otra dejaba la nueva
        invisible detrás de la caja."""
        T = self.T
        raiz = self.raiz_menu
        for c in raiz.get_children():
            raiz.remove(c)
        # cabecera
        cab = Gtk.Box(spacing=10); cab.set_name("cabecera")
        cab.pack_start(icono("inicio", 40), False, False, 0)
        vb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        n = Gtk.Label(xalign=0); n.set_markup('<span size="13000" weight="bold">%s</span>' % GLib.markup_escape_text(nombre_negocio()))
        s = Gtk.Label(xalign=0); s.set_markup('<span size="9000">Xunil OS 1.0 · %s</span>' % GLib.markup_escape_text(VERSION))
        vb.pack_start(n, False, False, 0); vb.pack_start(s, False, False, 0)
        cab.pack_start(vb, True, True, 0); raiz.pack_start(cab, False, False, 0)
        # columnas
        cols = Gtk.Box()
        izq = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2); izq.set_name("izq"); izq.set_size_request(215, -1)
        b, self.sub_caja = self.item_grande("caja", T["caja"], T["caja_s"], "caja"); izq.pack_start(b, False, False, 0)
        b, self.sub_red = self.item_grande("internet", T["internet"], "…", "internet"); self.boton_red = b; izq.pack_start(b, False, False, 0)
        b, _ = self.item_grande("navegador", T["navegador"], T["navegador_s"], "navegador"); izq.pack_start(b, False, False, 0)
        b, _ = self.item_grande("archivos", T["archivos"], T["archivos_s"], "archivos"); izq.pack_start(b, False, False, 0)
        b, _ = self.item_grande("equipo", T["equipo"], T["equipo_s"], "equipo"); izq.pack_start(b, False, False, 0)
        sep = Gtk.Separator(); sep.get_style_context().add_class("separador"); izq.pack_start(sep, False, False, 6)
        b, _ = self.item_chico("escritorio", T["escritorio"], "escritorio", negrita=True); izq.pack_start(b, False, False, 0)
        der = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2); der.set_name("der"); der.set_size_request(180, -1)
        b, _ = self.item_chico("impresora", T["impresora"], "impresora"); b.set_tooltip_text(T["impresora_s"]); der.pack_start(b, False, False, 0)
        b, _ = self.item_chico("actualizar", T["actualizar"], "actualizar"); der.pack_start(b, False, False, 0)
        b, _ = self.item_chico("informe", T["informe"], "informe"); der.pack_start(b, False, False, 0)
        sep = Gtk.Separator(); sep.get_style_context().add_class("separador"); der.pack_start(sep, False, False, 6)
        b, _ = self.item_chico("idioma", T["idioma"], "idioma"); der.pack_start(b, False, False, 0)
        b, self.lab_fijar = self.item_chico("fijar", T["fijar"], "fijar"); der.pack_start(b, False, False, 0)
        b, _ = self.item_chico("ocultar", T["cerrar"], "cerrar"); der.pack_start(b, False, False, 0)
        cols.pack_start(izq, True, True, 0); cols.pack_start(der, True, True, 0)
        raiz.pack_start(cols, True, True, 0)
        # pie
        pie = Gtk.Box(spacing=8); pie.set_name("pie")
        for ic, txt, acc in (("reiniciar", T["reiniciar"], "reiniciar"), ("apagar", T["apagar"], "apagar")):
            b = Gtk.Button(); b.get_style_context().add_class("pie-apagar" if acc == "apagar" else "pie-boton")
            h = Gtk.Box(spacing=6); h.pack_start(icono(ic, 20), False, False, 0); h.pack_start(Gtk.Label(label=txt), False, False, 0)
            b.add(h); b.connect("clicked", lambda w, a=acc: self.ejecutar(a)); pie.pack_end(b, False, False, 0)
        raiz.pack_start(pie, False, False, 0)
        raiz.show_all()

    # ---------- comportamiento ----------
    def leer_modo(self):
        try:
            m = open(MODO_ARCHIVO).read().strip()
            return m if m in ("oculta", "fija") else "oculta"
        except Exception:
            return "oculta"

    def guardar_modo(self):
        try:
            os.makedirs(os.path.dirname(MODO_ARCHIVO), exist_ok=True)
            open(MODO_ARCHIVO, "w").write(self.modo)
        except Exception as e:
            log("modo", e)

    def aplicar_modo(self, inicial=False):
        if self.modo == "fija":
            self.tab.hide(); self.barra.show_all(); self.barra.move(0, self.alto - ALTO_BARRA)
            self.lab_fijar.set_text(self.T["soltar"])
            pedir("/barra/fija")
        else:
            self.barra.hide(); self.tab.show_all(); self.tab.move(0, self.alto - ALTO_TAB)
            self.lab_fijar.set_text(self.T["fijar"])
            if not inicial:
                pedir("/barra/tuerca")

    def mostrar_barra(self):
        self.tab.hide(); self.barra.show_all(); self.barra.move(0, self.alto - ALTO_BARRA)
        self.refrescar_tareas()
        self.programar_ocultar()

    def programar_ocultar(self, segundos=SEGUNDOS_BARRA):
        if self.oculta_id:
            GLib.source_remove(self.oculta_id); self.oculta_id = None
        if self.modo == "oculta":
            self.oculta_id = GLib.timeout_add_seconds(segundos, self.ocultar_barra)

    def ocultar_barra(self, forzar=False):
        self.oculta_id = None
        if not forzar and (self.menu_abierto or self.modo == "fija" or self.escritorio):
            return False
        if self.menu_abierto:
            self.cerrar_menu()
        self.barra.hide(); self.tab.show_all(); self.tab.move(0, self.alto - ALTO_TAB)
        return False

    def abrir_menu(self):
        if self.menu_abierto:
            return
        self.menu.show_all()
        alto = self.menu.get_preferred_height()[1]
        self.menu.move(0, self.alto - ALTO_BARRA - alto)
        self.menu_abierto = True
        if self.oculta_id:
            GLib.source_remove(self.oculta_id); self.oculta_id = None
        try:
            seat = Gdk.Display.get_default().get_default_seat()
            seat.grab(self.menu.get_window(), Gdk.SeatCapabilities.ALL_POINTING, True, None, None, None, None)
        except Exception as e:
            log("grab", e)
        self.refrescar_estado()

    def cerrar_menu(self):
        if not self.menu_abierto:
            return
        try:
            Gdk.Display.get_default().get_default_seat().ungrab()
        except Exception:
            pass
        self.menu.hide(); self.menu_abierto = False
        self.programar_ocultar(2)

    def alternar_menu(self, *a):
        if self.menu_abierto:
            self.cerrar_menu()
        else:
            self.mostrar_barra(); self.abrir_menu()
        return True

    def click_fuera(self, w, e):
        al = self.menu.get_allocation()
        log("clic en el menú", int(e.x), int(e.y), "de", al.width, al.height)
        if e.x < 0 or e.y < 0 or e.x > al.width or e.y > al.height:
            self.cerrar_menu()
            # ¿tocó el botón de inicio o la barra? que la barra siga un rato
            return True
        return False

    def ejecutar(self, accion):
        log("acción:", accion)
        if accion in ("apagar", "reiniciar"):
            self.cerrar_menu(); self.confirmar(accion); return
        self.cerrar_menu()
        rutas = {"caja": "/barra/caja", "internet": "/abrir/red", "navegador": "/abrir/navegador",
                 "archivos": "/abrir/archivos", "equipo": "/abrir/equipo",
                 "impresora": "/abrir/impresoras"}
        if accion in rutas:
            pedir(rutas[accion])
            if accion == "caja":
                self.salir_escritorio()
        elif accion == "escritorio":
            # nunca una pantalla negra sin salida: la barra se queda fija con
            # «Volver a la caja» hasta que se vuelva (candado 80)
            pedir("/barra/escritorio")
            self.escritorio = True
            self.boton_volver.set_no_show_all(False); self.boton_volver.show_all()
            self.mostrar_barra()
        elif accion == "actualizar":
            self.buscar_actualizacion()
        elif accion == "informe":
            self.generar_informe()
        elif accion == "cerrar":
            self.ocultar_barra(forzar=True)
            self.aviso(self.T["cerrar"], self.T["cerrar_aviso"], [(self.T["cerrar_btn"], None)], auto=7)
        elif accion == "fijar":
            self.modo = "fija" if self.modo == "oculta" else "oculta"
            self.guardar_modo(); self.aplicar_modo()
        elif accion == "idioma":
            self.elegir_idioma()

    def elegir_idioma(self):
        """Tres banderas grandes; se toca una y TODO el menú cambia de idioma."""
        if self.elector:
            self.elector.destroy()
        v = Gtk.Window(type=Gtk.WindowType.POPUP); v.set_name("confirmar")
        caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12); caja.set_name("confirmar")
        t = Gtk.Label(label=self.T["elegir_idioma"] + "  ·  Language  ·  语言"); t.get_style_context().add_class("confirmar-txt")
        caja.pack_start(t, False, False, 0)
        h = Gtk.Box(spacing=16, homogeneous=True)
        for cod, nombre, ic in IDIOMAS:
            b = Gtk.Button(); b.get_style_context().add_class("gris")
            vb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            vb.pack_start(icono(ic, 56), False, False, 0)
            lab = Gtk.Label(); lab.set_markup('<span size="12000" weight="%s">%s</span>' % ("bold" if cod == self.idioma else "normal", nombre))
            vb.pack_start(lab, False, False, 0); b.add(vb)
            b.connect("clicked", lambda w, c=cod: (log("bandera", c), v.destroy(), self.cambiar_idioma(c)))
            h.pack_start(b, True, True, 0)
        caja.pack_start(h, False, False, 0)
        no = Gtk.Button(label=self.T["no"]); no.get_style_context().add_class("gris"); no.connect("clicked", lambda *a: v.destroy())
        caja.pack_start(no, False, False, 0)
        v.add(caja); v.show_all()
        w, hh = v.get_preferred_width()[1], v.get_preferred_height()[1]
        v.move((self.ancho - w) // 2, (self.alto - hh) // 2)
        self.elector = v

    def cambiar_idioma(self, cod):
        log("idioma ->", cod)
        self.idioma = cod; self.T = TEXTOS[cod]
        try:
            os.makedirs(os.path.dirname(IDIOMA_ARCHIVO), exist_ok=True)
            open(IDIOMA_ARCHIVO, "w").write(cod)
        except Exception as e:
            log("idioma", e)
        # el menú se vuelve a construir en el idioma nuevo y se REABRE, para
        # que la persona vea el cambio de una vez
        self.cerrar_menu(); self.poblar_menu()
        self.lab_fijar.set_text(self.T["soltar"] if self.modo == "fija" else self.T["fijar"])
        self.lab_volver.set_text(self.T["volver_caja"])
        for c in self.tareas.get_children():
            self.tareas.remove(c)
        self.refrescar_estado()
        self.mostrar_barra(); self.abrir_menu()

    def salir_escritorio(self):
        if self.escritorio:
            self.escritorio = False
            self.boton_volver.hide()
            self.programar_ocultar(2)

    # ---------- avisos emergentes ----------
    def aviso(self, titulo, texto, botones, auto=None):
        """Ventanita centrada con título, texto y botones [(etiqueta, función|None)].
        Devuelve (ventana, etiqueta) para poder ir cambiando el texto."""
        if self.aviso_win:
            try:
                self.aviso_win.destroy()
            except Exception:
                pass
        v = Gtk.Window(type=Gtk.WindowType.POPUP); v.set_name("confirmar")
        caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10); caja.set_name("confirmar")
        caja.set_size_request(460, -1)
        t = Gtk.Label(label=titulo); t.get_style_context().add_class("confirmar-txt"); caja.pack_start(t, False, False, 0)
        s = Gtk.Label(label=texto); s.get_style_context().add_class("confirmar-sub"); s.set_line_wrap(True)
        s.set_max_width_chars(48); s.set_justify(Gtk.Justification.CENTER); caja.pack_start(s, False, False, 0)
        h = Gtk.Box(spacing=12, homogeneous=True)
        for etiqueta, fn in botones:
            b = Gtk.Button(label=etiqueta); b.get_style_context().add_class("gris" if fn is None else "azul")
            b.connect("clicked", lambda w, f=fn: (v.destroy(), f() if f else None))
            h.pack_start(b, True, True, 0)
        caja.pack_start(h, False, False, 0)
        v.add(caja); v.show_all()
        w, hh = v.get_preferred_width()[1], v.get_preferred_height()[1]
        v.move((self.ancho - w) // 2, (self.alto - hh) // 2)
        self.aviso_win = v
        if auto:
            GLib.timeout_add_seconds(auto, lambda: (v.destroy() if v.get_visible() else None, False)[1])
        return v, s

    def buscar_actualizacion(self):
        """Nunca en silencio: «Buscando…», y al final qué pasó. Candado 81."""
        T = self.T
        antes = leer_json("/actualiza/estado") or {}
        marca = (antes.get("estado", ""), antes.get("mtime", 0))
        v, lab = self.aviso(T["act_titulo"], T["act_buscando"], [(T["cerrar_btn"], None)])
        pedir("/actualizar")
        inicio = time.time()
        def sondear():
            if not v.get_visible():
                return False
            d = leer_json("/actualiza/estado")
            if not d:
                # el asistente se reinicia al aplicar el parche: sin respuesta
                # NO es un error, es «espera» (visto en la VM: salía «no se
                # pudo aplicar ()»)
                if time.time() - inicio > 900:
                    lab.set_text(T["act_sinred"]); return False
                return True
            est = d.get("estado", ""); ver = est.split(":", 1)[1] if ":" in est else ""
            fresco = (est, d.get("mtime", 0)) != marca or d.get("activo")
            # DESCARGANDO/APLICANDO son estados de camino, nunca finales
            en_camino = est.startswith(("DESCARGANDO", "APLICANDO"))
            if d.get("activo") or not fresco or en_camino:
                if est.startswith("DESCARGANDO"):
                    lab.set_text(T["act_descargando"] % ver)
                elif est.startswith("APLICANDO"):
                    lab.set_text(T["act_aplicando"] % ver)
                if time.time() - inicio > 900:
                    lab.set_text(T["act_error"] % est); return False
                return True
            # terminó: estado fresco y sin actividad
            if est.startswith("AL-DIA"):
                lab.set_text(T["act_aldia"] % (ver or d.get("version", VERSION)))
            elif est.startswith("ACTUALIZADO-SIN-PROTEGER"):
                lab.set_text(T["act_hecho_sin"] % ver); GLib.timeout_add_seconds(4, lambda: (Gtk.main_quit(), False)[1])
            elif est.startswith("ACTUALIZADO"):
                lab.set_text(T["act_hecho"] % ver); GLib.timeout_add_seconds(4, lambda: (Gtk.main_quit(), False)[1])
            elif est.startswith("REVERTIDO"):
                lab.set_text(T["act_revertido"] % ver)
            elif est.startswith("REQUIERE-ISO"):
                lab.set_text(T["act_iso"] % ver)
            elif est.startswith(("SIN-RED", "SIN-CANAL", "CANAL")):
                lab.set_text(T["act_sinred"])
            else:
                lab.set_text(T["act_error"] % est)
            return False
        GLib.timeout_add_seconds(2, sondear)

    def generar_informe(self):
        T = self.T
        v, lab = self.aviso(T["inf_titulo"], T["inf_generando"], [(T["cerrar_btn"], None)])
        def listo(ok, d):
            if not v.get_visible():
                return False
            v.destroy()
            if ok:
                self.aviso(T["inf_titulo"], T["inf_hecho"], [(T["cerrar_btn"], None), (T["abrir"], lambda: pedir("/abrir/informe"))])
            else:
                self.aviso(T["inf_titulo"], T["inf_error"], [(T["cerrar_btn"], None)])
            return False
        pedir_con_respuesta("/informe", listo, timeout=180)

    def modo_temporal_visible(self):
        # tras una acción larga, la barra se queda un rato para que se vea el estado
        self.mostrar_barra(); self.programar_ocultar(15)

    def confirmar(self, accion):
        if self.confirmacion:
            self.confirmacion.destroy()
        v = Gtk.Window(type=Gtk.WindowType.POPUP); v.set_name("confirmar")
        caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10); caja.set_name("confirmar")
        t = Gtk.Label(label=self.T["p_apagar"] if accion == "apagar" else self.T["p_reiniciar"])
        t.get_style_context().add_class("confirmar-txt")
        s = Gtk.Label(label=self.T["p_sub"]); s.get_style_context().add_class("confirmar-sub")
        caja.pack_start(t, False, False, 0); caja.pack_start(s, False, False, 0)
        h = Gtk.Box(spacing=12, homogeneous=True)
        si = Gtk.Button(label=self.T["si_apagar"] if accion == "apagar" else self.T["si_reiniciar"]); si.get_style_context().add_class("rojo")
        no = Gtk.Button(label=self.T["no"]); no.get_style_context().add_class("gris")
        si.connect("clicked", lambda *a: (v.destroy(), pedir("/" + accion)))
        no.connect("clicked", lambda *a: v.destroy())
        h.pack_start(no, True, True, 0); h.pack_start(si, True, True, 0); caja.pack_start(h, False, False, 0)
        v.add(caja); v.show_all()
        w, hh = v.get_preferred_width()[1], v.get_preferred_height()[1]
        v.move((self.ancho - w) // 2, (self.alto - hh) // 2)
        self.confirmacion = v

    # ---------- estado ----------
    def poner_icono(self, contenedor, nombre, px):
        for c in contenedor.get_children():
            contenedor.remove(c)
        contenedor.pack_start(icono(nombre, px), False, False, 0); contenedor.show_all()

    def refrescar_estado(self):
        def go():
            d = estado()
            imp = ""
            try:
                imp = open("/opt/qrbott/estado-impresora").read().strip()
            except Exception:
                pass
            GLib.idle_add(self.pintar_estado, d, imp)
        threading.Thread(target=go, daemon=True).start()
        return True

    def pintar_estado(self, d, imp):
        if d is None:
            self.sub_red.set_text(self.T["sin_asistente"]); return False
        con = bool(d.get("internet"))
        if con != self.internet:
            self.internet = con
            self.poner_icono(self.ic_red, "internet" if con else "sinred", 22)
        self.sub_red.set_text((self.T["con_cable"] if d.get("cable") else self.T["con"]) if con else self.T["sin"])
        self.poner_icono(self.ic_imp, "impresora", 22)
        self.ic_imp.set_tooltip_text("Impresora: " + (imp or "sin registrar"))
        self.lab_nombre.set_text(nombre_negocio())
        return False

    def refrescar_reloj(self):
        self.reloj.set_text(time.strftime("%H:%M"))
        return True

    def refrescar_tareas(self):
        if not self.barra.get_visible():
            return True
        clases = (("QRBottPanel", "Equipo"), ("QRBottNavegador", "Navegador"), ("QRBottRed", "Internet"), ("pcmanfm", "Mis archivos"))
        vivos = []
        for clase, txt in clases:
            ids = xdotool("search", "--onlyvisible", "--classname" if clase == "pcmanfm" else "--class", clase).split()
            if ids:
                vivos.append((ids[-1], self.T["tareas"].get(txt, txt)))
        actuales = [c.get_label() for c in self.tareas.get_children()]
        if actuales == [t for _, t in vivos]:
            return True
        for c in self.tareas.get_children():
            self.tareas.remove(c)
        for wid, txt in vivos:
            b = Gtk.Button(label=txt); b.get_style_context().add_class("tarea")
            b.connect("clicked", lambda w, i=wid: (xdotool("windowactivate", i), self.programar_ocultar()))
            self.tareas.pack_start(b, False, False, 0)
        self.tareas.show_all()
        return True


if __name__ == "__main__":
    log("menú de inicio arrancando, versión", VERSION)
    m = Menu()
    # Si venimos de aplicar un parche hace nada, el aviso de «Actualizado» se
    # fue con el proceso anterior: se vuelve a enseñar aquí para cerrar el
    # círculo (informe de campo 2-09-2026). Candado 81.
    try:
        _est = open("/opt/qrbott/estado-actualiza").read().strip()
        _recien = time.time() - os.path.getmtime("/opt/qrbott/estado-actualiza") < 180
        if _recien and _est.startswith("ACTUALIZADO") and _est.endswith(VERSION):
            GLib.timeout_add_seconds(2, lambda: (m.aviso(m.T["act_titulo"],
                m.T["act_hecho"] % VERSION, [(m.T["cerrar_btn"], None)], auto=12), False)[1])
    except Exception as e:
        log("aviso post-parche", e)
    Gtk.main()
