#!/bin/bash
# ============================================================
#  QRBott POS — las carpetas del dueño, listas en cada arranque
#
#  Va aparte a propósito: el instalador NO puede escribir en /home/pos, porque
#  cuando él corre ese usuario todavía no existe y se perdería en silencio
#  (candado 7). Esto corre al arrancar la caja, como administrador, cuando el
#  usuario ya existe de verdad.
#  Auditoría 29-08-2026, fallo nº 7. Candado 46.
# ============================================================
set -uo pipefail
MIS="/var/qrbott-datos/Mis archivos"
CASA="/home/pos"

mkdir -p "$MIS/Descargas" "$MIS/Fotos de productos" "$MIS/Documentos" 2>/dev/null
# OJO — SOLO lo del dueño. Antes esto era «chown -R pos:pos /var/qrbott-datos»
# y pisaba TAMBIÉN /var/qrbott-datos/red: el guardián de red IGNORA por
# seguridad las claves que no sean de root, así que el equipo «olvidaba» el
# Wi-Fi en cada reinicio. Informe de campo del 31-08-2026. Candado 61.
chown -R pos:pos "$MIS" /var/qrbott-datos/caja 2>/dev/null || true
# Y se repara la carpeta de red por si una versión vieja ya la pisó:
chown -R root:root /var/qrbott-datos/red 2>/dev/null || true
chmod 700 /var/qrbott-datos/red 2>/dev/null || true
chmod 600 /var/qrbott-datos/red/* 2>/dev/null || true

# Que el navegador descargue en la carpeta del dueño, y no en un rincón.
install -d -o pos -g pos "$CASA/.config" 2>/dev/null || true
{
  echo "XDG_DOWNLOAD_DIR=\"$MIS/Descargas\""
  echo "XDG_PICTURES_DIR=\"$MIS/Fotos de productos\""
  echo "XDG_DOCUMENTS_DIR=\"$MIS/Documentos\""
} > "$CASA/.config/user-dirs.dirs" 2>/dev/null || true
chown pos:pos "$CASA/.config/user-dirs.dirs" 2>/dev/null || true

# Acceso directo a la carpeta, para que se vea en el escritorio y en el gestor.
ln -sfn "$MIS" "$CASA/Mis archivos" 2>/dev/null || true
chown -h pos:pos "$CASA/Mis archivos" 2>/dev/null || true
exit 0
