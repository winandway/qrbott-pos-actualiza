#!/bin/bash
# ============================================================
#  QRBott POS — la barra se abre y se cierra
#
#  POR QUÉ (dicho por el dueño, 29-08-2026): «no tiene sentido tener eso 24
#  horas viéndolo allí». Tenía razón: son herramientas de vez en cuando, y el
#  punto de venta es lo que se usa todo el día. Ahora la barra vive como una
#  tuerquita en la esquina y se abre al tocarla.
#
#  Modos:
#    tuerca   → solo el botón redondo en la esquina; la caja ocupa TODO
#    abierta  → la barra sale encima, por un rato
#    fija     → la barra se queda, y la caja se encoge para no quedar tapada
#    escritorio → la caja se esconde y sale el escritorio (para técnicos)
#    caja     → volver del escritorio a la caja
#  Ver CANDADOS.md nº 38.
# ============================================================
set -uo pipefail
export DISPLAY=:0
MODO="${1:-tuerca}"
ALTO_BARRA=40   # la barra del menú de inicio (menu-inicio.py)
LADO_TUERCA=44
ESTADO=/opt/qrbott/estado-barra

GEO=$(xrandr 2>/dev/null | awk '/\*/{print $1; exit}')
ANCHO=${GEO%x*}; ALTO=${GEO#*x}
case "$ANCHO" in ''|*[!0-9]*) ANCHO=1024 ;; esac
case "$ALTO"  in ''|*[!0-9]*) ALTO=768 ;; esac

ven() { xdotool search --class "$1" 2>/dev/null | tail -1; }
BARRA=""   # la barra ya no es una ventana del navegador (candado 77): el menú nativo se mueve solo
CAJA=$(ven QRBottCaja)

case "$MODO" in
  tuerca)
    [ -n "$BARRA" ] && { xdotool windowsize "$BARRA" $LADO_TUERCA $LADO_TUERCA
                         xdotool windowmove "$BARRA" 8 $((ALTO-LADO_TUERCA-8)); }
    [ -n "$CAJA" ]  && { xdotool windowsize "$CAJA" $ANCHO $ALTO
                         xdotool windowmove "$CAJA" 0 0; }
    ;;
  abierta)
    [ -n "$BARRA" ] && { xdotool windowsize "$BARRA" $ANCHO $ALTO_BARRA
                         xdotool windowmove "$BARRA" 0 $((ALTO-ALTO_BARRA)); }
    [ -n "$CAJA" ]  && { xdotool windowsize "$CAJA" $ANCHO $ALTO
                         xdotool windowmove "$CAJA" 0 0; }
    ;;
  fija)
    [ -n "$BARRA" ] && { xdotool windowsize "$BARRA" $ANCHO $ALTO_BARRA
                         xdotool windowmove "$BARRA" 0 $((ALTO-ALTO_BARRA)); }
    [ -n "$CAJA" ]  && { xdotool windowsize "$CAJA" $ANCHO $((ALTO-ALTO_BARRA))
                         xdotool windowmove "$CAJA" 0 0; }
    ;;
  escritorio)
    # NUNCA una pantalla negra sin salida (informe de campo 2-09-2026): fondo
    # azul, el escritorio con sus íconos, y la ventana de Mis archivos abierta;
    # la barra del menú se queda fija con «Volver a la caja». Candado 80.
    xsetroot -solid "#1C4EBF" 2>/dev/null || true
    [ -n "$CAJA" ] && xdotool windowminimize "$CAJA"
    # (pcmanfm --desktop pintaba la pantalla de NEGRO: se queda el fondo azul)
    # setsid -f: el visor arranca APARTE y este guion termina de una. Con
    # «… || nohup … &» el subshell se quedaba esperando a pcmanfm con la
    # salida abierta y el asistente tardaba 20 s en contestar (visto en la VM).
    if ! pgrep -f "pcmanfm /var/qrbott-datos/Mis archivos" >/dev/null 2>&1; then
      setsid -f pcmanfm "/var/qrbott-datos/Mis archivos" >/dev/null 2>&1 </dev/null
    fi
    [ -n "$BARRA" ] && { xdotool windowsize "$BARRA" $ANCHO $ALTO_BARRA
                         xdotool windowmove "$BARRA" 0 $((ALTO-ALTO_BARRA)); }
    ;;
  caja)
    # LA PUERTA DE VUELTA. El dueño tocó «Escritorio» y quedó atrapado: la caja
    # se escondía y no había botón para volver. Esto la trae SIEMPRE:
    # se cierra el escritorio, se desminimiza, se activa y se pone delante.
    # Si la ventana no existe, se reinicia el servicio entero de la caja.
    # Informe real del 30-08-2026. Candado 50.
    pkill -f "pcmanfm --desktop" 2>/dev/null
    if [ -n "$CAJA" ]; then
      xdotool windowmap "$CAJA" 2>/dev/null
      xdotool windowactivate "$CAJA" 2>/dev/null
      xdotool windowraise "$CAJA" 2>/dev/null
      xdotool windowsize "$CAJA" $ANCHO $ALTO 2>/dev/null
      xdotool windowmove "$CAJA" 0 0 2>/dev/null
      # La caja volvía EN BLANCO hasta que el dueño pulsaba F5 a mano: el
      # navegador no repinta solo tras estar escondido. Se fuerza el repintado
      # y una recarga (el carrito sobrevive: vive guardado en el equipo).
      # Informe de campo del 30-08-2026. Candado 57.
      xrefresh -display :0 2>/dev/null || true
      sleep 1
      xdotool key --window "$CAJA" F5 2>/dev/null || true
    else
      systemctl restart qrbott-caja.service 2>/dev/null || true
    fi
    ;;
esac

echo "$MODO" > "$ESTADO" 2>/dev/null || true
exit 0
