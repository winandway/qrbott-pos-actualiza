#!/bin/bash
# ============================================================
#  QRBott POS OS — robustez de tienda real
#  1) El equipo aguanta cortes de luz sin corromperse
#  2) Salida de mantenimiento protegida con contraseña (para el técnico)
# ============================================================
set -uo pipefail   # sin -e: un comando que falle no debe tumbar la instalación

# ---------- 1. Protección contra cortes de luz ----------
# El disco va en solo lectura; lo que se escribe va a una capa aparte en RAM.
# Los datos que SÍ deben sobrevivir (sesión de la caja) van a una partición propia.
apt-get install -y -qq overlayroot 2>/dev/null || true
true
if [ -f /etc/overlayroot.conf ]; then
  sed -i 's|^overlayroot=.*|overlayroot="tmpfs:swap=1,recurse=0"|' /etc/overlayroot.conf
  grep -q '^overlayroot=' /etc/overlayroot.conf || echo 'overlayroot="tmpfs:swap=1,recurse=0"' >> /etc/overlayroot.conf
fi

# (La zona persistente ya la crea el instalador como partición propia
#  QRBOTTDATA y la monta el sistema: ver payload/persistencia.sh y CANDADOS.md nº 12.)

# Herramienta para actualizar el sistema (desactiva la protección, actualiza y la repone)
cat > /usr/local/sbin/qrbott-mantenimiento <<'MNTS'
#!/bin/bash
# Uso: qrbott-mantenimiento on|off|update
case "${1:-}" in
  off)    overlayroot-chroot /bin/true 2>/dev/null; sed -i 's|^overlayroot=.*|overlayroot=""|' /etc/overlayroot.conf; echo "Protección DESACTIVADA. Reinicia para escribir en el disco.";;
  on)     sed -i 's|^overlayroot=.*|overlayroot="tmpfs:swap=1,recurse=0"|' /etc/overlayroot.conf; echo "Protección ACTIVADA. Reinicia.";;
  update) overlayroot-chroot apt-get update && overlayroot-chroot apt-get -y upgrade; echo "Sistema actualizado.";;
  *) echo "Uso: qrbott-mantenimiento on|off|update";;
esac
MNTS
chmod +x /usr/local/sbin/qrbott-mantenimiento

# ---------- 2. Salida de mantenimiento con contraseña ----------
# El cajero NO puede salir. El técnico sí: Ctrl+Alt+F2 pide usuario y contraseña.
# (tty1 = la caja · tty2 = mantenimiento)
systemctl enable getty@tty2.service 2>/dev/null || true
true

# Bloquear los atajos que permitirían escaparse de la caja en tty1
mkdir -p /etc/X11/xorg.conf.d
cat > /etc/X11/xorg.conf.d/90-qrbott-kiosco.conf <<'XORG'
Section "ServerFlags"
    Option "DontVTSwitch" "off"     # se permite cambiar de consola: lo protege la contraseña
    Option "DontZap"      "on"      # no se puede matar X con Ctrl+Alt+Retroceso
    Option "BlankTime"    "0"
    Option "StandbyTime"  "0"
    Option "SuspendTime"  "0"
    Option "OffTime"      "0"
EndSection
XORG

# Aviso al técnico al entrar por la consola de mantenimiento
cat > /etc/qrbott/MANTENIMIENTO.txt <<'TXT'
QRBott POS — consola de mantenimiento

Comandos útiles:
  qrbott-mantenimiento off      desactiva la protección de disco (para instalar cosas)
  qrbott-mantenimiento update   actualiza el sistema con la protección puesta
  qrbott-mantenimiento on       vuelve a proteger el disco
  /opt/qrbott/impresora.sh      vuelve a detectar y registrar la impresora
  nmtui                         configurar el Wi-Fi
  systemctl restart qrbott-caja reiniciar la caja

Volver a la caja: Ctrl + Alt + F1
TXT
cat /etc/qrbott/MANTENIMIENTO.txt >> /etc/motd 2>/dev/null || true

echo "Robustez aplicada: protección de disco + consola de mantenimiento."

exit 0   # nunca tumbar la instalación
