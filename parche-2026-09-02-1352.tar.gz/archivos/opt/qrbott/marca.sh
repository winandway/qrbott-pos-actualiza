#!/bin/bash
# ============================================================
#  QRBott POS OS — MARCA PROPIA en todo el sistema
#  Deja el equipo identificado como fabricado por Windoce LLC / QRBott.com
#  en TODO lo que el sistema operativo puede controlar.
# ============================================================
set -uo pipefail   # sin -e: un comando que falle no debe tumbar la instalación
D=/opt/qrbott

# ---------- 1. Identidad del sistema operativo ----------
cat > /etc/os-release <<'OSR'
PRETTY_NAME="QRBott POS OS 1.0"
NAME="QRBott POS OS"
VERSION_ID="1.0"
VERSION="1.0 (Terminal de punto de venta)"
VERSION_CODENAME=caja
ID=qrbott
ID_LIKE="ubuntu debian"
HOME_URL="https://qrbott.com/"
SUPPORT_URL="https://qrbott.com/soporte"
BUG_REPORT_URL="https://qrbott.com/soporte"
PRIVACY_POLICY_URL="https://qrbott.com/privacidad"
VENDOR_NAME="Windoce LLC"
VENDOR_URL="https://windoce.com/"
OSR
ln -sf /etc/os-release /usr/lib/os-release 2>/dev/null || true
true

# ---------- 2. Datos OEM que ve el sistema (lo que Windows llama "OEM info") ----------
mkdir -p /etc/qrbott
cat > /etc/qrbott/oem.conf <<'OEM'
# Datos del fabricante del equipo — QRBott POS
Manufacturer=Windoce LLC
Brand=QRBott
Product=QRBott POS Terminal
SupportURL=https://qrbott.com/soporte
SupportPhone=
Website=https://qrbott.com
Model=QRBott POS
OEM
cp "$D/logo.png" /etc/qrbott/logo.png 2>/dev/null || true

# Mensaje de bienvenida en cualquier consola (si un técnico entra)
cat > /etc/issue <<'ISS'

  QRBott POS Terminal — Windoce LLC
  Soporte: https://qrbott.com/soporte

ISS
cp /etc/issue /etc/issue.net
rm -f /etc/motd; cat > /etc/motd <<'MOTD'

  ██  QRBott POS OS
      Terminal de punto de venta · Windoce LLC
      https://qrbott.com

MOTD
# Quitar la publicidad y los avisos de Ubuntu
rm -f /etc/update-motd.d/10-help-text /etc/update-motd.d/50-motd-news \
      /etc/update-motd.d/00-header /etc/update-motd.d/80-livepatch \
      /etc/update-motd.d/91-contract-ua-esm-status 2>/dev/null || true
sed -i 's/^ENABLED=1/ENABLED=0/' /etc/default/motd-news 2>/dev/null || true

# ---------- 3. Arranque: GRUB con nuestra marca ----------
sed -i 's/^GRUB_DISTRIBUTOR=.*/GRUB_DISTRIBUTOR="QRBott POS"/' /etc/default/grub 2>/dev/null || \
  echo 'GRUB_DISTRIBUTOR="QRBott POS"' >> /etc/default/grub
grep -q GRUB_BACKGROUND /etc/default/grub || echo 'GRUB_BACKGROUND="/etc/qrbott/fondo-arranque.png"' >> /etc/default/grub

# ---------- 4. Nombre del equipo ----------
echo "qrbott-pos" > /etc/hostname 2>/dev/null || true
hostnamectl set-hostname qrbott-pos 2>/dev/null || true
cat > /etc/machine-info <<'MI'
PRETTY_HOSTNAME=QRBott POS
ICON_NAME=computer-vm
CHASSIS=desktop
DEPLOYMENT=production
MI

# ---------- 5. Nota permanente del fabricante ----------
cat > /etc/qrbott/LEEME.txt <<'NOTA'
QRBott POS Terminal
Fabricado y soportado por Windoce LLC — https://windoce.com
Software: QRBott POS OS · https://qrbott.com

Este equipo es una terminal de punto de venta. El software se actualiza
solo desde la nube; no requiere mantenimiento local.
Soporte: https://qrbott.com/soporte
NOTA

echo "Marca QRBott aplicada al sistema."

exit 0   # nunca tumbar la instalación
