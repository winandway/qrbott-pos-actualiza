#!/bin/bash
# ============================================================
#  QRBott Actualiza — lo que hace un parche al llegar al equipo.
#  Lo ejecuta /opt/qrbott/actualizar.sh con estas variables:
#    RAIZ          el disco real (/media/root-ro), ya montado para escribir
#    ANTERIOR_DIR  copia de /opt/qrbott previa (+ _otros/ para lo de fuera)
#    NUEVA / ANTERIOR   versiones
#  Copia CADA archivo de archivos/ (rutas absolutas del sistema) al disco real
#  y al sistema vivo, guardando antes lo que pisa (para poder revertir), y
#  después reinstala el driver de impresión y reinicia lo que toca.
#  Un fallo aquí = el parche NO se da por aplicado. Candado 71.
# ============================================================
set -euo pipefail
cd "$(dirname "$0")"
: "${RAIZ:?}" "${ANTERIOR_DIR:?}"
echo "== aplicando parche $NUEVA (venía la $ANTERIOR) =="
n=0
while IFS= read -r -d '' f; do
  dest="${f#./}"; dest="/${dest#archivos/}"
  modo=$(stat -c %a "$f")
  for r in "$RAIZ" ""; do
    mkdir -p "$r$(dirname "$dest")"
    # respaldo de lo que se pisa fuera de /opt/qrbott (lo de dentro ya está copiado entero)
    case "$dest" in /opt/qrbott/*) ;; *)
      if [ -z "$r" ] && [ -e "$dest" ] && [ ! -e "$ANTERIOR_DIR/_otros$dest" ]; then
        mkdir -p "$ANTERIOR_DIR/_otros$(dirname "$dest")"; cp -a "$dest" "$ANTERIOR_DIR/_otros$dest"
      fi ;;
    esac
    install -m "$modo" "$f" "$r$dest"
  done
  n=$((n+1))
done < <(find ./archivos -type f -print0)
echo "archivos escritos: $n (en el disco real y en el sistema vivo)"
[ "$n" -gt 0 ] || { echo "!! el parche no traía archivos"; exit 1; }

# Pasos fijos después de copiar
for r in "$RAIZ" ""; do
  chmod +x "$r"/opt/qrbott/*.sh 2>/dev/null || true
  chmod 644 "$r"/opt/qrbott/actualiza.pub 2>/dev/null || true
  if [ -f "$r/opt/qrbott/qrbott-pdf-a-escpos" ]; then
    install -m 755 -o root -g root "$r/opt/qrbott/qrbott-pdf-a-escpos" "$r/usr/lib/cups/filter/qrbott-pdf-a-escpos"
  fi
  [ -f "$r/opt/qrbott/qrbott-escpos-paso" ] && install -m 755 -o root -g root "$r/opt/qrbott/qrbott-escpos-paso" "$r/usr/lib/cups/filter/qrbott-escpos-paso"
  [ -f "$r/opt/qrbott/qrbott.types" ] && install -m 644 -o root -g root "$r/opt/qrbott/qrbott.types" "$r/usr/share/cups/mime/qrbott.types"
done
if [ -f ./despues.sh ]; then echo "-- despues.sh --"; bash ./despues.sh; fi
systemctl daemon-reload
systemctl restart qrbott-asistente-red.service
systemctl try-restart cups.service 2>/dev/null || true
echo "== parche $NUEVA aplicado =="
