#!/usr/bin/env python3
# ============================================================
#  QRBott POS — MENÚ DE INICIO (nativo, estilo Windows XP «Luna»)
#
#  POR QUÉ (pedido por el dueño, 2-09-2026): la barra de abajo era una
#  ventanita del navegador pintada con HTML — «se ve como de código barato».
#  Esto es un programa DEL SISTEMA (GTK 3, las mismas piezas que usa el
#  teclado en pantalla): vive aunque el navegador se caiga, tiene bandeja de
#  estado y manda sobre las ventanas. Candado 77.
#
#  Cómo se ve: una barra azul abajo con el botón verde «QRBott» en la esquina
#  izquierda; al tocarlo sale el menú de dos columnas (izquierda blanca con lo
#  del día a día, derecha celeste con lo técnico), cabecera azul con el nombre
#  del negocio y pie con Reiniciar / Apagar. Al elegir algo, se esconde solo.
#
#  La barra se ESCONDE SOLA (candado 78): la caja ocupa toda la pantalla y en
#  la esquina queda una pestañita verde; se toca y sale. «Fijar» la deja
#  siempre visible (la caja se encoge para no quedar tapada).
#
#  Habla con el asistente local (127.0.0.1:7777) para todo lo que requiere
#  permisos: abrir ventanas, apagar, reiniciar, informe, parches.
#  Señales para probar sin tocar la pantalla: USR1 abre/cierra el menú,
#  USR2 muestra la barra.
# ============================================================
import gi, os, sys, json, signal, subprocess, threading, time, urllib.request, urllib.parse
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf, Pango  # noqa: E402

BASE = "http://127.0.0.1:7777"
ICONOS = "/opt/qrbott/iconos"
MODO_ARCHIVO = "/var/qrbott-datos/caja/barra-modo"      # «oculta» (por defecto) o «fija»
ALTO_BARRA = 40
ANCHO_TAB, ALTO_TAB = 96, 14
ANCHO_MENU = 400
SEGUNDOS_BARRA = 8        # la barra sola se esconde tras este rato
IDIOMA_ARCHIVO = "/var/qrbott-datos/caja/idioma"       # es (por defecto), en, zh
TEXTOS = {
 "es": {"caja": "Caja", "caja_s": "Volver a vender", "internet": "Internet", "navegador": "Navegador",
        "navegador_s": "Correo, envíos", "archivos": "Mis archivos", "archivos_s": "Fotos, descargas, pendrive",
        "equipo": "Equipo", "equipo_s": "Impresora y estado", "escritorio": "Escritorio (modo técnico)  ▶",
        "impresora": "Impresora", "actualizar": "Buscar actualización", "informe": "Generar informe",
        "idioma": "Idioma / Language / 语言", "fijar": "Fijar la barra", "soltar": "Soltar la barra (se esconde sola)",
        "cerrar": "Esconder el menú", "reiniciar": "Reiniciar", "apagar": "Apagar",
        "p_apagar": "¿Apagar el equipo?", "p_reiniciar": "¿Reiniciar el equipo?", "p_sub": "Termina la venta antes",
        "si_apagar": "Sí, apagar", "si_reiniciar": "Sí, reiniciar", "no": "No, volver",
        "con_cable": "Por cable · conectado", "con": "Conectado", "sin": "SIN conexión · tocar aquí",
        "sin_asistente": "sin respuesta del asistente", "elegir_idioma": "Elige el idioma",
        "tareas": {"Equipo": "Equipo", "Navegador": "Navegador", "Internet": "Internet", "Mis archivos": "Mis archivos"}},
 "en": {"caja": "Register", "caja_s": "Back to selling", "internet": "Internet", "navegador": "Browser",
        "navegador_s": "Email, shipping", "archivos": "My files", "archivos_s": "Photos, downloads, USB drive",
        "equipo": "This device", "equipo_s": "Printer and status", "escritorio": "Desktop (technician mode)  ▶",
        "impresora": "Printer", "actualizar": "Check for updates", "informe": "Create support report",
        "idioma": "Language / Idioma / 语言", "fijar": "Pin the taskbar", "soltar": "Unpin the taskbar (auto-hide)",
        "cerrar": "Hide this menu", "reiniciar": "Restart", "apagar": "Shut down",
        "p_apagar": "Shut down this device?", "p_reiniciar": "Restart this device?", "p_sub": "Finish your sale first",
        "si_apagar": "Yes, shut down", "si_reiniciar": "Yes, restart", "no": "No, go back",
        "con_cable": "Wired · connected", "con": "Connected", "sin": "NO connection · tap here",
        "sin_asistente": "no answer from the local service", "elegir_idioma": "Choose your language",
        "tareas": {"Equipo": "Device", "Navegador": "Browser", "Internet": "Internet", "Mis archivos": "My files"}},
 "zh": {"caja": "收银台", "caja_s": "返回销售", "internet": "网络", "navegador": "浏览器",
        "navegador_s": "邮件、物流", "archivos": "我的文件", "archivos_s": "照片、下载、U盘",
        "equipo": "本机", "equipo_s": "打印机与状态", "escritorio": "桌面（技术模式）  ▶",
        "impresora": "打印机", "actualizar": "检查更新", "informe": "生成支持报告",
        "idioma": "语言 / Language / Idioma", "fijar": "固定任务栏", "soltar": "取消固定（自动隐藏）",
        "cerrar": "隐藏菜单", "reiniciar": "重新启动", "apagar": "关机",
        "p_apagar": "要关闭本机吗？", "p_reiniciar": "要重新启动本机吗？", "p_sub": "请先完成当前销售",
        "si_apagar": "是，关机", "si_reiniciar": "是，重启", "no": "否，返回",
        "con_cable": "有线 · 已连接", "con": "已连接", "sin": "无网络 · 点此处理",
        "sin_asistente": "本地服务无响应", "elegir_idioma": "选择语言",
        "tareas": {"Equipo": "本机", "Navegador": "浏览器", "Internet": "网络", "Mis archivos": "我的文件"}},
}
IDIOMAS = (("es", "Español", "es"), ("en", "English", "en"), ("zh", "中文", "zh"))

def leer_idioma():
    try:
        i = open(IDIOMA_ARCHIVO).read().strip()
        return i if i in TEXTOS else "es"
    except Exception:
        return "es"

VERSION = open("/opt/qrbott/version").read().strip() if os.path.exists("/opt/qrbott/version") else "?"

def log(*a):
    print(time.strftime("%H:%M:%S"), *a, file=sys.stderr, flush=True)

def pedir(ruta, metodo="POST"):
    """Orden al asistente local, en segundo plano (nunca congela el menú)."""
    def go():
        try:
            req = urllib.request.Request(BASE + ruta, method=metodo, data=b"" if metodo == "POST" else None)
            urllib.request.urlopen(req, timeout=20).read()
        except Exception as e:
            log("pedir", ruta, "->", e)
    threading.Thread(target=go, daemon=True).start()

def estado():
    try:
        return json.load(urllib.request.urlopen(BASE + "/estado", timeout=4))
    except Exception:
        return None

def nombre_negocio():
    try:
        url = open("/var/qrbott-datos/caja/url-caja").read().strip()
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
        n = q.get("nombre", [""])[0].strip()
        if n:
            return n
    except Exception:
        pass
    try:
        return open("/opt/qrbott/nombre-equipo").read().strip() or "QRBott POS"
    except Exception:
        return "QRBott POS"

def icono(nombre, px):
    try:
        pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(os.path.join(ICONOS, nombre + ".svg"), px, px, True)
        return Gtk.Image.new_from_pixbuf(pb)
    except Exception as e:
        log("icono", nombre, e)
        return Gtk.Image.new_from_icon_name("image-missing", Gtk.IconSize.DND)

def xdotool(*args):
    try:
        return subprocess.run(["xdotool", *args], capture_output=True, text=True, timeout=5).stdout.strip()
    except Exception:
        return ""

CSS = b"""
* { font-family: "DejaVu Sans", sans-serif; }
#barra { background-image: linear-gradient(to bottom, #4A8AEA, #245EDC 45%, #1C4EBF); }
#tab { background-image: linear-gradient(to bottom, #6CC46E, #3C9B3E); border-radius: 0 10px 0 0; }
#inicio { background-image: linear-gradient(to bottom, #6CC46E, #3C9B3E 55%, #2E7A30);
          color: #ffffff; font-weight: bold; font-size: 15px; font-style: italic;
          border-radius: 0 14px 14px 0; border: none; padding: 0 18px 0 8px; margin: 0; }
#inicio:hover, #inicio:active { background-image: linear-gradient(to bottom, #7ED481, #48AA4A 55%, #378838); }
.tarea { color: #ffffff; background-image: linear-gradient(to bottom, #3F7BE3, #2A63D0); border: 1px solid #1C4EBF;
         border-radius: 3px; padding: 2px 10px; font-size: 12px; }
.tarea:hover { background-image: linear-gradient(to bottom, #5A90EC, #3A73DB); }
.bandeja { color: #ffffff; font-size: 12px; }
#bandeja { background-image: linear-gradient(to bottom, #1A8BE8, #0F6BC4); border-left: 1px solid #0A4F9C; padding: 0 10px; }
#menu { background-color: #ffffff; border: 2px solid #0831D9; border-radius: 8px 8px 0 0; }
#cabecera { background-image: linear-gradient(to bottom, #3B78E6, #1E5EDC 60%, #1A4FC2); padding: 8px 12px; border-radius: 6px 6px 0 0; }
#cabecera label { color: #ffffff; }
#izq { background-color: #ffffff; padding: 6px; }
#der { background-color: #D3E5FA; border-left: 1px solid #98B8E8; padding: 6px; }
#pie { background-image: linear-gradient(to bottom, #3A7BD5, #245EDC); padding: 6px 10px; }
.item { background: none; border: none; border-radius: 3px; padding: 5px 8px; }
.item:hover, .item:active { background-color: #3169C6; }
.item:hover label, .item:active label { color: #ffffff; }
.titulo { font-weight: bold; font-size: 13px; color: #1a1a1a; }
.subtitulo { font-size: 11px; color: #6b7280; }
.item-der label { font-size: 13px; color: #1a1a1a; }
.item-der .titulo { font-weight: bold; }
.pie-boton { background-image: linear-gradient(to bottom, #4F8CE8, #2E6BD6); color: #ffffff; border: 1px solid #1C4EBF;
             border-radius: 4px; padding: 4px 10px; font-size: 12px; }
.pie-boton:hover { background-image: linear-gradient(to bottom, #6AA0F0, #3E7BDF); }
.separador { background-color: #C5D8F2; }
#confirmar { background-color: #ffffff; border: 2px solid #0831D9; border-radius: 8px; padding: 14px; }
.confirmar-txt { font-size: 15px; font-weight: bold; color: #1a1a1a; }
.confirmar-sub { font-size: 12px; color: #6b7280; }
.rojo { background-image: linear-gradient(to bottom, #EF5350, #C62828); color: #ffffff; border: 1px solid #8E1B1B; border-radius: 4px; padding: 6px 18px; font-weight: bold; }
.gris { background-image: linear-gradient(to bottom, #F5F5F5, #DDDDDD); color: #1a1a1a; border: 1px solid #9E9E9E; border-radius: 4px; padding: 6px 18px; }
"""


class Menu:
    def __init__(self):
        self.pantalla = Gdk.Screen.get_default()
        self.ancho, self.alto = self.pantalla.get_width(), self.pantalla.get_height()
        self.modo = self.leer_modo()
        self.oculta_id = None
        self.menu_abierto = False
        self.internet = None
        self.idioma = leer_idioma()
        self.T = TEXTOS[self.idioma]

        prov = Gtk.CssProvider(); prov.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(self.pantalla, prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        self.barra = self.crear_barra()
        self.tab = self.crear_tab()
        self.menu = self.crear_menu()
        self.elector = None
        self.confirmacion = None
        self.aplicar_modo(inicial=True)
        GLib.timeout_add_seconds(6, self.refrescar_estado)
        GLib.timeout_add_seconds(3, self.refrescar_tareas)
        GLib.timeout_add_seconds(20, self.refrescar_reloj)
        self.refrescar_estado(); self.refrescar_reloj()
        GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, signal.SIGUSR1, self.alternar_menu)
        GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, signal.SIGUSR2, lambda *a: (self.mostrar_barra(), True)[1])

    # ---------- ventanas ----------
    def ventana_dock(self, nombre, w, h, x, y):
        v = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
        v.set_name(nombre)
        v.set_wmclass("qrbott-menu", "QRBottMenu")
        v.set_type_hint(Gdk.WindowTypeHint.DOCK)
        v.set_decorated(False); v.set_resizable(False)
        v.set_keep_above(True); v.set_skip_taskbar_hint(True); v.set_skip_pager_hint(True)
        v.set_accept_focus(False)
        v.set_default_size(w, h); v.set_size_request(w, h)
        v.move(x, y)
        return v

    def crear_tab(self):
        v = self.ventana_dock("tab", ANCHO_TAB, ALTO_TAB, 0, self.alto - ALTO_TAB)
        ev = Gtk.EventBox(); ev.set_name("tab")
        lab = Gtk.Label(label="▲  QRBott"); lab.set_markup('<span foreground="#ffffff" size="8000" weight="bold">▲  QRBott</span>')
        ev.add(lab)
        ev.connect("button-press-event", lambda *a: (self.mostrar_barra(), self.abrir_menu(), True)[2])
        v.add(ev)
        return v

    def crear_barra(self):
        v = self.ventana_dock("barra", self.ancho, ALTO_BARRA, 0, self.alto - ALTO_BARRA)
        caja = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6); caja.set_name("barra")
        self.boton_inicio = Gtk.Button(); self.boton_inicio.set_name("inicio")
        bi = Gtk.Box(spacing=6); bi.pack_start(icono("inicio", 24), False, False, 0)
        bi.pack_start(Gtk.Label(label="QRBott"), False, False, 0); self.boton_inicio.add(bi)
        self.boton_inicio.connect("clicked", lambda *a: self.alternar_menu())
        caja.pack_start(self.boton_inicio, False, False, 0)
        self.tareas = Gtk.Box(spacing=4); caja.pack_start(self.tareas, False, False, 6)
        # bandeja: internet, impresora, nombre y hora
        bandeja = Gtk.Box(spacing=10); bandeja.set_name("bandeja")
        self.ic_red = Gtk.Box(); bandeja.pack_start(self.ic_red, False, False, 0)
        self.ic_imp = Gtk.Box(); bandeja.pack_start(self.ic_imp, False, False, 0)
        self.lab_nombre = Gtk.Label(); self.lab_nombre.get_style_context().add_class("bandeja")
        bandeja.pack_start(self.lab_nombre, False, False, 0)
        self.reloj = Gtk.Label(); self.reloj.get_style_context().add_class("bandeja")
        bandeja.pack_start(self.reloj, False, False, 0)
        caja.pack_end(bandeja, False, False, 0)
        ev = Gtk.EventBox(); ev.add(caja)
        ev.connect("button-press-event", lambda *a: (self.programar_ocultar(), False)[1])
        v.add(ev)
        return v

    def item_grande(self, ic, titulo, subtitulo, accion):
        b = Gtk.Button(); b.get_style_context().add_class("item"); b.set_relief(Gtk.ReliefStyle.NONE)
        h = Gtk.Box(spacing=10); h.pack_start(icono(ic, 34), False, False, 0)
        vb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        t = Gtk.Label(label=titulo, xalign=0); t.get_style_context().add_class("titulo")
        s = Gtk.Label(label=subtitulo, xalign=0); s.get_style_context().add_class("subtitulo")
        vb.pack_start(t, False, False, 0); vb.pack_start(s, False, False, 0)
        h.pack_start(vb, True, True, 0); b.add(h)
        b.connect("clicked", lambda *a: self.ejecutar(accion))
        return b, s

    def item_chico(self, ic, titulo, accion, negrita=False):
        b = Gtk.Button(); b.get_style_context().add_class("item"); b.get_style_context().add_class("item-der")
        b.set_relief(Gtk.ReliefStyle.NONE)
        h = Gtk.Box(spacing=8); h.pack_start(icono(ic, 24), False, False, 0)
        t = Gtk.Label(label=titulo, xalign=0)
        if negrita: t.get_style_context().add_class("titulo")
        h.pack_start(t, True, True, 0); b.add(h)
        b.connect("clicked", lambda *a: self.ejecutar(accion))
        return b, t

    def crear_menu(self):
        v = Gtk.Window(type=Gtk.WindowType.POPUP)
        v.set_name("menu"); v.set_wmclass("qrbott-menu", "QRBottMenu")
        v.set_decorated(False); v.set_size_request(ANCHO_MENU, -1)
        self.raiz_menu = Gtk.Box(orientation=Gtk.Orientation.VERTICAL); self.raiz_menu.set_name("menu")
        v.add(self.raiz_menu)
        v.connect("button-press-event", self.click_fuera)
        v.connect("key-press-event", lambda w, e: (self.cerrar_menu(), True)[1] if e.keyval == Gdk.KEY_Escape else False)
        self.poblar_menu()
        return v

    def poblar_menu(self):
        """Llena (o vuelve a llenar, al cambiar de idioma) el contenido del menú
        SIN destruir la ventana: destruirla y crear otra dejaba la nueva
        invisible detrás de la caja."""
        T = self.T
        raiz = self.raiz_menu
        for c in raiz.get_children():
            raiz.remove(c)
        # cabecera
        cab = Gtk.Box(spacing=10); cab.set_name("cabecera")
        cab.pack_start(icono("inicio", 40), False, False, 0)
        vb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        n = Gtk.Label(xalign=0); n.set_markup('<span size="13000" weight="bold">%s</span>' % GLib.markup_escape_text(nombre_negocio()))
        s = Gtk.Label(xalign=0); s.set_markup('<span size="9000">QRBott POS OS · %s</span>' % GLib.markup_escape_text(VERSION))
        vb.pack_start(n, False, False, 0); vb.pack_start(s, False, False, 0)
        cab.pack_start(vb, True, True, 0); raiz.pack_start(cab, False, False, 0)
        # columnas
        cols = Gtk.Box()
        izq = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2); izq.set_name("izq"); izq.set_size_request(215, -1)
        b, self.sub_caja = self.item_grande("caja", T["caja"], T["caja_s"], "caja"); izq.pack_start(b, False, False, 0)
        b, self.sub_red = self.item_grande("internet", T["internet"], "…", "internet"); self.boton_red = b; izq.pack_start(b, False, False, 0)
        b, _ = self.item_grande("navegador", T["navegador"], T["navegador_s"], "navegador"); izq.pack_start(b, False, False, 0)
        b, _ = self.item_grande("archivos", T["archivos"], T["archivos_s"], "archivos"); izq.pack_start(b, False, False, 0)
        b, _ = self.item_grande("equipo", T["equipo"], T["equipo_s"], "equipo"); izq.pack_start(b, False, False, 0)
        sep = Gtk.Separator(); sep.get_style_context().add_class("separador"); izq.pack_start(sep, False, False, 6)
        b, _ = self.item_chico("escritorio", T["escritorio"], "escritorio", negrita=True); izq.pack_start(b, False, False, 0)
        der = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2); der.set_name("der"); der.set_size_request(180, -1)
        b, _ = self.item_chico("impresora", T["impresora"], "impresora"); der.pack_start(b, False, False, 0)
        b, _ = self.item_chico("actualizar", T["actualizar"], "actualizar"); der.pack_start(b, False, False, 0)
        b, _ = self.item_chico("informe", T["informe"], "informe"); der.pack_start(b, False, False, 0)
        sep = Gtk.Separator(); sep.get_style_context().add_class("separador"); der.pack_start(sep, False, False, 6)
        b, _ = self.item_chico("idioma", T["idioma"], "idioma"); der.pack_start(b, False, False, 0)
        b, self.lab_fijar = self.item_chico("fijar", T["fijar"], "fijar"); der.pack_start(b, False, False, 0)
        b, _ = self.item_chico("ocultar", T["cerrar"], "cerrar"); der.pack_start(b, False, False, 0)
        cols.pack_start(izq, True, True, 0); cols.pack_start(der, True, True, 0)
        raiz.pack_start(cols, True, True, 0)
        # pie
        pie = Gtk.Box(spacing=8); pie.set_name("pie")
        for ic, txt, acc in (("reiniciar", T["reiniciar"], "reiniciar"), ("apagar", T["apagar"], "apagar")):
            b = Gtk.Button(); b.get_style_context().add_class("pie-boton")
            h = Gtk.Box(spacing=6); h.pack_start(icono(ic, 20), False, False, 0); h.pack_start(Gtk.Label(label=txt), False, False, 0)
            b.add(h); b.connect("clicked", lambda w, a=acc: self.ejecutar(a)); pie.pack_end(b, False, False, 0)
        raiz.pack_start(pie, False, False, 0)
        raiz.show_all()

    # ---------- comportamiento ----------
    def leer_modo(self):
        try:
            m = open(MODO_ARCHIVO).read().strip()
            return m if m in ("oculta", "fija") else "oculta"
        except Exception:
            return "oculta"

    def guardar_modo(self):
        try:
            os.makedirs(os.path.dirname(MODO_ARCHIVO), exist_ok=True)
            open(MODO_ARCHIVO, "w").write(self.modo)
        except Exception as e:
            log("modo", e)

    def aplicar_modo(self, inicial=False):
        if self.modo == "fija":
            self.tab.hide(); self.barra.show_all(); self.barra.move(0, self.alto - ALTO_BARRA)
            self.lab_fijar.set_text(self.T["soltar"])
            pedir("/barra/fija")
        else:
            self.barra.hide(); self.tab.show_all(); self.tab.move(0, self.alto - ALTO_TAB)
            self.lab_fijar.set_text(self.T["fijar"])
            if not inicial:
                pedir("/barra/tuerca")

    def mostrar_barra(self):
        self.tab.hide(); self.barra.show_all(); self.barra.move(0, self.alto - ALTO_BARRA)
        self.refrescar_tareas()
        self.programar_ocultar()

    def programar_ocultar(self, segundos=SEGUNDOS_BARRA):
        if self.oculta_id:
            GLib.source_remove(self.oculta_id); self.oculta_id = None
        if self.modo == "oculta":
            self.oculta_id = GLib.timeout_add_seconds(segundos, self.ocultar_barra)

    def ocultar_barra(self):
        self.oculta_id = None
        if self.menu_abierto or self.modo == "fija":
            return False
        self.barra.hide(); self.tab.show_all(); self.tab.move(0, self.alto - ALTO_TAB)
        return False

    def abrir_menu(self):
        if self.menu_abierto:
            return
        self.menu.show_all()
        alto = self.menu.get_preferred_height()[1]
        self.menu.move(0, self.alto - ALTO_BARRA - alto)
        self.menu_abierto = True
        if self.oculta_id:
            GLib.source_remove(self.oculta_id); self.oculta_id = None
        try:
            seat = Gdk.Display.get_default().get_default_seat()
            seat.grab(self.menu.get_window(), Gdk.SeatCapabilities.ALL_POINTING, True, None, None, None, None)
        except Exception as e:
            log("grab", e)
        self.refrescar_estado()

    def cerrar_menu(self):
        if not self.menu_abierto:
            return
        try:
            Gdk.Display.get_default().get_default_seat().ungrab()
        except Exception:
            pass
        self.menu.hide(); self.menu_abierto = False
        self.programar_ocultar(2)

    def alternar_menu(self, *a):
        if self.menu_abierto:
            self.cerrar_menu()
        else:
            self.mostrar_barra(); self.abrir_menu()
        return True

    def click_fuera(self, w, e):
        al = self.menu.get_allocation()
        log("clic en el menú", int(e.x), int(e.y), "de", al.width, al.height)
        if e.x < 0 or e.y < 0 or e.x > al.width or e.y > al.height:
            self.cerrar_menu()
            # ¿tocó el botón de inicio o la barra? que la barra siga un rato
            return True
        return False

    def ejecutar(self, accion):
        log("acción:", accion)
        if accion in ("apagar", "reiniciar"):
            self.cerrar_menu(); self.confirmar(accion); return
        self.cerrar_menu()
        rutas = {"caja": "/barra/caja", "internet": "/abrir/red", "navegador": "/abrir/navegador",
                 "archivos": "/abrir/archivos", "equipo": "/abrir/equipo", "escritorio": "/barra/escritorio",
                 "impresora": "/impresora/reintentar", "actualizar": "/actualizar", "informe": "/informe"}
        if accion in rutas:
            pedir(rutas[accion])
            if accion in ("escritorio", "actualizar", "informe", "impresora"):
                self.modo_temporal_visible()
        elif accion == "fijar":
            self.modo = "fija" if self.modo == "oculta" else "oculta"
            self.guardar_modo(); self.aplicar_modo()
        elif accion == "idioma":
            self.elegir_idioma()
        elif accion == "cerrar":
            pass

    def elegir_idioma(self):
        """Tres banderas grandes; se toca una y TODO el menú cambia de idioma."""
        if self.elector:
            self.elector.destroy()
        v = Gtk.Window(type=Gtk.WindowType.POPUP); v.set_name("confirmar")
        caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12); caja.set_name("confirmar")
        t = Gtk.Label(label=self.T["elegir_idioma"] + "  ·  Language  ·  语言"); t.get_style_context().add_class("confirmar-txt")
        caja.pack_start(t, False, False, 0)
        h = Gtk.Box(spacing=16, homogeneous=True)
        for cod, nombre, ic in IDIOMAS:
            b = Gtk.Button(); b.get_style_context().add_class("gris")
            vb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            vb.pack_start(icono(ic, 56), False, False, 0)
            lab = Gtk.Label(); lab.set_markup('<span size="12000" weight="%s">%s</span>' % ("bold" if cod == self.idioma else "normal", nombre))
            vb.pack_start(lab, False, False, 0); b.add(vb)
            b.connect("clicked", lambda w, c=cod: (log("bandera", c), v.destroy(), self.cambiar_idioma(c)))
            h.pack_start(b, True, True, 0)
        caja.pack_start(h, False, False, 0)
        no = Gtk.Button(label=self.T["no"]); no.get_style_context().add_class("gris"); no.connect("clicked", lambda *a: v.destroy())
        caja.pack_start(no, False, False, 0)
        v.add(caja); v.show_all()
        w, hh = v.get_preferred_width()[1], v.get_preferred_height()[1]
        v.move((self.ancho - w) // 2, (self.alto - hh) // 2)
        self.elector = v

    def cambiar_idioma(self, cod):
        log("idioma ->", cod)
        self.idioma = cod; self.T = TEXTOS[cod]
        try:
            os.makedirs(os.path.dirname(IDIOMA_ARCHIVO), exist_ok=True)
            open(IDIOMA_ARCHIVO, "w").write(cod)
        except Exception as e:
            log("idioma", e)
        # el menú se vuelve a construir en el idioma nuevo y se REABRE, para
        # que la persona vea el cambio de una vez
        self.cerrar_menu(); self.poblar_menu()
        self.lab_fijar.set_text(self.T["soltar"] if self.modo == "fija" else self.T["fijar"])
        for c in self.tareas.get_children():
            self.tareas.remove(c)
        self.refrescar_estado()
        self.mostrar_barra(); self.abrir_menu()

    def modo_temporal_visible(self):
        # tras una acción larga, la barra se queda un rato para que se vea el estado
        self.mostrar_barra(); self.programar_ocultar(15)

    def confirmar(self, accion):
        if self.confirmacion:
            self.confirmacion.destroy()
        v = Gtk.Window(type=Gtk.WindowType.POPUP); v.set_name("confirmar")
        caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10); caja.set_name("confirmar")
        t = Gtk.Label(label=self.T["p_apagar"] if accion == "apagar" else self.T["p_reiniciar"])
        t.get_style_context().add_class("confirmar-txt")
        s = Gtk.Label(label=self.T["p_sub"]); s.get_style_context().add_class("confirmar-sub")
        caja.pack_start(t, False, False, 0); caja.pack_start(s, False, False, 0)
        h = Gtk.Box(spacing=12, homogeneous=True)
        si = Gtk.Button(label=self.T["si_apagar"] if accion == "apagar" else self.T["si_reiniciar"]); si.get_style_context().add_class("rojo")
        no = Gtk.Button(label=self.T["no"]); no.get_style_context().add_class("gris")
        si.connect("clicked", lambda *a: (v.destroy(), pedir("/" + accion)))
        no.connect("clicked", lambda *a: v.destroy())
        h.pack_start(no, True, True, 0); h.pack_start(si, True, True, 0); caja.pack_start(h, False, False, 0)
        v.add(caja); v.show_all()
        w, hh = v.get_preferred_width()[1], v.get_preferred_height()[1]
        v.move((self.ancho - w) // 2, (self.alto - hh) // 2)
        self.confirmacion = v

    # ---------- estado ----------
    def poner_icono(self, contenedor, nombre, px):
        for c in contenedor.get_children():
            contenedor.remove(c)
        contenedor.pack_start(icono(nombre, px), False, False, 0); contenedor.show_all()

    def refrescar_estado(self):
        def go():
            d = estado()
            imp = ""
            try:
                imp = open("/opt/qrbott/estado-impresora").read().strip()
            except Exception:
                pass
            GLib.idle_add(self.pintar_estado, d, imp)
        threading.Thread(target=go, daemon=True).start()
        return True

    def pintar_estado(self, d, imp):
        if d is None:
            self.sub_red.set_text(self.T["sin_asistente"]); return False
        con = bool(d.get("internet"))
        if con != self.internet:
            self.internet = con
            self.poner_icono(self.ic_red, "internet" if con else "sinred", 22)
        self.sub_red.set_text((self.T["con_cable"] if d.get("cable") else self.T["con"]) if con else self.T["sin"])
        self.poner_icono(self.ic_imp, "impresora", 22)
        self.ic_imp.set_tooltip_text("Impresora: " + (imp or "sin registrar"))
        self.lab_nombre.set_text(nombre_negocio())
        return False

    def refrescar_reloj(self):
        self.reloj.set_text(time.strftime("%H:%M"))
        return True

    def refrescar_tareas(self):
        if not self.barra.get_visible():
            return True
        clases = (("QRBottPanel", "Equipo"), ("QRBottNavegador", "Navegador"), ("QRBottRed", "Internet"), ("pcmanfm", "Mis archivos"))
        vivos = []
        for clase, txt in clases:
            ids = xdotool("search", "--onlyvisible", "--classname" if clase == "pcmanfm" else "--class", clase).split()
            if ids:
                vivos.append((ids[-1], self.T["tareas"].get(txt, txt)))
        actuales = [c.get_label() for c in self.tareas.get_children()]
        if actuales == [t for _, t in vivos]:
            return True
        for c in self.tareas.get_children():
            self.tareas.remove(c)
        for wid, txt in vivos:
            b = Gtk.Button(label=txt); b.get_style_context().add_class("tarea")
            b.connect("clicked", lambda w, i=wid: (xdotool("windowactivate", i), self.programar_ocultar()))
            self.tareas.pack_start(b, False, False, 0)
        self.tareas.show_all()
        return True


if __name__ == "__main__":
    log("menú de inicio arrancando, versión", VERSION)
    Menu()
    Gtk.main()
