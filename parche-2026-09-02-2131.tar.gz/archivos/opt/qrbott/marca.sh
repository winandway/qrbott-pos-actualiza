#!/bin/bash
# ============================================================
#  Possum OS — MARCA PROPIA en todo el sistema
#  El sistema operativo se llama XUNIL OS (se dice «pósum»); el punto de
#  venta que corre encima se llama QRBott. Fabricado por Windoce LLC.
#  Nombre elegido por el dueño el 2-09-2026. Candado 83.
#  Deja el equipo identificado como fabricado por Windoce LLC / QRBott.com
#  en TODO lo que el sistema operativo puede controlar.
# ============================================================
set -uo pipefail   # sin -e: un comando que falle no debe tumbar la instalación
D=/opt/qrbott

# ---------- 1. Identidad del sistema operativo ----------
cat > /etc/os-release <<'OSR'
PRETTY_NAME="Possum OS 1.0"
NAME="Possum OS"
VERSION_ID="1.0"
VERSION="1.0 (Terminal de punto de venta)"
VERSION_CODENAME=caja
ID=possum
ID_LIKE="ubuntu debian"
HOME_URL="https://possumos.com/"
SUPPORT_URL="https://qrbott.com/soporte"
BUG_REPORT_URL="https://qrbott.com/soporte"
PRIVACY_POLICY_URL="https://qrbott.com/privacidad"
VENDOR_NAME="Windoce LLC"
VENDOR_URL="https://windoce.com/"
OSR
ln -sf /etc/os-release /usr/lib/os-release 2>/dev/null || true
true

# ---------- 2. Datos OEM que ve el sistema (lo que Windows llama "OEM info") ----------
mkdir -p /etc/qrbott
cat > /etc/qrbott/oem.conf <<'OEM'
# Datos del fabricante del equipo — QRBott POS
Manufacturer=Windoce LLC
Brand=QRBott
Product=QRBott POS Terminal
SupportURL=https://qrbott.com/soporte
SupportPhone=
Website=https://qrbott.com
Model=QRBott POS
OEM
cp "$D/logo.png" /etc/qrbott/logo.png 2>/dev/null || true

# Mensaje de bienvenida en cualquier consola (si un técnico entra)
cat > /etc/issue <<'ISS'

  Possum OS 1.0   ·   se dice "pósum"
  Terminal de punto de venta QRBott — Developed by Windoce LLC
  Soporte: https://qrbott.com/soporte

ISS
cp /etc/issue /etc/issue.net
rm -f /etc/motd; cat > /etc/motd <<'MOTD'

  ██  Possum OS 1.0   ·   se dice "pósum"
      Terminal de punto de venta QRBott
      Developed by Windoce LLC · https://windoce.com

MOTD
# Quitar la publicidad y los avisos de Ubuntu
rm -f /etc/update-motd.d/10-help-text /etc/update-motd.d/50-motd-news \
      /etc/update-motd.d/00-header /etc/update-motd.d/80-livepatch \
      /etc/update-motd.d/91-contract-ua-esm-status 2>/dev/null || true
sed -i 's/^ENABLED=1/ENABLED=0/' /etc/default/motd-news 2>/dev/null || true

# ---------- 3. Arranque: GRUB con nuestra marca ----------
sed -i 's/^GRUB_DISTRIBUTOR=.*/GRUB_DISTRIBUTOR="Possum OS"/' /etc/default/grub 2>/dev/null || \
  echo 'GRUB_DISTRIBUTOR="Possum OS"' >> /etc/default/grub
grep -q GRUB_BACKGROUND /etc/default/grub || echo 'GRUB_BACKGROUND="/etc/qrbott/fondo-arranque.png"' >> /etc/default/grub

# ---------- 4. Nombre del equipo ----------
echo "qrbott-pos" > /etc/hostname 2>/dev/null || true
hostnamectl set-hostname qrbott-pos 2>/dev/null || true
cat > /etc/machine-info <<'MI'
PRETTY_HOSTNAME=QRBott POS
ICON_NAME=computer-vm
CHASSIS=desktop
DEPLOYMENT=production
MI

# ---------- 5. Nota permanente del fabricante ----------
cat > /etc/qrbott/LEEME.txt <<'NOTA'
QRBott POS Terminal
Fabricado y soportado por Windoce LLC — https://windoce.com
Sistema operativo: Possum OS 1.0 (se dice "pósum") · https://qrbott.com

Este equipo es una terminal de punto de venta. El software se actualiza
solo desde la nube; no requiere mantenimiento local.
Soporte: https://qrbott.com/soporte
NOTA

echo "Marca aplicada: Possum OS 1.0 (Windoce LLC)."

exit 0   # nunca tumbar la instalación
