#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
QRBott POS — asistente de conexión del primer arranque.

Se muestra EN LA MISMA PANTALLA DE LA CAJA (es una página web local), con
nuestra marca y en tres idiomas. Reemplaza a la ventana de sistema `nmtui`, que
salía con fondo morado y un <Quit> en inglés: lo primero que veía el dueño de
la tienda. Ver CANDADOS.md nº 20.

Escucha SOLO en 127.0.0.1 (nadie de fuera puede entrar).
"""
import json, os, subprocess, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

def _direccion_caja():
    """La dirección REAL de la caja, con shell=linux, el serial del equipo, la
    versión y el nombre. La escribe el arranque en /opt/qrbott/url-caja.
    IMPORTANTE: sin «shell=linux» el punto de venta NO reserva los 52 px de la
    barra del sistema y nuestra barra le taparía cosas. Ver CANDADOS.md nº 42."""
    for ruta in ("/var/qrbott-datos/caja/url-caja", "/opt/qrbott/url-caja"):
        try:
            with open(ruta, encoding="utf-8") as f:
                u = f.read().strip()
                if u.startswith("http"):
                    return u
        except Exception:
            continue
    return "https://pos.qrbott.com/pos?shell=linux"

POS = _direccion_caja()
VERSION = "2026-09-02-2145"   # sello de la ISO: para saber de un vistazo cuál está corriendo
PUERTO = 7777

def corre(args, t=25):
    """Ejecuta un comando SIN pasar por el shell (nada de inyección).
    Devuelve (código, salida) juntando lo normal y los errores: el mensaje de
    error es justo lo que hace falta para saber por qué no conecta."""
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=t)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except Exception as e:
        return 1, str(e)

def _registrar_impresion(origen, largo, texto, ok, detalle, dur):
    """Cada orden de imprimir queda escrita (el informe la enseña): de dónde
    vino, cuánto pesaba, cómo empieza, por qué vía salió y cuánto tardó. Sin
    esto se diagnosticaba a ciegas con fotos. Candado 74."""
    try:
        primera = next((l.strip() for l in texto.splitlines() if l.strip()), "")[:40]
        with open("/var/qrbott-datos/caja/impresion.log", "a") as f:
            f.write("%s | %s | %d bytes | %s | %s | %.1fs | %s\n" % (
                time.strftime("%Y-%m-%d %H:%M:%S"), origen or "(sin origen)", largo,
                "OK" if ok else "FALLO", detalle, dur, primera))
    except Exception:
        pass

def _estado_actualiza():
    try:
        est = open("/opt/qrbott/estado-actualiza").read().strip()
    except Exception:
        est = "(todavía no ha buscado)"
    try:
        cola = open("/var/qrbott-datos/caja/actualiza.log").read().splitlines()[-8:]
    except Exception:
        cola = []
    return est, "\n".join(cola)

IMPRESORAS_EXTRA = "/var/qrbott-datos/impresoras.json"   # las que agrega el dueño (sobreviven al reinicio)

def _impresoras_extra():
    try:
        d = json.load(open(IMPRESORAS_EXTRA))
        return d if isinstance(d, list) else []
    except Exception:
        return []

def _guardar_impresoras_extra(lista):
    try:
        os.makedirs(os.path.dirname(IMPRESORAS_EXTRA), exist_ok=True)
        json.dump(lista, open(IMPRESORAS_EXTRA, "w"), indent=1, ensure_ascii=False)
    except Exception as e:
        print("impresoras.json:", e, file=sys.stderr)

def _leer_impresoras():
    """Colas registradas (nombre, estado, URI, predeterminada) y aparatos
    detectados que todavía no tienen cola."""
    _, colas = corre(["lpstat", "-p"], t=10)
    _, uris = corre(["lpstat", "-v"], t=10)
    _, pred = corre(["lpstat", "-d"], t=10)
    # Solo puertos locales y con tope de tiempo: sin esto la página tardaba
    # 15-20 s rastreando la red (visto en la VM).
    _, aparatos = corre(["lpinfo", "--timeout", "4", "--exclude-schemes", "dnssd,snmp,socket,ipp,ipps,lpd,http,https,beh,implicitclass", "-v"], t=12)
    predet = pred.split(":")[-1].strip() if ":" in pred else ""
    uri_de = {}
    for l in uris.splitlines():
        # "device for QRBott-Ticket: file:/dev/lp0"
        if l.startswith("device for ") and ":" in l[11:]:
            n, u = l[11:].split(":", 1)
            uri_de[n.strip()] = u.strip()
    lista = []
    for l in colas.splitlines():
        if not l.startswith("printer "):
            continue
        partes = l.split()
        n = partes[1]
        if " is idle" in l:
            est, bien = "lista", True
        elif "printing" in l:
            est, bien = "imprimiendo", True
        elif "disabled" in l or "stopped" in l:
            est, bien = "DETENIDA: " + (l.split("-", 1)[1].strip() if "-" in l else ""), False
        else:
            est, bien = l.split(n, 1)[1].strip(), True
        try:
            ppd = open("/etc/cups/ppd/%s.ppd" % n, errors="replace").read()
        except Exception:
            ppd = ""
        tipo = ("térmica 58 mm (driver QRBott)" if "qrbott-escpos-paso" in ppd or "qrbott-pdf-a-escpos" in ppd
                else ("cruda (ESC/POS directo)" if not ppd else "con driver propio"))
        lista.append({"nombre": n, "estado": est, "bien": bien, "uri": uri_de.get(n, ""),
                      "predeterminada": n == predet, "tipo": tipo})
    usadas = set(uri_de.values())
    detectados = []
    for l in aparatos.splitlines():
        partes = l.split(None, 1)
        if len(partes) < 2:
            continue
        clase, uri = partes[0], partes[1].strip()
        if clase not in ("direct", "serial") or uri in usadas:
            continue
        if uri.startswith(("usb://", "parallel:", "serial:", "hp:")):
            detectados.append(uri)
    return lista, detectados, predet

ANIO_MARCA = "2026"

def _nombre_negocio():
    """El nombre que el POS puso en la direccion de la caja; si no, el del
    equipo. (Vive en el menu con otro nombre: aqui hace falta su propia copia.)"""
    try:
        import urllib.parse as up
        url = open("/var/qrbott-datos/caja/url-caja").read().strip()
        n = up.parse_qs(up.urlparse(url).query).get("nombre", [""])[0].strip()
        if n:
            return n
    except Exception:
        pass
    try:
        return open("/opt/qrbott/nombre-equipo").read().strip() or "QRBott POS"
    except Exception:
        return "QRBott POS"

def pagina_acerca():
    """«Acerca de este equipo» — como el «Acerca de esta Mac»: qué sistema
    tiene, quién lo hizo, cuándo, para qué, y los datos del equipo. Pedido por
    el dueño el 2-09-2026: la marca tiene que estar en todas partes. Candado 85."""
    def c1(args, t=10):
        _, o = corre(args, t=t)
        return (o or "").strip()
    esc = lambda t: (t or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    cpu = ""
    try:
        for l in open("/proc/cpuinfo"):
            if l.startswith("model name"):
                cpu = l.split(":", 1)[1].strip(); break
    except Exception:
        pass
    nucleos = c1(["nproc"]) or "?"
    mem = ""
    try:
        for l in open("/proc/meminfo"):
            if l.startswith("MemTotal"):
                mem = "%.1f GB" % (int(l.split()[1]) / 1048576.0); break
    except Exception:
        pass
    disco = c1(["bash", "-c", "df -h /var/qrbott-datos | tail -1 | awk '{print $2\" en total, \"$4\" libres\"}'"])
    pantalla = c1(["bash", "-c", "DISPLAY=:0 xrandr 2>/dev/null | awk '/\\*/{print $1; exit}'"]) or "?"
    equipo = c1(["/opt/qrbott/identidad.sh"]) or "?"
    base = ""
    try:
        for l in open("/etc/lsb-release"):
            if l.startswith("DISTRIB_DESCRIPTION"):
                base = l.split("=", 1)[1].strip().strip('"'); break
    except Exception:
        pass
    kernel = c1(["uname", "-r"])
    encendido = c1(["uptime", "-p"])
    impresora = ""
    try:
        impresora = open("/opt/qrbott/estado-impresora").read().strip()
    except Exception:
        pass
    impresora = "lista" if impresora.startswith("OK") else (impresora or "sin registrar")
    est_act, _ = _estado_actualiza()
    nombre = _nombre_negocio()
    # La version que MANDA es la del archivo (la que dejo el ultimo parche),
    # no la constante del codigo: si difieren, el codigo miente. Candado 49.
    try:
        ver_real = open("/opt/qrbott/version").read().strip() or VERSION
    except Exception:
        ver_real = VERSION
    pos_corto = POS.split("?")[0].replace("https://", "").replace("http://", "").rstrip("/")
    filas = [
        ("Sistema operativo", "Possum OS 1.0 &nbsp;<span class='pron'>Siempre puede.</span>"),
        ("Versi&oacute;n instalada", "build " + esc(ver_real)),
        ("Punto de venta", "QRBott &middot; " + esc(pos_corto)),
        ("Actualizaciones", esc(est_act)),
        ("Nombre del equipo", esc(nombre)),
        ("Identificador", esc(equipo)),
        ("Procesador", esc(cpu) + (" (%s n&uacute;cleos)" % nucleos if nucleos else "")),
        ("Memoria", esc(mem)),
        ("Disco de datos", esc(disco)),
        ("Pantalla", esc(pantalla)),
        ("Impresora de tickets", esc(impresora)),
        ("Encendido", esc(encendido)),
        ("Base del sistema", esc(base) + " &middot; n&uacute;cleo " + esc(kernel)),
    ]
    tabla = "".join('<tr><td>%s</td><td>%s</td></tr>' % (k, v) for k, v in filas)
    return """<!doctype html><html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Acerca de este equipo &middot; Possum OS</title><style>
body{margin:0;background:#0B1D3A;color:#EAF0FA;font:15px/1.6 "DejaVu Sans",sans-serif}
.hero{text-align:center;padding:34px 20px 26px}
.hero img{width:104px;height:auto}
h1{margin:14px 0 2px;font-size:34px;letter-spacing:-.5px}
.pron{color:#9FB3D9;font-size:13px;font-weight:normal}
.lema{color:#22A559;font-size:22px;font-weight:500;margin:6px 0 0}
.sub{color:#9FB3D9;font-size:15px;margin:0}
main{max-width:760px;margin:0 auto;padding:0 22px 40px}
table{width:100%;border-collapse:collapse;background:#12294B;border-radius:14px;overflow:hidden}
td{padding:11px 16px;border-bottom:1px solid #1D3A63;vertical-align:top}
td:first-child{color:#9FB3D9;width:42%}
tr:last-child td{border-bottom:none}
h2{font-size:14px;letter-spacing:1px;text-transform:uppercase;color:#7E93B8;margin:26px 0 10px}
.caja{background:#12294B;border-radius:14px;padding:16px 18px}
a{color:#7FC9FF}
.pie{text-align:center;color:#7E93B8;font-size:13px;margin-top:26px;line-height:1.9}
.pie b{color:#EAF0FA}
</style></head><body>
<div class="hero">
  <img src="/possum.svg" alt="Possum OS">
  <h1>Possum OS <span style="color:#22A559">1.0</span></h1>
  <p class="lema">Siempre puede.</p>
  <p class="sub">build """ + esc(ver_real) + """ &nbsp;&middot;&nbsp; se dice &laquo;p&oacute;sum&raquo;</p>
</div>
<main>
<h2>Este equipo</h2>
<table>""" + tabla + """</table>

<h2>Qui&eacute;n lo hizo</h2>
<div class="caja">
  <b>Developed by Windoce LLC</b> &nbsp;&middot;&nbsp; <a href="https://windoce.com" target="_blank" rel="noopener noreferrer">windoce.com</a><br>
  Dise&ntilde;ado y construido en """ + ANIO_MARCA + """ para las terminales de punto de venta QRBott.<br>
  &copy; """ + ANIO_MARCA + """ qrbott.com &nbsp;|&nbsp; All rights reserved. Developed by
  <a href="https://windoce.com" target="_blank" rel="noopener noreferrer">Windoce LLC</a>
</div>

<h2>Para qu&eacute; se hizo</h2>
<div class="caja">
  Possum OS es el sistema operativo de la caja: arranca sola en el punto de venta,
  guarda la sesi&oacute;n y la conexi&oacute;n, habla con la impresora de tickets y con el
  lector de c&oacute;digos, protege el disco para que un ap&oacute;n no rompa nada, y se
  actualiza sola desde la nube con parches firmados &mdash; sin t&eacute;cnicos ni USB.<br><br>
  El nombre viene del lat&iacute;n <i>possum</i>: &laquo;yo puedo&raquo; &mdash; de ah&iacute;
  sale su lema, <b>&laquo;Siempre puede&raquo;</b>. Y lleva <b>POS</b> (point of sale)
  en sus tres primeras letras. Se pronuncia &laquo;p&oacute;sum&raquo;; el animal es la
  zarig&uuml;eya, que en ingl&eacute;s se dice <i>opossum</i>.
</div>

<h2>Soporte</h2>
<div class="caja">
  <a href="https://qrbott.com/soporte" target="_blank" rel="noopener noreferrer">qrbott.com/soporte</a><br>
  Antes de llamar, toca <b>Generar informe</b> en el men&uacute; y manda el archivo:
  trae todo lo que soporte necesita.
</div>

<p class="pie"><b>Possum OS 1.0</b> &middot; build """ + esc(ver_real) + """<br>
Terminal de punto de venta <b>QRBott</b> &middot; Developed by <b>Windoce LLC</b></p>
</main></body></html>"""

def pagina_impresoras():
    lista, detectados, predet = _leer_impresoras()
    esc = lambda t: (t or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
    filas = ""
    for i in lista:
        filas += ('<div class="imp %s"><div class="cab"><b>%s</b>%s<span class="est">%s</span></div>'
                  '<div class="det">%s &middot; <code>%s</code></div>'
                  '<div class="acc"><button onclick="orden(\'prueba\',\'%s\')">Imprimir prueba</button>'
                  '%s%s</div></div>' % (
                      "ok" if i["bien"] else "mal", esc(i["nombre"]),
                      ' <span class="pred">predeterminada</span>' if i["predeterminada"] else "",
                      esc(i["estado"]), esc(i["tipo"]), esc(i["uri"]), esc(i["nombre"]),
                      "" if i["predeterminada"] else '<button onclick="orden(\'predeterminada\',\'%s\')">Usar como predeterminada</button>' % esc(i["nombre"]),
                      "" if i["nombre"] == "QRBott-Ticket" else '<button class="gris" onclick="quitar(\'%s\')">Quitar</button>' % esc(i["nombre"])))
    if not filas:
        filas = '<div class="imp mal"><b>No hay ninguna impresora registrada.</b> Toca «Reintentar la integrada» o agrega una de las detectadas abajo.</div>'
    nuevos = ""
    for u in detectados:
        sug = "USB-" + str(abs(hash(u)) % 1000)
        if u.startswith("usb://"):
            marca = u[6:].split("?")[0].replace("/", "-")[:24]
            sug = "".join(c if c.isalnum() or c in "-_" else "-" for c in marca) or sug
        nuevos += ('<div class="imp nueva"><div class="cab"><b>Detectada, sin registrar</b></div>'
                   '<div class="det"><code>%s</code></div>'
                   '<div class="acc"><input id="n-%d" value="%s" maxlength="32" placeholder="Nombre de la impresora">'
                   '<select id="t-%d"><option value="termica58">T&eacute;rmica de tickets 58 mm (driver QRBott)</option>'
                   '<option value="cruda">Cruda: recibe ESC/POS tal cual (80 mm u otra t&eacute;rmica)</option></select>'
                   '<button onclick="agregar(\'%s\',%d)">Agregar</button></div></div>'
                   % (esc(u), abs(hash(u)), esc(sug), abs(hash(u)), esc(u), abs(hash(u))))
    if not nuevos:
        nuevos = '<div class="nota">No se detecta ninguna impresora nueva. Con&eacute;ctala por USB, enci&eacute;ndela y toca «Buscar de nuevo».</div>'
    return """<!doctype html><html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Impresoras · QRBott POS</title><style>
body{margin:0;background:#0b1220;color:#ecf0f4;font:15px/1.5 "DejaVu Sans",sans-serif}
.top{background:linear-gradient(#3B78E6,#1E5EDC);padding:16px 22px;display:flex;align-items:center;gap:14px}
.top h1{margin:0;font-size:20px}.top small{opacity:.85}
main{padding:18px 22px;max-width:960px}
.imp{background:#16223a;border:1px solid #22314f;border-radius:10px;padding:14px 16px;margin:0 0 12px}
.imp.ok{border-left:6px solid #1D9E75}.imp.mal{border-left:6px solid #E24B4A}.imp.nueva{border-left:6px solid #EF9F27}
.cab{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.cab b{font-size:17px}
.est{margin-left:auto;font-size:13px;color:#8ee9bd}.mal .est{color:#f5a5a5}
.pred{background:#1D9E75;color:#03241a;border-radius:6px;padding:1px 8px;font-size:12px;font-weight:bold}
.det{font-size:13px;color:#9aa6bf;margin:4px 0 8px}code{color:#c9d4ea}
.acc{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
button{padding:10px 16px;font-size:14px;border-radius:8px;border:1px solid #1d5c40;background:#0f2a1e;color:#8ee9bd;cursor:pointer}
button.gris{border-color:#3a4763;background:#1c2740;color:#c9d4ea}
input,select{padding:9px 10px;font-size:14px;border-radius:8px;border:1px solid #3a4763;background:#0b1220;color:#ecf0f4}
h2{font-size:16px;margin:22px 0 10px;color:#9fb3d9;text-transform:uppercase;letter-spacing:.5px}
.nota{color:#9aa6bf;font-size:14px}
#msg{position:fixed;left:0;right:0;bottom:0;background:#1E5EDC;color:#fff;padding:12px 22px;font-size:15px;display:none}
</style></head><body>
<div class="top"><img src="/possum.svg" alt="" style="height:40px"><div><h1>Impresoras</h1><small>Possum OS &middot; las que est&aacute;n registradas, su estado, y c&oacute;mo agregar una nueva</small></div></div>
<main>
<h2>Registradas</h2>""" + filas + """
<div class="acc" style="margin:4px 0 10px"><button class="gris" onclick="orden('reintegrada','')">Reintentar la integrada</button><button class="gris" onclick="location.reload()">Buscar de nuevo</button></div>
<h2>Detectadas sin registrar</h2>""" + nuevos + """
<p class="nota" style="margin-top:22px">La <b>predeterminada</b> es la que usa la caja al imprimir un ticket. Si agregas una t&eacute;rmica USB y quieres que los tickets salgan por ella, m&aacute;rcala como predeterminada. Las que agregues quedan guardadas: vuelven solas al encender el equipo.</p>
</main>
<div id="msg"></div>
<script>
function aviso(t){var m=document.getElementById("msg");m.textContent=t;m.style.display="block";}
function orden(que,nombre){aviso(que==="prueba"?"Mandando la prueba a "+nombre+"…":"Un momento…");
  fetch("/impresoras/"+que+"?nombre="+encodeURIComponent(nombre),{method:"POST"}).then(function(r){return r.json();}).then(function(d){
    aviso(d.ok?(d.detalle||"Listo."):("No se pudo: "+(d.detalle||"")));if(que!=="prueba"){setTimeout(function(){location.reload();},1500);}
  }).catch(function(){aviso("No se pudo hablar con el equipo.");});}
function quitar(nombre){if(!confirm("¿Quitar la impresora "+nombre+"?"))return;orden("quitar",nombre);}
function agregar(uri,k){var n=document.getElementById("n-"+k).value.trim(),t=document.getElementById("t-"+k).value;
  if(!n){aviso("Escribe un nombre para la impresora.");return;}
  aviso("Registrando "+n+"…");
  fetch("/impresoras/agregar",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({nombre:n,uri:uri,tipo:t})}).then(function(r){return r.json();}).then(function(d){
    aviso(d.ok?"Impresora "+n+" registrada. Toca «Imprimir prueba» para comprobarla.":("No se pudo: "+(d.detalle||"")));setTimeout(function(){location.reload();},1800);
  }).catch(function(){aviso("No se pudo hablar con el equipo.");});}
</script></body></html>"""

def hay_internet():
    c, _ = corre(["curl", "-sf", "-m", "4", "-o", "/dev/null", POS], t=8)
    return c == 0

def cable_conectado():
    _, s = corre(["nmcli", "-t", "-f", "TYPE,STATE", "device"])
    return any(l.startswith("ethernet:connected") for l in s.splitlines())

# --------------------------------------------------------------------------
#  El escaneo de Wi-Fi va POR SU CUENTA, cada 20 segundos, en segundo plano.
#  OJO: pedir un escaneo nuevo cada 3 segundos (una vez por consulta) hace que
#  el anterior NUNCA termine, y la lista se queda vacía para siempre —
#  "Buscando redes Wi-Fi…" eterno. Pasó en el equipo real. Ver CANDADOS.md nº 22.
# --------------------------------------------------------------------------
_estado = {"redes": [], "motivo": "buscando", "ultimo": 0,
           "internet": False, "cable": False, "datos": {}}
_cerrojo = threading.Lock()

def hay_tarjeta_wifi():
    _, s = corre(["nmcli", "-t", "-f", "TYPE", "device"])
    return any(l.strip() == "wifi" for l in s.splitlines())

def radio_encendida():
    _, s = corre(["nmcli", "radio", "wifi"])
    return "enabled" in s.lower()

def datos_equipo():
    """Línea discreta para soporte: con una foto de la pantalla basta."""
    _, s1 = corre(["nmcli", "-t", "-f", "DEVICE,TYPE,STATE", "device"])
    wifi = [l.split(":")[0] for l in s1.splitlines() if ":wifi:" in l]
    cabl = [l.split(":")[0] for l in s1.splitlines() if ":ethernet:" in l]
    try:
        serie = subprocess.run(["/opt/qrbott/identidad.sh"], capture_output=True,
                               text=True, timeout=10).stdout.strip()
    except Exception:
        serie = ""
    return {"equipo": serie or "?",
            "wifi": wifi[0] if wifi else "no hay",
            "cable": cabl[0] if cabl else "no hay",
            "radio": "encendida" if radio_encendida() else "apagada",
            "version": VERSION}

def dispositivo_wifi():
    """Devuelve (nombre, estado) de la tarjeta Wi-Fi, o (None, None)."""
    _, s = corre(["nmcli", "-t", "-f", "DEVICE,TYPE,STATE", "device"])
    for l in s.splitlines():
        p = l.split(":")
        if len(p) >= 3 and p[1] == "wifi":
            return p[0], p[2]
    return None, None

def despertar_wifi(dev):
    """Intenta dejar la tarjeta lista para escanear. Devuelve lo que hizo."""
    hecho = []
    corre(["rfkill", "unblock", "all"], t=10);          hecho.append("rfkill")
    corre(["nmcli", "radio", "wifi", "on"], t=10)
    corre(["nmcli", "device", "set", dev, "managed", "yes"], t=10); hecho.append("managed")
    corre(["ip", "link", "set", dev, "up"], t=10);      hecho.append("link-up")
    return hecho

def escanear():
    """Un solo escaneo. Devuelve (lista, motivo, detalle)."""
    dev, estado = dispositivo_wifi()
    if not dev:
        return [], "sin-tarjeta", "no aparece ninguna tarjeta wifi"
    if not radio_encendida():
        corre(["nmcli", "radio", "wifi", "on"], t=10)
        corre(["rfkill", "unblock", "wifi"], t=10)
        time.sleep(2)
        if not radio_encendida():
            return [], "apagada", "la radio sigue apagada"

    detalle = "estado=%s" % (estado or "?")

    # Si la tarjeta no está lista para escanear, intentar despertarla.
    if estado in ("unmanaged", "unavailable", "disconnecting", None):
        despertar_wifi(dev)
        time.sleep(4)
        dev2, estado2 = dispositivo_wifi()
        detalle += " -> %s" % (estado2 or "?")
        if estado2 in ("unmanaged", "unavailable"):
            corre(["systemctl", "restart", "NetworkManager"], t=40)
            time.sleep(8)
            _, estado3 = dispositivo_wifi()
            detalle += " -> %s (reinicio NM)" % (estado3 or "?")

    # Escanear con paciencia: el escaneo tarda, y a veces hay que insistir.
    err = ""
    lineas = ""
    for intento in (1, 2, 3):
        c, salida = corre(["nmcli", "device", "wifi", "rescan"], t=25)
        if c != 0:
            _, e = corre(["nmcli", "device", "wifi", "rescan"], t=25)
            err = (salida or e or "").strip().replace("\n", " ")[:90]
        time.sleep(6)
        _, lineas = corre(["nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY", "device", "wifi", "list"])
        if lineas.strip():
            break
    if err:
        detalle += " · " + err
    s = lineas
    vistas, salida = set(), []
    for linea in s.splitlines():
        p = linea.split(":")
        if len(p) < 3 or not p[0] or p[0] in vistas:
            continue
        vistas.add(p[0])
        salida.append({"nombre": p[0],
                       "senal": int(p[1]) if p[1].isdigit() else 0,
                       "abierta": p[2].strip() == ""})
    salida.sort(key=lambda r: -r["senal"])
    return salida[:12], ("ok" if salida else "sin-redes"), detalle

def bucle_conexion():
    """Comprueba la conexión cada 3 s, en segundo plano. Así la pantalla
    responde al instante y nunca se queda esperando por la red."""
    while True:
        i, c = hay_internet(), cable_conectado()
        with _cerrojo:
            _estado["internet"], _estado["cable"] = i, c
        time.sleep(3)

def bucle_escaneo():
    primera = True
    while True:
        redes, motivo, detalle = escanear()
        datos = datos_equipo()
        datos["detalle"] = detalle
        with _cerrojo:
            _estado["redes"], _estado["motivo"] = redes, motivo
            _estado["datos"] = datos
            _estado["ultimo"] = int(time.time())
        time.sleep(20 if not primera else 8)
        primera = False

def redes_wifi():
    with _cerrojo:
        return list(_estado["redes"]), _estado["motivo"]



def pagina_equipo():
    """Lo que hace falta saber del equipo, en palabras normales y en pantalla.
    Existe porque la impresora fallaba y no había forma de ver POR QUÉ sin
    entrar por consola. Ver CANDADOS.md nº 34."""
    def leer(ruta):
        try:
            with open(ruta, encoding="utf-8", errors="replace") as f:
                return f.read().strip()
        except Exception:
            return ""

    est = leer("/opt/qrbott/estado-impresora")
    _, colas = corre(["lpstat", "-p"], t=10)
    _, puertos = corre(["lpinfo", "-v"], t=15)
    _, usb = corre(["lsusb"], t=10)
    _, aparatos = corre(["bash", "-c",
        "ls -l /dev/usb/lp* /dev/lp* /dev/ttyUSB* /dev/ttyS[0-3] /dev/parport* 2>/dev/null"], t=10)

    # ¿Está vivo el motor de impresión? Es lo PRIMERO que hay que saber: sin él
    # no hay impresora posible, y era justo lo que fallaba (candado 37).
    _, marcha = corre(["lpstat", "-r"], t=10)
    motor_vivo = "is running" in marcha.lower()

    if not motor_vivo:
        cabecera = ("mal", "El sistema de impresión NO está corriendo",
                    "Sin él, el equipo no puede tener ninguna impresora. "
                    "Toca «Reintentar» abajo; si sigue igual, enséñale esta "
                    "pantalla a soporte.")
    elif est.startswith("OK"):
        cabecera = ("ok", "La impresora está lista",
                    "Ya puedes imprimir tickets. Conectada en: " +
                    (est.split(":", 1)[1] if ":" in est else est))
    elif "sin-impresora" in est:
        cabecera = ("mal", "No hay ninguna impresora conectada",
                    "El sistema de impresión funciona, pero no ve ninguna "
                    "impresora. Comprueba que esté encendida y enchufada.")
    elif est:
        cabecera = ("mal", "NO se pudo registrar la impresora", est)
    else:
        cabecera = ("mal", "Todavía no se ha buscado la impresora",
                    "Toca «Reintentar» abajo.")

    # El puerto paralelo: ahí vive la impresora INTEGRADA de este equipo (LPT1).
    _, paralelo = corre(["bash", "-c",
        "ls -l /dev/lp* /dev/parport* 2>/dev/null || echo 'no hay ningún /dev/lp*'"], t=10)
    _, modulos = corre(["bash", "-c",
        "lsmod 2>/dev/null | grep -E '^(lp|parport|parport_pc|ppdev) ' || echo 'los módulos NO están cargados'"], t=10)
    # OJO: no basta con buscar "/dev/lp" en el texto — el propio mensaje de
    # error lo contiene y daba un falso positivo. Se pregunta de verdad.
    cod_lp, _ = corre(["bash", "-c",
        "ls /dev/lp0 /dev/lp1 /dev/usb/lp0 >/dev/null 2>&1"], t=10)
    hay_lp = (cod_lp == 0)

    # El escáner integrado: es un teclado a ojos del sistema. Se listan los que
    # hay, para distinguirlo del teclado de verdad y del táctil.
    _, entradas = corre(["bash", "-c",
        "grep -E '^N: Name' /proc/bus/input/devices 2>/dev/null | sed 's/N: Name=//' "
        "|| echo 'no se pudo leer'"], t=10)

    # Cuánto ha guardado la caja EN EL DISCO de este equipo. IndexedDB no es
    # memoria ni nube: son archivos dentro del perfil, en el SSD. Esto lo
    # enseña en números para que se vea crecer. Candado 42.
    _, guardado = corre(["bash", "-c",
        "du -sh /var/qrbott-datos/caja/Default/IndexedDB "
        "/var/qrbott-datos/caja/Default/'Service Worker' "
        "/var/qrbott-datos/caja 2>/dev/null | sed 's|/var/qrbott-datos/caja/Default/||;"
        "s|/var/qrbott-datos/caja|TODO EL PERFIL|'"], t=20)
    _, disco = corre(["bash", "-c",
        "df -h /var/qrbott-datos 2>/dev/null | tail -1 | "
        "awk '{print \"usado \"$3\"  ·  libre \"$4\"  de \"$2}'"], t=10)

    pantallas = leer("/var/qrbott-datos/caja/pantallas.log")[-1500:]
    _, mem = corre(["free", "-m"], t=10)
    _, grafica = corre(["bash", "-c", "glxinfo -B 2>/dev/null | grep -i -m2 'renderer\\|OpenGL'"], t=15)

    def bloque(titulo, texto):
        if not (texto or "").strip():
            texto = "(vacío)"
        return ("<h2>" + titulo + "</h2><pre>" +
                texto.replace("&", "&amp;").replace("<", "&lt;") + "</pre>")

    return ("""<!doctype html><html lang="es"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Estado del equipo · QRBott POS</title><style>
*{box-sizing:border-box}
body{margin:0;padding:24px;background:#0d1420;color:#ecf0f4;
 font:15px/1.5 system-ui,-apple-system,Arial,sans-serif}
h1{font-size:22px;margin:0 0 4px}
.v{color:#7885a4;font-size:13px;margin-bottom:20px}
.caja{border-radius:12px;padding:16px 18px;margin-bottom:20px;border:1px solid #22314f;
 background:#16223a}
.ok{background:#0f2a1e;border-color:#1d5c40}
.mal{background:#3a1620;border-color:#5c2230}
.caja b{font-size:17px;display:block;margin-bottom:4px}
h2{font-size:14px;color:#8fa3c8;margin:22px 0 6px;text-transform:uppercase;
 letter-spacing:.5px}
pre{background:#0a1018;border:1px solid #1b2740;border-radius:8px;padding:12px;
 overflow-x:auto;font-size:12px;color:#c8d4e6;margin:0}
.pie{margin-top:28px;color:#4a5878;font-size:12px}
</style>
<h1>Estado del equipo</h1>
<div class="v">Possum OS 1.0 &middot; build """ + VERSION + """ &middot; Developed by Windoce LLC</div>
<div class="caja """ + cabecera[0] + """"><b>""" + cabecera[1] + """</b>""" +
    cabecera[2].replace("<", "&lt;") + """</div>
<h2>Resumen</h2>
<div class="caja" style="font-size:15px;line-height:2">""" +
    ("&#10003; El motor de impresi&oacute;n est&aacute; corriendo"
     if motor_vivo else
     "&#10007; El motor de impresi&oacute;n NO est&aacute; corriendo") + "<br>" +
    ("&#10003; El puerto paralelo est&aacute; encendido (ah&iacute; va la impresora integrada)"
     if hay_lp else
     "&#10007; El puerto paralelo NO aparece: la impresora integrada no se puede ver") + "<br>" +
    ("&#10003; La impresora est&aacute; registrada"
     if est.startswith("OK") else
     "&#10007; La impresora no est&aacute; registrada") + "<br>" +
    "Aparatos de entrada detectados (uno de ellos debe ser el esc&aacute;ner): " +
    str(len([x for x in entradas.splitlines() if x.strip()])) + "<br>" +
    "Guardado en el disco por la caja: <b>" +
    (guardado.strip().splitlines()[-1].split()[0] if guardado.strip() else "0") +
    "</b> &nbsp; &middot; &nbsp; Disco: " + disco.strip() +
    """</div>""" +
    bloque("Lo que la caja tiene guardado en el disco de este equipo", guardado) +
    bloque("Disco del equipo", disco) +
    bloque("QRBott Actualiza (parches desde la nube) — estado: " + _estado_actualiza()[0],
           _estado_actualiza()[1] or "(sin registro todavía)") +
    bloque("Motor de impresión", marcha or "(sin respuesta)") +
    bloque("Puerto paralelo (la impresora integrada va por aquí)", paralelo) +
    bloque("Controladores del puerto paralelo", modulos) +
    bloque("Aparatos de entrada (teclado, táctil y escáner integrado)", entradas) +
    bloque("Impresoras registradas", colas) +
    bloque("Puertos que ve el sistema de impresión", puertos) +
    bloque("Aparatos conectados por USB", usb) +
    bloque("Puertos de impresora presentes", aparatos) +
    bloque("Pantallas y táctil", pantallas) +
    bloque("Memoria", mem) +
    bloque("Aceleración gráfica", grafica) +
    """<div style="margin:-8px 0 20px">
<button id="inf" style="padding:11px 18px;font-size:15px;border-radius:8px;
 border:1px solid #1d5c40;background:#0f2a1e;color:#8ee9bd;cursor:pointer;
 margin-right:10px">Generar informe para soporte</button>
<button id="prueba" style="padding:11px 18px;font-size:15px;border-radius:8px;
 border:1px solid #1d5c40;background:#0f2a1e;color:#8ee9bd;cursor:pointer;
 margin-right:10px">Imprimir PRUEBA (directa, sin motor)</button>
<button id="reint" style="padding:11px 18px;font-size:15px;border-radius:8px;
 border:1px solid #22314f;background:#16223a;color:#ecf0f4;cursor:pointer">
Reintentar la impresora</button>
<button id="act" style="padding:11px 18px;font-size:15px;border-radius:8px;
 border:1px solid #4a3a12;background:#2a2210;color:#f0c86a;cursor:pointer;
 margin-left:10px">Buscar actualizaci&oacute;n ahora</button>
<span id="reintmsg" style="margin-left:12px;font-size:13px;color:#7885a4"></span>
</div>
<script>
document.getElementById("prueba").addEventListener("click", function(){
  var m = document.getElementById("reintmsg");
  m.textContent = "Mandando el ticket de prueba directo al puerto\u2026";
  fetch("/imprimir", {method: "POST", body: ""})
    .then(function(r){ return r.json(); })
    .then(function(d){
      m.textContent = d.ok
        ? "Enviado al puerto " + d.detalle + ". Si sali\u00F3 papel, la impresora FUNCIONA."
        : "No se pudo: " + d.detalle;
    }).catch(function(){ m.textContent = "No se pudo mandar la prueba."; });
});
document.getElementById("act").addEventListener("click", function(){
  var m = document.getElementById("reintmsg");
  m.textContent = "Buscando un parche firmado en la nube\u2026";
  fetch("/actualizar", {method: "POST", body: ""}).then(function(){
    var n = 0;
    var t = setInterval(function(){
      fetch("/actualiza/estado").then(function(r){ return r.json(); }).then(function(d){
        m.textContent = "Actualiza: " + d.estado;
        n++;
        if (n > 40 || /^(AL-DIA|ACTUALIZADO|REVERTIDO|SIN-|FIRMA|REQUIERE|DESCARGA-FALLO|APLICAR-FALLO|HUELLA|PAQUETE|MANIFIESTO|CANAL|DISCO)/.test(d.estado)) {
          clearInterval(t);
          if (/^ACTUALIZADO/.test(d.estado)) { setTimeout(function(){ location.reload(); }, 2500); }
        }
      }).catch(function(){});
    }, 3000);
  }).catch(function(){ m.textContent = "No se pudo pedir la actualizaci\u00F3n."; });
});
document.getElementById("inf").addEventListener("click", function(){
  var m = document.getElementById("reintmsg");
  m.textContent = "Reuniendo todo\u2026 medio minuto.";
  fetch("/informe", {method: "POST"})
    .then(function(r){ return r.json(); })
    .then(function(d){
      m.innerHTML = d.ok
        ? "Listo. Est\u00E1 en <b>Mis archivos &rarr; informe-del-equipo.txt</b>. "+
          "C\u00F3pialo a un pendrive y m\u00E1ndalo a soporte."
        : "No se pudo generar el informe.";
    })
    .catch(function(){ m.textContent = "No se pudo generar el informe."; });
});
document.getElementById("reint").addEventListener("click", function(){
  var m = document.getElementById("reintmsg");
  m.textContent = "Buscando\u2026 esto tarda hasta un minuto.";
  fetch("/impresora/reintentar", {method: "POST"})
    .then(function(r){ return r.json(); })
    .then(function(){ m.textContent = "Listo. Recargando\u2026";
                      setTimeout(function(){ location.reload(); }, 1200); })
    .catch(function(){ m.textContent = "No se pudo. Enséñale esto a soporte."; });
});
</script>
<h2>Lector de código de barras</h2>
<div class="caja"><b>Dispara el lector sobre cualquier código</b>
Si el lector funciona, el código aparece aquí solo. No hace falta tocar nada.
<div style="margin-top:12px">
<input id="lec" autofocus placeholder="Esperando un disparo del lector&hellip;"
 style="width:100%;padding:12px;font-size:16px;border-radius:8px;
 border:1px solid #22314f;background:#0a1018;color:#ecf0f4">
<div id="res" style="margin-top:10px;font-size:14px;color:#7885a4">
A&uacute;n no ha llegado ning&uacute;n c&oacute;digo.</div></div></div>
<script>
var campo = document.getElementById("lec");
var res = document.getElementById("res");
var t0 = 0;
campo.addEventListener("keydown", function(e){
  if (!t0) t0 = e.timeStamp;
  if (e.key === "Enter") {
    var ms = Math.round(e.timeStamp - t0);
    var codigo = campo.value.replace(/</g, "&lt;");
    var esLector = (ms < 400 && codigo.length >= 4);
    res.innerHTML = esLector
      ? "<b style='color:#8ee9bd'>El lector FUNCIONA.</b> C&oacute;digo le&iacute;do: <b>"
        + codigo + "</b>, en " + ms + " milisegundos."
      : "Lleg&oacute; <b>" + codigo + "</b> en " + ms +
        " ms. Esa es velocidad de mano, no de lector: si lo escribiste t&uacute;, es normal.";
    campo.value = ""; t0 = 0;
    e.preventDefault();
  }
});
setInterval(function(){ if (document.activeElement !== campo) campo.focus(); }, 1200);
</script>
<div class="pie">Ens&eacute;&ntilde;ale esta pantalla a soporte: aqu&iacute; est&aacute; todo
    lo que hace falta para arreglar la impresora y el lector.</div></html>""")


BARRA = """<!doctype html><html lang="es"><meta charset="utf-8">
<title>QRBott barra</title><style>
*{box-sizing:border-box}
html,body{margin:0;height:100%;overflow:hidden;background:#0d1420;
 font:14px/1.2 system-ui,-apple-system,Arial,sans-serif;color:#ecf0f4;
 -webkit-user-select:none;user-select:none}
#tuerca{width:100%;height:100%;display:flex;align-items:center;
 justify-content:center;background:#0d1420;border-radius:0;cursor:pointer}
#tuerca:active{background:#16223a}
#f{display:none;height:100%;align-items:stretch;gap:6px;padding:5px 8px;
 background:#0d1420;border-top:1px solid #22314f}
button{border:1px solid #22314f;background:#16223a;color:#ecf0f4;border-radius:8px;
 font-size:14px;cursor:pointer;padding:0 14px;white-space:nowrap;line-height:1.15;
 display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px}
button:active{background:#22314f}
button small{font-size:10px;color:#7885a4}
.crece{flex:1;display:flex;align-items:center;gap:8px;color:#4a5878;font-size:11px;
 padding:0 4px}
.rojo{background:#3a1620;border-color:#5c2230;color:#ffb4b4}
.verde{background:#0f2a1e;border-color:#1d5c40;color:#8ee9bd}
.txt{flex:1;display:flex;flex-direction:column;justify-content:center;
 align-items:center;font-size:13px}
.txt small{font-size:10px;color:#7885a4}
svg{width:17px;height:17px;fill:none;stroke:currentColor;stroke-width:2;
 stroke-linecap:round;stroke-linejoin:round}
</style>

<div id="tuerca">
<svg viewBox="0 0 24 24" style="width:18px;height:18px;stroke:#5a6a8c;opacity:.85">
<circle id="luz" cx="21" cy="3" r="3" fill="#5F5E5A" stroke="none"></circle>
<circle cx="12" cy="12" r="3"></circle>
<path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
</svg>
</div>

<div id="f"></div>
<script>
var TUERCA = document.getElementById("tuerca");
var F = document.getElementById("f");
var fija = false;

var ICONO = {
  archivos: '<svg viewBox="0 0 24 24"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path></svg>',
  caja: '<svg viewBox="0 0 24 24"><path d="M4 10l1.5-5h13L20 10"></path><path d="M5 10h14v10H5z"></path><path d="M9 14h6"></path></svg>',
  red: '<svg viewBox="0 0 24 24"><path d="M5 12.5a10 10 0 0 1 14 0"></path><path d="M8.5 15.5a5 5 0 0 1 7 0"></path><circle cx="12" cy="19" r="1"></circle><path d="M2 9a15 15 0 0 1 20 0"></path></svg>',
  web: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"></circle><path d="M3 12h18M12 3c2.5 2.7 2.5 15.3 0 18M12 3c-2.5 2.7-2.5 15.3 0 18"></path></svg>',
  equipo: '<svg viewBox="0 0 24 24"><path d="M14.7 6.3a4 4 0 0 0 5 5L21 19a2 2 0 0 1-2.8 2.8L10.5 14a4 4 0 0 1-5-5z"></path></svg>',
  escritorio: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="12" rx="2"></rect><path d="M8 20h8M12 16v4"></path></svg>',
  reiniciar: '<svg viewBox="0 0 24 24"><path d="M21 12a9 9 0 1 1-3-6.7"></path><path d="M21 3v6h-6"></path></svg>',
  apagar: '<svg viewBox="0 0 24 24"><path d="M12 3v9"></path><path d="M6.6 6.6a9 9 0 1 0 10.8 0"></path></svg>',
  cerrar: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"></path></svg>',
  fijar: '<svg viewBox="0 0 24 24"><path d="M9 4h6l-1 6 4 3v2H6v-2l4-3z"></path><path d="M12 15v5"></path></svg>'
};

function boton(clase, icono, titulo, sub, alPulsar){
  var b = document.createElement("button");
  if (clase) b.className = clase;
  b.innerHTML = (icono ? ICONO[icono] : "") + "<span>" + titulo + "</span>" +
                (sub ? "<small>" + sub + "</small>" : "");
  b.addEventListener("click", alPulsar);
  return b;
}

function modo(m){ fetch("/barra/" + m, {method: "POST"}).catch(function(){}); }

// LA VISTA SIGUE AL TAMAÑO REAL DE LA VENTANA. Antes la página asumía en qué
// tamaño estaba y, si la ventana cambiaba antes (o la orden se perdía), se
// veía la tuerca estirada como una "lente" sin ningún botón que tocar.
// Reportado por el dueño con foto, 30-08-2026. Candado 54.
function ajustar(){
  if (window.innerWidth > 200) {
    TUERCA.style.display = "none";
    if (F.style.display !== "flex") { F.style.display = "flex"; inicio(); }
  } else {
    F.style.display = "none";
    TUERCA.style.display = "flex";
    pintarRed();
  }
}
window.addEventListener("resize", ajustar);

function mostrarTuerca(){ modo("tuerca"); ajustar(); }
function abrir(){ modo(fija ? "fija" : "abierta"); }
TUERCA.addEventListener("click", abrir);

function inicio(){
  F.textContent = "";
  var m = document.createElement("div");
  m.className = "crece"; m.id = "marca";
  m.textContent = "QRBott POS";
  F.appendChild(m);
  pintarUsb();
  F.appendChild(boton("verde", "caja", "CAJA", "Volver a vender",
                      function(){ modo("caja"); mostrarTuerca(); }));
  var bRed = boton("", "red", "Internet", "Comprobando\u2026",
                   function(){ lanzar("red"); });
  bRed.id = "bred";
  F.appendChild(bRed);
  pintarRed();
  F.appendChild(boton("", "archivos", "Mis archivos", "Fotos, descargas",
                      function(){ lanzar("archivos"); }));
  F.appendChild(boton("", "web", "Navegador", "Correo, env\u00EDos",
                      function(){ lanzar("navegador"); }));
  F.appendChild(boton("", "equipo", "Equipo", "Impresora y estado",
                      function(){ lanzar("equipo"); }));
  F.appendChild(boton("", "escritorio", "Escritorio", "Modo t\u00E9cnico",
                      function(){ modo("escritorio"); }));
  F.appendChild(boton(fija ? "verde" : "", "fijar", fija ? "Fija" : "Fijar",
                      fija ? "Tocar para soltar" : "Que no se cierre",
                      function(){ fija = !fija; modo(fija ? "fija" : "abierta"); inicio(); }));
  F.appendChild(boton("", "reiniciar", "Reiniciar", "Restart",
                      function(){ pedir("reiniciar"); }));
  F.appendChild(boton("rojo", "apagar", "Apagar", "Shut down",
                      function(){ pedir("apagar"); }));
  F.appendChild(boton("", "cerrar", "Cerrar", "Ocultar barra", mostrarTuerca));
}

function lanzar(que){ fetch("/abrir/" + que, {method: "POST"}).catch(function(){}); }

// La luz de Internet. Sin esto el dueño no sabe si está conectado, y si algo
// falla no tiene por dónde arreglarlo. Candado 40.
function pintarRed(){
  fetch("/estado").then(function(r){ return r.json(); }).then(function(d){
    var b = document.getElementById("bred");
    var luz = document.getElementById("luz");
    if (b) {
      var s = b.querySelector("small");
      if (d.internet) {
        b.className = "verde";
        if (s) s.textContent = d.cable ? "Por cable \u00B7 conectado" : "Conectado";
      } else {
        b.className = "rojo";
        if (s) s.textContent = "SIN conexi\u00F3n \u00B7 tocar aqu\u00ED";
      }
    }
    if (luz) luz.setAttribute("fill", d.internet ? "#1D9E75" : "#E24B4A");
  }).catch(function(){});
}
setInterval(pintarRed, 6000);

function pedir(que){
  var apagar = (que === "apagar");
  F.textContent = "";
  var d = document.createElement("div");
  d.className = "txt";
  d.innerHTML = "<b>" + (apagar ? "\u00BFApagar el equipo?" : "\u00BFReiniciar el equipo?") +
    "</b><small>Termina la venta antes \u00B7 Finish your sale first</small>";
  F.appendChild(d);
  F.appendChild(boton(apagar ? "rojo" : "verde", "", "S\u00ED", "Yes \u00B7 \u662F",
                      function(){ hacer(que); }));
  F.appendChild(boton("", "", "No", "Cancelar", inicio));
}

function hacer(que){
  F.textContent = "";
  var d = document.createElement("div");
  d.className = "txt";
  d.innerHTML = "<b>" + ((que === "apagar") ? "Apagando\u2026" : "Reiniciando\u2026") + "</b>";
  F.appendChild(d);
  fetch("/" + que, {method: "POST"}).catch(function(){});
}

function pintarUsb(){
  fetch("/usb").then(function(r){ return r.json(); }).then(function(d){
    var m = document.getElementById("marca");
    if (!m || !d.montado) return;
    m.textContent = "";
    var chip = document.createElement("span");
    chip.id = "chipusb";
    chip.style.cssText = "background:#0f2a1e;color:#8ee9bd;padding:5px 11px;" +
      "border-radius:7px;font-size:12px;cursor:pointer";
    chip.textContent = d.nombre + " \u00B7 tocar para sacarlo";
    chip.addEventListener("click", sacarUsb);
    m.appendChild(chip);
  }).catch(function(){});
}

function sacarUsb(){
  var chip = document.getElementById("chipusb");
  if (chip) chip.textContent = "Guardando\u2026 no lo saques todav\u00EDa";
  fetch("/usb/sacar", {method: "POST"}).then(function(r){ return r.json(); })
    .then(function(d){
      if (chip) chip.textContent = d.ok ? "Ya puedes sacarlo" : "Hay algo abierto";
    }).catch(function(){});
}

ajustar();
setInterval(ajustar, 1500);
</script></html>"""

CAJA = """<!doctype html><html lang="es"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>QRBott POS</title><style>
*{box-sizing:border-box;margin:0}
html,body{height:100%;background:#0d1420;color:#ecf0f4;
 font:16px/1.5 system-ui,-apple-system,Arial,sans-serif;
 display:flex;align-items:center;justify-content:center;padding:24px;
 -webkit-user-select:none;user-select:none}
.caja{max-width:620px;width:100%;text-align:center}
img{width:84px;height:84px;margin-bottom:22px}
h1{font-size:30px;font-weight:500;margin-bottom:6px}
.en{color:#7885a4;font-size:16px;margin-bottom:22px}
.sub{color:#8fa3c8;font-size:16px;margin-bottom:28px;line-height:1.7}
button{display:block;width:100%;padding:20px;font-size:19px;border-radius:12px;
 border:none;cursor:pointer;margin-bottom:12px;font-family:inherit}
.b1{background:#378ADD;color:#042C53}
.b2{background:#16223a;color:#ecf0f4;border:1px solid #22314f}
.pie{margin-top:22px;color:#4a5878;font-size:13px}
</style>
<div class="caja">
  <img src="/logo.png" alt="QRBott">
  <h1 id="t">Buscando el punto de venta&hellip;</h1>
  <div class="en" id="t2">Loading &middot; \u6B63\u5728\u52A0\u8F7D</div>
  <div class="sub" id="s"></div>
  <div id="acciones"></div>
  <div class="pie" id="pie"></div>
</div>
<script>
var VERSION = "__VERSION__";
document.getElementById("pie").textContent = "Possum OS 1.0 \u00B7 build " + VERSION;

var A = document.getElementById("acciones");

function sinConexion(){
  document.getElementById("t").textContent = "No hay conexi\u00F3n a Internet";
  document.getElementById("t2").innerHTML = "No internet &middot; \u6CA1\u6709\u7F51\u7EDC";
  document.getElementById("s").innerHTML =
    "Esta es la <b>primera vez</b> que enciendes esta caja, as\u00ED que "+
    "necesita Internet una vez para descargarse.<br>Despu\u00E9s de esto "+
    "podr\u00E1 trabajar aunque se caiga la conexi\u00F3n.";
  if (A.dataset.puesto) return;
  A.dataset.puesto = "1";
  A.innerHTML =
    '<button class="b1" id="ir">Conectar a Internet</button>' +
    '<button class="b2" id="re">Reintentar ahora</button>';
  document.getElementById("ir").addEventListener("click", function(){
    location.href = "/red";
  });
  document.getElementById("re").addEventListener("click", mirar);
}

function mirar(){
  fetch("/estado").then(function(r){ return r.json(); }).then(function(d){
    // Con Internet, o si la caja YA está guardada en este equipo, se abre.
    // Sin Internet y sin caja guardada (primer día), hay que conectarse.
    if (d.internet || d.guardada) {
      document.getElementById("t").textContent = d.internet
        ? "Abriendo el punto de venta\u2026"
        : "Abriendo la caja guardada en el equipo\u2026";
      document.getElementById("s").textContent = d.internet
        ? "" : "Sin Internet. Las ventas se guardan aqu\u00ED y suben solas al volver la red.";
      A.innerHTML = "";
      location.href = d.pos;
    } else {
      sinConexion();
    }
  }).catch(sinConexion);
}

mirar();
setInterval(mirar, 4000);
</script></html>"""

PAGINA = """<!doctype html><html lang="es"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>QRBott POS</title><style>
*{box-sizing:border-box}
body{margin:0;height:100vh;display:flex;align-items:center;justify-content:center;
 background:#080f1a;color:#ecf0f4;font:16px/1.5 system-ui,-apple-system,Arial,sans-serif}
.caja{width:min(560px,92vw);text-align:center}
h1{font-size:30px;margin:0 0 4px}
.sub{color:#7885a4;font-size:15px;margin-bottom:26px}
.en,.zh{color:#a6aeb7;font-size:15px;margin:2px 0}
.zh{color:#7885a4}
.tarjeta{background:#101a2b;border:1px solid #1b2740;border-radius:14px;padding:18px;margin-top:22px;text-align:left}
.red{display:flex;align-items:center;gap:12px;width:100%;background:#16223a;border:1px solid #22314f;
 color:#ecf0f4;border-radius:11px;padding:15px 16px;margin-bottom:9px;font-size:17px;cursor:pointer}
.red:hover{background:#1d2c49}
.barra{width:34px;height:7px;border-radius:4px;background:#22c07a;flex:none}
.nom{flex:1;text-align:left;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
input{width:100%;padding:15px 74px 15px 15px;font-size:18px;border-radius:11px;
 border:1px solid #22314f;background:#16223a;color:#ecf0f4;margin:10px 0}
.campo{position:relative}
.ojo{position:absolute;right:6px;top:50%;transform:translateY(-50%);
 background:#22314f;border:1px solid #2d3f63;border-radius:9px;
 color:#ecf0f4;font-size:26px;cursor:pointer;padding:9px 14px;line-height:1}
.ojo:hover{background:#2d3f63}
/* marco bien visible al moverse con el tabulador, sin necesidad de ratón */
button:focus-visible,input:focus-visible,.red:focus-visible,.ojo:focus-visible{
 outline:3px solid #22c07a;outline-offset:2px}
button.ok{width:100%;padding:15px;font-size:18px;font-weight:700;border:0;border-radius:11px;
 background:#22c07a;color:#04150d;cursor:pointer}
button.gris{background:transparent;color:#7885a4;border:0;font-size:15px;margin-top:14px;cursor:pointer}
.cable{background:#0f2a1e;border:1px solid #1d5c40;color:#8ee9bd;border-radius:11px;padding:13px;margin-bottom:16px;font-size:15px}
.aviso{color:#e86060;margin-top:10px;min-height:22px;font-size:15px}
.logo{width:78px;margin-bottom:12px;opacity:.95}
.luego{margin-top:18px;color:#a6aeb7;font-size:15px;line-height:1.6}
.luego span{color:#7885a4;font-size:13px}
.pie{margin-top:22px;color:#46536b;font-size:12px;font-family:ui-monospace,monospace}
</style>
<div class="caja">
  <img class="logo" src="/logo.png" alt="">
  <h1>Conecta el equipo a internet</h1>
  <div class="sub">Possum OS 1.0 &nbsp;·&nbsp; Developed by Windoce LLC</div>
  <div class="en">Connect this device to the internet</div>
  <div class="zh">请将设备连接到网络</div>

  <div class="tarjeta">
    <div class="cable">
      <b>Lo más fácil:</b> conecta el cable de internet al equipo y listo.<br>
      <span style="color:#5d9e80">Easiest: just plug in the network cable. · 最简单：插上网线即可。</span>
      <div style="margin-top:9px;padding-top:9px;border-top:1px solid #1d5c40">
        <b>¿No tienes cable?</b> Conecta tu celular al equipo con el cable USB y activa
        «Compartir internet» (anclaje por USB).<br>
        <span style="color:#5d9e80">No cable? Plug your phone in via USB and turn on USB tethering.
        · 没有网线？用USB线连接手机并开启「USB共享网络」。</span>
      </div>
    </div>
    <div id="lista"></div>
    <div id="clave" style="display:none">
      <div style="margin:6px 0 2px" id="elegida"></div>
      <div class="campo">
        <input id="pass" type="password" placeholder="Contraseña del Wi-Fi · Wi-Fi password · Wi-Fi密码">
        <button class="ojo" id="ojo" onclick="verClave()" aria-label="Ver la contraseña">👁</button>
      </div>
      <button class="ok" onclick="conectar()">Conectar &nbsp;·&nbsp; Connect &nbsp;·&nbsp; 连接</button>
      <button class="gris" onclick="volver()">← Elegir otra red · Choose another network</button>
      <div style="color:#46536b;font-size:13px;margin-top:8px">
        Puedes moverte con la tecla Tab y confirmar con Enter.
        · Use Tab to move and Enter to confirm. · 可用Tab键移动，Enter键确认。</div>
    </div>
    <div class="aviso" id="aviso"></div>
    <button class="gris" id="reintentar" onclick="reintentar()"
      style="width:100%;background:#16223a;color:#ecf0f4;border:1px solid #22314f;
             border-radius:11px;padding:13px;font-size:16px;margin-top:6px">
      Buscar otra vez · Search again · 重新搜索</button>
  </div>
  <div class="luego">
    En cuanto conecte, el punto de venta se abre solo. No hay que hacer nada más.<br>
    <span>As soon as it connects, the point of sale opens by itself.  ·  连接成功后将自动打开收银系统。</span>
  </div>
  <div class="pie" id="pie"></div>
</div>
<script>
let sel=null;
async function estado(){
  const r=await fetch('/estado').then(r=>r.json()).catch(()=>null);
  if(!r) return;
  if(r.internet){
    const desdeBarra = location.pathname.indexOf('/red') === 0;
    document.body.innerHTML=
    '<div class="caja"><h1 style="color:#22c07a">Conectado</h1>'+
    '<div class="en">Connected · 已连接</div><div class="sub">'+
    (desdeBarra ? 'Ya puedes cerrar esta ventana.' : 'Abriendo el punto de venta…')+
    '</div></div>';
    if(!desdeBarra) setTimeout(()=>location.href=r.pos,1200);
    return; }
  if(sel===null) pintar(r.redes, r.motivo);
  const t=r.datos||{};
  document.getElementById('pie').textContent =
    'equipo '+(t.equipo||'?')+'  ·  wifi '+(t.wifi||'?')+' ('+(t.radio||'?')+')'+
    '  ·  cable '+(t.cable||'?')+'  ·  '+(r.motivo||'')+
    '  ·  '+(t.detalle||'')+'  ·  v'+(t.version||'?');
}
const MOTIVOS={
  'buscando':['Buscando redes Wi-Fi…','Searching for Wi-Fi networks…','正在搜索Wi-Fi网络…'],
  'sin-tarjeta':['Este equipo no tiene Wi-Fi. Conecta el cable de internet.',
                 'This device has no Wi-Fi. Please use the network cable.',
                 '本设备无Wi-Fi，请使用网线。'],
  'apagada':['El Wi-Fi está apagado en el equipo. Conecta el cable de internet.',
             'Wi-Fi is turned off on this device. Please use the network cable.',
             '设备的Wi-Fi已关闭，请使用网线。'],
  'sin-redes':['No se ve ninguna red Wi-Fi cerca. Acerca el equipo al router o usa el cable.',
               'No Wi-Fi networks found. Move closer to the router or use the cable.',
               '未发现Wi-Fi网络。请靠近路由器或使用网线。']};
function pintar(redes,motivo){
  const l=document.getElementById('lista');
  if(!redes.length){
    const m=MOTIVOS[motivo]||MOTIVOS['buscando'];
    l.innerHTML='<div style="color:#a6aeb7;line-height:1.7">'+m[0]+
      '<br><span style="color:#7885a4;font-size:14px">'+m[1]+'<br>'+m[2]+'</span></div>';
    return; }
  l.innerHTML=redes.map((r,i)=>
    '<button class="red" onclick="elegir('+i+')"><span class="barra" style="opacity:'+
    (0.35+0.65*r.senal/100).toFixed(2)+'"></span><span class="nom">'+r.nombre+'</span>'+
    (r.abierta?'':'<span style="color:#7885a4">🔒</span>')+'</button>').join('');
  window._redes=redes;
}
function elegir(i){ sel=window._redes[i];
  document.getElementById('lista').style.display='none';
  document.getElementById('clave').style.display='block';
  document.getElementById('elegida').textContent='Red: '+sel.nombre;
  document.getElementById('pass').focus(); }
function verClave(){
  const c=document.getElementById('pass'), o=document.getElementById('ojo');
  const ver = c.type==='password';
  c.type = ver ? 'text' : 'password';
  o.textContent = ver ? '🙈' : '👁';
  o.setAttribute('aria-label', ver ? 'Ocultar la contraseña' : 'Ver la contraseña');
  c.focus();
}
function volver(){ sel=null;
  document.getElementById('lista').style.display='block';
  document.getElementById('clave').style.display='none';
  document.getElementById('aviso').textContent=''; }
async function reintentar(){
  const b=document.getElementById('reintentar');
  b.textContent='Buscando… · Searching… · 搜索中…'; b.disabled=true;
  await fetch('/reintentar',{method:'POST'}).catch(()=>{});
  setTimeout(()=>{ b.textContent='Buscar otra vez · Search again · 重新搜索'; b.disabled=false; }, 12000);
}
async function conectar(){
  const a=document.getElementById('aviso'); a.style.color='#7885a4';
  a.textContent='Conectando… · Connecting… · 正在连接…';
  const r=await fetch('/conectar',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({red:sel.nombre,clave:document.getElementById('pass').value})})
    .then(r=>r.json()).catch(()=>({ok:false}));
  if(!r.ok){ a.style.color='#e86060';
    a.innerHTML='No se pudo conectar. Revisa la contraseña. · Could not connect. · 无法连接。'+
      (r.error?'<br><span style="color:#7885a4;font-size:13px;font-family:ui-monospace,monospace">'+
       r.error.replace(/</g,'&lt;')+'</span>':''); }
}
estado(); setInterval(estado,3000);
</script></html>"""

class Manejador(BaseHTTPRequestHandler):
    def log_message(self, *a): pass          # sin ruido en el registro

    def _responder(self, cuerpo, tipo="text/html; charset=utf-8", codigo=200):
        self.send_response(codigo)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(cuerpo)))
        self.end_headers()
        self.wfile.write(cuerpo)

    def do_GET(self):
        if self.path.startswith("/estado"):
            # ¿La caja ya se guardó alguna vez en este equipo? Si sí, puede
            # abrir SIN Internet (la nube la deja guardada en el disco). La
            # primera vez sí hace falta red, para bajarla. Candado 41.
            marca = "/var/qrbott-datos/caja/pos-guardado"
            with _cerrojo:
                hay_red = _estado["internet"]
            if hay_red:
                try:
                    os.makedirs(os.path.dirname(marca), exist_ok=True)
                    open(marca, "w").write("si")
                except Exception:
                    pass
            with _cerrojo:                     # todo sale de la caché: instantáneo
                d = {"internet": _estado["internet"], "pos": POS,
                     "guardada": os.path.exists(marca),
                     "cable": _estado["cable"], "redes": list(_estado["redes"]),
                     "motivo": _estado["motivo"], "datos": _estado["datos"]}
            return self._responder(json.dumps(d).encode(), "application/json")
        if self.path.startswith("/caja"):
            # La caja SIEMPRE abre aquí. Antes se decidía UNA VEZ al arrancar:
            # si fallaba, el dueño quedaba en una página muerta, sin login (que
            # vive en la nube) y sin forma de conectarse. Ver CANDADOS.md nº 40.
            return self._responder(
                CAJA.replace("__VERSION__", VERSION).encode("utf-8"))
        if self.path.startswith("/red"):
            # El asistente de Wi-Fi, abierto A VOLUNTAD desde la barra. Antes
            # solo existía en el primer arranque: si fallaba ahí, el dueño se
            # quedaba SIN NINGUNA forma de conectarse y había que reinstalar.
            # Ver CANDADOS.md nº 40.
            return self._responder(PAGINA.encode("utf-8"))
        if self.path.startswith("/barra"):
            return self._responder(BARRA.encode("utf-8"))
        if self.path.startswith("/usb"):
            montado, nombre, punto = False, "", ""
            try:
                with open("/opt/qrbott/estado-usb", encoding="utf-8") as f:
                    partes = f.read().strip().split("\t")
                if partes and partes[0] == "OK":
                    montado, nombre = True, partes[1] if len(partes) > 1 else "Pendrive"
                    punto = partes[2] if len(partes) > 2 else ""
            except Exception:
                pass
            return self._responder(
                json.dumps({"montado": montado, "nombre": nombre, "ruta": punto}).encode(),
                "application/json")
        if self.path.startswith("/actualiza/estado"):
            est, cola = _estado_actualiza()
            try:
                mtime = int(os.path.getmtime("/opt/qrbott/estado-actualiza"))
            except Exception:
                mtime = 0
            _, act = corre(["systemctl", "is-active", "qrbott-actualiza.service"], t=5)
            return self._responder(json.dumps({"estado": est, "registro": cola, "mtime": mtime,
                                               "activo": act.strip() in ("active", "activating"),
                                               "version": VERSION}).encode(),
                                   "application/json")
        if self.path.startswith("/impresoras"):
            return self._responder(pagina_impresoras().encode("utf-8"))
        if self.path.startswith("/acerca"):
            return self._responder(pagina_acerca().encode("utf-8"))
        if self.path.startswith("/possum.svg"):
            try:
                with open("/opt/qrbott/possum.svg", "rb") as f:
                    return self._responder(f.read(), "image/svg+xml")
            except Exception:
                return self._responder(b"", "image/svg+xml", 404)
        if self.path.startswith("/equipo"):
            return self._responder(pagina_equipo().encode("utf-8"))
        if self.path.startswith("/logo.png"):
            try:
                with open("/opt/qrbott/logo.png", "rb") as f:
                    return self._responder(f.read(), "image/png")
            except Exception:
                return self._responder(b"", "image/png", 404)
        return self._responder(PAGINA.encode("utf-8"))

    def _impresoras_orden(self):
        """Órdenes del gestor de impresoras: prueba, predeterminada, quitar,
        agregar, reintentar la integrada. Solo nombres y URIs que el sistema
        ve de verdad (nada de armar comandos con texto libre)."""
        import re, tempfile, urllib.parse as up
        ruta = self.path.split("?")[0]
        q = up.parse_qs(self.path.split("?", 1)[1]) if "?" in self.path else {}
        nombre = (q.get("nombre", [""])[0] or "").strip()
        def resp(ok, detalle=""):
            return self._responder(json.dumps({"ok": ok, "detalle": detalle}).encode(), "application/json")
        def nombre_valido(n):
            return bool(re.fullmatch(r"[A-Za-z0-9_-]{1,32}", n))
        lista, detectados, _ = _leer_impresoras()
        registradas = {i["nombre"]: i for i in lista}
        if ruta == "/impresoras/reintegrada":
            corre(["/opt/qrbott/impresora.sh"], t=90)
            return resp(True, "Se volvió a buscar la impresora integrada.")
        if ruta == "/impresoras/agregar":
            try:
                n = int(self.headers.get("Content-Length", "0"))
                d = json.loads(self.rfile.read(min(n, 4096)).decode("utf-8", "replace"))
            except Exception:
                return resp(False, "orden ilegible")
            nom, uri, tipo = str(d.get("nombre", "")).strip(), str(d.get("uri", "")), str(d.get("tipo", ""))
            if not nombre_valido(nom):
                return resp(False, "el nombre solo puede llevar letras, números, guion y guion bajo (máximo 32)")
            if uri not in detectados:
                return resp(False, "esa impresora ya no se detecta; toca «Buscar de nuevo»")
            if nom in registradas:
                return resp(False, "ya hay una impresora con ese nombre")
            if tipo == "termica58":
                args = ["lpadmin", "-p", nom, "-E", "-v", uri, "-P", "/opt/qrbott/qrbott58.ppd", "-o", "printer-is-shared=false"]
            elif tipo == "cruda":
                args = ["lpadmin", "-p", nom, "-E", "-v", uri, "-m", "raw", "-o", "printer-is-shared=false"]
            else:
                return resp(False, "tipo desconocido")
            c, sal = corre(args, t=30)
            if c != 0:
                return resp(False, sal.strip()[:200])
            corre(["cupsenable", nom], t=10); corre(["cupsaccept", nom], t=10)
            extra = [e for e in _impresoras_extra() if e.get("nombre") != nom]
            extra.append({"nombre": nom, "uri": uri, "tipo": tipo, "predeterminada": False})
            _guardar_impresoras_extra(extra)
            return resp(True, "registrada")
        if not nombre_valido(nombre) or nombre not in registradas:
            return resp(False, "esa impresora no está registrada")
        if ruta == "/impresoras/prueba":
            datos = (b"\x1b@" + ("QRBott POS\nPRUEBA DE IMPRESORA\n%s\n%s\nSi lees esto, FUNCIONA.\n"
                     % (nombre, time.strftime("%Y-%m-%d %H:%M:%S"))).encode("cp437", "replace") + b"\n\n\n\n\x1dV\x00")
            with tempfile.NamedTemporaryFile(prefix="qrbott-pr-", delete=False) as f:
                f.write(datos); ruta_t = f.name
            tipo = registradas[nombre]["tipo"]
            if tipo.startswith("térmica"):
                args = ["lp", "-d", nombre, "-t", "prueba", "-o", "document-format=application/vnd.qrbott-escpos", ruta_t]
            elif tipo.startswith("cruda"):
                args = ["lp", "-d", nombre, "-t", "prueba", "-o", "raw", ruta_t]
            else:
                with open(ruta_t, "w") as f:
                    f.write("QRBott POS - PRUEBA DE IMPRESORA\n%s\n%s\n" % (nombre, time.strftime("%Y-%m-%d %H:%M:%S")))
                args = ["lp", "-d", nombre, "-t", "prueba", ruta_t]
            c, sal = corre(args, t=20)
            try:
                os.unlink(ruta_t)
            except Exception:
                pass
            _registrar_impresion("gestor-de-impresoras", len(datos), "PRUEBA " + nombre, c == 0, sal.strip()[:80], 0.0)
            return resp(c == 0, ("Prueba enviada a %s. Si salió papel, funciona." % nombre) if c == 0 else sal.strip()[:200])
        if ruta == "/impresoras/predeterminada":
            c, sal = corre(["lpadmin", "-d", nombre], t=15)
            extra = _impresoras_extra()
            for e in extra:
                e["predeterminada"] = (e.get("nombre") == nombre)
            _guardar_impresoras_extra(extra)
            return resp(c == 0, ("%s es ahora la predeterminada." % nombre) if c == 0 else sal.strip()[:200])
        if ruta == "/impresoras/quitar":
            if nombre == "QRBott-Ticket":
                return resp(False, "la integrada no se quita")
            c, sal = corre(["lpadmin", "-x", nombre], t=15)
            _guardar_impresoras_extra([e for e in _impresoras_extra() if e.get("nombre") != nombre])
            return resp(c == 0, ("%s quitada." % nombre) if c == 0 else sal.strip()[:200])
        return resp(False, "orden desconocida")

    def _abrir_ventana(self, url, clase, perfil="navegador"):
        """Abre una ventana de navegador NORMAL en la sesión del cajero — y si
        YA HAY una, la RESTAURA en vez de abrir otra. Antes cada toque abría
        una ventana nueva y el WhatsApp recargaba de cero: el dueño perdía la
        sesión cada vez. Candado 56."""
        cod, vid = corre(["bash", "-c",
            "DISPLAY=:0 xdotool search --class %s 2>/dev/null | tail -1" % clase], t=10)
        vid = (vid or "").strip()
        if cod == 0 and vid.isdigit():
            # Los paneles de datos se RECARGAN al volver (datos frescos); el
            # Navegador NO (mataría la sesión de WhatsApp). Candado 58.
            recarga = ("; DISPLAY=:0 xdotool key --window %s F5" % vid
                       if clase != "QRBottNavegador" else "")
            corre(["bash", "-c",
                "DISPLAY=:0 xdotool windowmap %s; DISPLAY=:0 xdotool windowactivate %s; "
                "DISPLAY=:0 xdotool windowraise %s%s" % (vid, vid, vid, recarga)], t=10)
            return
        # Perfil PROPIO por tipo de ventana: con el mismo perfil, el navegador
        # reutiliza el proceso y la ventana nueva hereda la clase vieja — tocar
        # «Equipo» habría restaurado WhatsApp. Auditoría v7, fallo 25.
        corre(["su", "-l", "pos", "-c",
               "DISPLAY=:0 nohup chromium --class=%s %s "
               "--user-data-dir=/var/qrbott-datos/caja/%s "
               "--no-first-run --password-store=basic >/dev/null 2>&1 &"
               % (clase, url, perfil)], t=15)

    def _orden_legitima(self):
        """¿Esta orden viene de NUESTRAS pantallas, o de una web cualquiera?

        Sin esto, una página web abierta con el botón «Navegador» podría mandar
        una orden de apagado a 127.0.0.1:7777 y apagar la caja a mitad de una
        venta. El navegador marca las peticiones con su origen: solo se aceptan
        las que salen de nuestras propias páginas.
        Auditoría 29-08-2026, fallo nº 4. Candado 46."""
        propios = ("http://127.0.0.1:%d" % PUERTO, "http://localhost:%d" % PUERTO)
        origen = self.headers.get("Origin")
        if origen:
            return origen in propios
        # Sin Origin: solo vale si el navegador dice que es del mismo sitio.
        sitio = self.headers.get("Sec-Fetch-Site")
        if sitio:
            return sitio in ("same-origin", "none")
        # Ni Origin ni Sec-Fetch-Site: es curl u otra herramienta local, no una
        # web. Se acepta (hace falta para el arranque y para soporte).
        return True

    def _imprimir_directo(self, texto):
        """Escribe el ticket DIRECTO al puerto de la impresora, sin pasar por
        el motor de impresión. En el equipo real el motor (CUPS) se cae y se
        bloquea; esto no depende de él: es el camino garantizado.
        ESC/POS: reiniciar, texto, avanzar papel y cortar. Candado 52."""
        datos = (b"\x1b@" +
                 texto.replace("\r\n", "\n").encode("cp437", "replace") +
                 b"\n\n\n\n\x1dV\x00")
        # UN SOLO DUEÑO DEL PUERTO. Desde que el motor de impresión vive, la
        # cola y la vía directa escribían AL MISMO /dev/lp0: cuando chocaban,
        # la directa fallaba, el POS caía al diálogo y salía el ticket ENANO
        # (una hoja ancha apretada a 58mm). Ahora la vía directa pasa POR el
        # motor en modo crudo (-o raw): él serializa el puerto y no hay
        # choque posible. El escrito directo queda solo de respaldo.
        # Informe de campo del 1-09-2026. Candado 68.
        try:
            import tempfile
            c, marcha = corre(["lpstat", "-r"], t=5)
            if "is running" in (marcha or "").lower():
                with tempfile.NamedTemporaryFile(prefix="qrbott-tk-",
                                                 delete=False) as f:
                    f.write(datos)
                    ruta = f.name
                # NUNCA "-o raw": con destino file:/dev/lp0 un trabajo crudo
                # (sin filtros) se da por "completado" y NO escribe ni un byte
                # (visto en la VM el 1-09-2026: 2 trabajos, 0 bytes en el
                # puerto). El tipo application/vnd.qrbott-escpos pasa por el
                # filtro de paso y sí llega. Candado 75.
                c2, sal2 = corre(["lp", "-d", "QRBott-Ticket", "-t", "ticket-directo",
                                  "-o", "document-format=application/vnd.qrbott-escpos",
                                  ruta], t=15)
                try:
                    os.unlink(ruta)
                except Exception:
                    pass
                if c2 == 0:
                    return True, "cola QRBott-Ticket (ESC/POS)"
        except Exception:
            pass
        ultimo = "no hay ningún puerto de impresora"
        for dev in ("/dev/usb/lp0", "/dev/usb/lp1", "/dev/lp0", "/dev/lp1"):
            # SIN bloqueo: si la impresora está apagada o sin papel, un open
            # normal se queda colgado PARA SIEMPRE. Auditoría v4, fallo 23.
            try:
                fd = os.open(dev, os.O_WRONLY | os.O_NONBLOCK)
            except Exception as e:
                ultimo = "%s: %s" % (dev, e)
                continue
            try:
                enviado = 0
                intentos = 0
                while enviado < len(datos) and intentos < 55:
                    try:
                        enviado += os.write(fd, datos[enviado:])
                        intentos = 0
                    except BlockingIOError:
                        intentos += 1
                        time.sleep(0.05)
                if enviado >= len(datos):
                    return True, dev
                ultimo = ("%s: la impresora no acepta datos "
                          "(¿apagada o sin papel?)" % dev)
            except Exception as e:
                ultimo = "%s: %s" % (dev, e)
            finally:
                try:
                    os.close(fd)
                except Exception:
                    pass
        return False, ultimo

    def do_OPTIONS(self):
        """El POS en la nube (https) pregunta antes de mandar el ticket a
        127.0.0.1 (preflight CORS y «acceso a red privada»). Sin respuesta,
        el navegador tira la orden y el POS cae al diálogo de imprimir.
        Candado 74."""
        origen = self.headers.get("Origin", "") or "*"
        pedidas = self.headers.get("Access-Control-Request-Headers", "") or "Content-Type"
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", origen)
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", pedidas)
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "86400")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_POST(self):
        if self.path.startswith("/imprimir"):
            # La nube (pos.qrbott.com) también puede imprimir por aquí: es la
            # vía SIN motor. Orígenes permitidos: nuestras pantallas y el POS.
            origen = self.headers.get("Origin", "")
            de_confianza = (not origen or
                origen in ("http://127.0.0.1:%d" % PUERTO,
                           "http://localhost:%d" % PUERTO,
                           "https://pos.qrbott.com", "https://app.qrbott.com"))
            if not de_confianza:
                return self._responder(b'{"ok":false}', "application/json", 403)
            try:
                n = int(self.headers.get("Content-Length", "0"))
                texto = self.rfile.read(min(n, 65536)).decode("utf-8", "replace")
            except Exception:
                texto = ""
            t0, largo = time.time(), len(texto)
            if texto.lstrip().startswith("{"):
                # Si la nube manda JSON, el ticket va en un campo, no se
                # imprime el JSON entero.
                try:
                    j = json.loads(texto)
                    for k in ("texto", "text", "ticket", "contenido", "body"):
                        if isinstance(j.get(k), str):
                            texto = j[k]; break
                except Exception:
                    pass
            if not texto.strip():
                texto = ("QRBott POS\nPRUEBA DE IMPRESORA\n" +
                         time.strftime("%Y-%m-%d %H:%M:%S") +
                         "\nSi lees esto, la impresora FUNCIONA.\n")
            ok, detalle = self._imprimir_directo(texto)
            _registrar_impresion(origen, largo, texto, ok, detalle, time.time() - t0)
            cuerpo = json.dumps({"ok": ok, "detalle": detalle}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Private-Network", "true")
            self.send_header("Content-Length", str(len(cuerpo)))
            self.end_headers()
            self.wfile.write(cuerpo)
            return
        if not self._orden_legitima():
            return self._responder(
                b'{"ok":false,"error":"orden rechazada: no viene de la caja"}',
                "application/json", 403)
        if self.path.startswith("/actualizar"):
            # Buscar y aplicar un parche AHORA (botón de Equipo). Corre aparte,
            # como administrador, por systemd. Candado 71.
            corre(["systemctl", "start", "--no-block", "qrbott-actualiza.service"], t=10)
            return self._responder(b'{"ok":true}', "application/json")

        if self.path.startswith("/barra/"):
            modo = self.path.rsplit("/", 1)[-1].split("?")[0]
            if modo in ("tuerca", "abierta", "fija", "escritorio", "caja"):
                corre(["/opt/qrbott/barra-modo.sh", modo], t=20)
            return self._responder(b'{"ok":true}', "application/json")
        if self.path.startswith("/informe"):
            cod, _ = corre(["/opt/qrbott/informe.sh"], t=120)
            return self._responder(
                json.dumps({"ok": cod == 0}).encode(), "application/json")
        if self.path.startswith("/impresora/reintentar"):
            corre(["/opt/qrbott/impresora.sh"], t=90)
            return self._responder(b'{"ok":true}', "application/json")
        if self.path.startswith("/usb/sacar"):
            # Primero se vacía lo que esté a medio escribir, y luego se suelta.
            corre(["sync"], t=20)
            cod, _ = corre(["bash", "-c",
                "for p in /media/qrbott/*; do mountpoint -q \"$p\" && umount \"$p\"; done"], t=25)
            corre(["bash", "-c", "rmdir /media/qrbott/* 2>/dev/null; "
                   "rm -f /opt/qrbott/estado-usb '/var/qrbott-datos/Mis archivos/Pendrive'"], t=15)
            return self._responder(
                json.dumps({"ok": cod == 0}).encode(), "application/json")
        if self.path.startswith("/abrir/archivos"):
            corre(["su", "-l", "pos", "-c",
                   "DISPLAY=:0 nohup pcmanfm '/var/qrbott-datos/Mis archivos' "
                   ">/dev/null 2>&1 &"], t=15)
            return self._responder(b'{"ok":true}', "application/json")
        if self.path.startswith("/abrir/red"):
            self._abrir_ventana("http://127.0.0.1:7777/red", "QRBottRed", "red")
            return self._responder(b'{"ok":true}', "application/json")
        if self.path.startswith("/abrir/navegador"):
            self._abrir_ventana("https://app.qrbott.com/", "QRBottNavegador")
            return self._responder(b'{"ok":true}', "application/json")
        if self.path.startswith("/abrir/equipo"):
            self._abrir_ventana("http://127.0.0.1:7777/equipo", "QRBottPanel", "panel")
            return self._responder(b'{"ok":true}', "application/json")
        if self.path.startswith("/abrir/acerca"):
            self._abrir_ventana("http://127.0.0.1:7777/acerca", "QRBottAcerca", "acerca")
            return self._responder(b'{"ok":true}', "application/json")
        if self.path.startswith("/abrir/impresoras"):
            self._abrir_ventana("http://127.0.0.1:7777/impresoras", "QRBottImpresoras", "impresoras")
            return self._responder(b'{"ok":true}', "application/json")
        if self.path.startswith("/abrir/informe"):
            self._abrir_ventana("file:///var/qrbott-datos/Mis%20archivos/informe-del-equipo.txt",
                                "QRBottInforme", "informe")
            return self._responder(b'{"ok":true}', "application/json")
        if self.path.startswith("/impresoras/"):
            return self._impresoras_orden()

        # Apagar y reiniciar DE FORMA LIMPIA (nunca cortando la corriente)
        if self.path.startswith("/apagar"):
            threading.Timer(1.0, lambda: corre(["systemctl", "poweroff"], t=20)).start()
            return self._responder(b'{"ok":true}', "application/json")
        if self.path.startswith("/reiniciar"):
            threading.Timer(1.0, lambda: corre(["systemctl", "reboot"], t=20)).start()
            return self._responder(b'{"ok":true}', "application/json")
        if self.path.startswith("/reintentar"):
            def tarea():
                redes, motivo, detalle = escanear()
                datos = datos_equipo(); datos["detalle"] = detalle
                with _cerrojo:
                    _estado["redes"], _estado["motivo"] = redes, motivo
                    _estado["datos"] = datos
            threading.Thread(target=tarea, daemon=True).start()
            return self._responder(b'{"ok":true}', "application/json")
        n = int(self.headers.get("Content-Length", 0) or 0)
        try:
            d = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            d = {}
        red, clave = str(d.get("red", ""))[:64], str(d.get("clave", ""))[:128]
        if not red:
            return self._responder(b'{"ok":false}', "application/json")
        # Borrar un intento anterior fallido: si queda guardado, vuelve a fallar
        corre(["nmcli", "connection", "delete", red], t=15)
        # SIN shell: la red y la clave viajan como argumentos, no como texto de comando
        args = ["nmcli", "device", "wifi", "connect", red]
        if clave:
            args += ["password", clave]
        c, salida = corre(args, t=70)
        if c == 0:
            # CANARIO DE GUARDADO: conectar no basta — la clave tiene que
            # QUEDAR EN EL DISCO o el equipo la olvida al reiniciar (nos pasó
            # tres veces). Se fija autoconexión y se comprueba el archivo; si
            # no está, SE DICE en la pantalla, no se descubre al reiniciar.
            # Candado 69.
            corre(["nmcli", "connection", "modify", red,
                   "connection.autoconnect", "yes"], t=15)
            corre(["sync"], t=10)
            import glob as _g
            en_disco = [x for x in _g.glob("/var/qrbott-datos/red/*")
                        if red.lower() in os.path.basename(x).lower()
                        or x.endswith(".nmconnection")]
            if not en_disco:
                salida = ("Conectó, pero la clave NO quedó guardada en el "
                          "equipo: al reiniciar se perderá. Enséñale esta "
                          "pantalla a soporte (o el informe del equipo).")
            with _cerrojo:
                _estado["internet"] = hay_internet()
        # El mensaje EXACTO del sistema: es lo que dice si la clave está mal,
        # si la red no responde, o si el problema es otro.
        motivo = " ".join((salida or "").split())[:160]
        return self._responder(json.dumps({"ok": c == 0, "error": motivo}).encode(),
                               "application/json")

if __name__ == "__main__":
    threading.Thread(target=bucle_conexion, daemon=True).start()
    threading.Thread(target=bucle_escaneo,  daemon=True).start()
    # con hilos: una consulta lenta no deja colgadas a las demás
    def _vigia_usb():
        """Cada 6 segundos repasa los discos USB y monta el que falte. Es el
        respaldo de la regla del sistema, que en el equipo real no disparó."""
        while True:
            try:
                subprocess.run(["/opt/qrbott/montar-usb.sh", "escanear"],
                               capture_output=True, timeout=30)
            except Exception:
                pass
            time.sleep(6)
    threading.Thread(target=_vigia_usb, daemon=True).start()
    ThreadingHTTPServer(("127.0.0.1", PUERTO), Manejador).serve_forever()
